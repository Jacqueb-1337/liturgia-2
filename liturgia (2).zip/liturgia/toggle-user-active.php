<?php
// toggle-user-active.php
// Usage (web): https://<site>/liturgia/toggle-user-active.php?secret=INIT_SECRET&email=...&active=0
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
$secret = getenv('INIT_SECRET') ?: null;
$provided = $_GET['secret'] ?? null;
if (!$provided || !$secret || $provided !== $secret) {
    http_response_code(403);
    echo json_encode(['error'=>'forbidden']);
    exit;
}
$email = $_GET['email'] ?? null;
$cid = $_GET['cid'] ?? null; // stripe customer id
$active = isset($_GET['active']) ? intval($_GET['active']) : null;
if ($active === null) { http_response_code(400); echo json_encode(['error'=>'missing active param']); exit; }
$log = __DIR__ . '/data/stripe_webhook.log';
try {
    $pdo = get_db();
    $driver = strtolower($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) ?: 'sqlite');
    if ($driver === 'mysql') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) UNIQUE, active TINYINT, plan VARCHAR(32), expires_at INT, stripe_customer_id VARCHAR(255), created_at INT)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, active INTEGER, plan TEXT, expires_at INTEGER, stripe_customer_id TEXT, created_at INTEGER)");
    }
    if ($email) {
        $stmt = $pdo->prepare('UPDATE users SET active = :a WHERE email = :e');
        $stmt->execute([':a'=>$active, ':e'=>$email]);
        @file_put_contents($log, date('c') . " - toggle: set active={$active} for email={$email}\n", FILE_APPEND);
        echo json_encode(['ok'=>true,'email'=>$email,'active'=>$active,'rows'=>$stmt->rowCount()]);
        exit;
    } elseif ($cid) {
        $stmt = $pdo->prepare('UPDATE users SET active = :a WHERE stripe_customer_id = :cid');
        $stmt->execute([':a'=>$active, ':cid'=>$cid]);
        @file_put_contents($log, date('c') . " - toggle: set active={$active} for cid={$cid}\n", FILE_APPEND);
        echo json_encode(['ok'=>true,'cid'=>$cid,'active'=>$active,'rows'=>$stmt->rowCount()]);
        exit;
    } else {
        http_response_code(400);
        echo json_encode(['error'=>'missing email or cid']);
        exit;
    }
} catch (Exception $e) {
    @file_put_contents($log, date('c') . " - toggle: DB error: " . $e->getMessage() . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error'=>'db','detail'=>$e->getMessage()]);
    exit;
}
?>