<?php
header('Content-Type: text/plain');

echo "SQLite File Path Checker\n";
echo str_repeat('=', 50) . "\n\n";

$paths = [
    __DIR__ . '/data/auth.sqlite',
    '/data/vhosts/jacqueb.me/httpdocs/liturgia/data/auth.sqlite',
    __DIR__ . '/../data/auth.sqlite',
    realpath(__DIR__ . '/data/auth.sqlite'),
    realpath(__DIR__ . '/../data/auth.sqlite'),
];

echo "__DIR__ = " . __DIR__ . "\n\n";

foreach ($paths as $path) {
    if ($path === false || $path === null) continue;
    
    echo "Path: $path\n";
    if (file_exists($path)) {
        echo "  ✓ EXISTS\n";
        echo "  Size: " . filesize($path) . " bytes\n";
        echo "  Readable: " . (is_readable($path) ? 'yes' : 'no') . "\n";
        
        try {
            $db = new PDO("sqlite:$path");
            $result = $db->query("SELECT COUNT(*) as count FROM tokens WHERE revoked_at IS NULL")->fetch();
            echo "  Active tokens: " . $result['count'] . "\n";
        } catch (Exception $e) {
            echo "  Database error: " . $e->getMessage() . "\n";
        }
    } else {
        echo "  ✗ NOT FOUND\n";
    }
    echo "\n";
}

echo "\nLooking for data folders:\n";
$dataDirs = glob(__DIR__ . '/**/data', GLOB_ONLYDIR);
foreach ($dataDirs as $dir) {
    echo "  Found: $dir\n";
    $sqliteFile = $dir . '/auth.sqlite';
    if (file_exists($sqliteFile)) {
        echo "    → auth.sqlite exists here!\n";
    }
}
?>
