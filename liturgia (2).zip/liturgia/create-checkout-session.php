<?php
require __DIR__.'/helpers.php';
// Creates a Stripe Checkout session for subscription plans (monthly/yearly)
// Expects POST: email, plan (monthly|yearly)
header('Content-Type: application/json');

$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL) ?: (isset($_POST['email']) ? trim($_POST['email']) : '');
$plan = isset($_POST['plan']) ? strtolower(trim($_POST['plan'])) : 'monthly';
if ($plan !== 'monthly' && $plan !== 'yearly') $plan = 'monthly';

if (!$email) {
    http_response_code(400);
    echo json_encode(['error'=>'Missing or invalid email']);
    exit;
}

// Load price IDs from env
// Read and sanitize price IDs (strip comments/trailing whitespace)
$rawMonthly = getenv('STRIPE_PRICE_MONTHLY') ?: '';
$rawYearly = getenv('STRIPE_PRICE_YEARLY') ?: '';
$priceMonthly = preg_split('/\s+/', trim($rawMonthly))[0] ?: null;
$priceYearly = preg_split('/\s+/', trim($rawYearly))[0] ?: null;
$stripeSecret = getenv('STRIPE_SECRET') ?: null;
$siteUrl = rtrim(getenv('SITE_URL') ?: '', '/');

if (!$stripeSecret || !$priceMonthly || !$priceYearly || !$siteUrl) {
    http_response_code(500);
    echo json_encode(['error'=>'Server misconfigured']);
    exit;
}

$price = ($plan === 'yearly') ? $priceYearly : $priceMonthly;
// Log request for debugging
@file_put_contents(__DIR__ . '/data/stripe_requests.log', date('c') . " - create-checkout: email={$email} plan={$plan} price={$price}\n", FILE_APPEND);

// Build POST form for Stripe (including metadata so webhook reliably knows the chosen plan)
$post = [
    'mode' => 'subscription',
    'success_url' => $siteUrl . '/?success=1&plan=' . urlencode($plan),
    'cancel_url' => $siteUrl . '/?canceled=1',
    'customer_email' => $email,
    'line_items[0][price]' => $price,
    'line_items[0][quantity]' => 1,
    'allow_promotion_codes' => 'true',
    'metadata[plan]' => $plan,
    'metadata[email]' => $email,
];

$ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer {$stripeSecret}"]);
$res = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($res === false) {
    http_response_code(502);
    error_log('Stripe request failed: ' . $err);
    echo json_encode(['error'=>'Stripe request failed']);
    exit;
}

$j = json_decode($res, true);
if (!$j || ($httpCode < 200 || $httpCode >= 300)) {
    http_response_code(502);
    error_log('Stripe responded with error: ' . $res);
    echo json_encode(['error'=>'Stripe error', 'detail'=>$j]);
    exit;
}

// Return the session object to the client
echo json_encode($j);
exit;
?>
