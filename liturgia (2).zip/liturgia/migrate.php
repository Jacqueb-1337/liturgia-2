<?php
require_once __DIR__ . '/db.php';
$pdo = get_db();
$driver = getenv('DB_DRIVER') ?: (getenv('DB_HOST') ? 'mysql' : 'sqlite');

if ($driver === 'mysql') {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) UNIQUE,
        stripe_customer_id VARCHAR(255),
        active TINYINT(1) DEFAULT 0,
        plan VARCHAR(100),
        expires_at INT,
        created_at INT DEFAULT (UNIX_TIMESTAMP())
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS stripe_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        event_id VARCHAR(255) UNIQUE,
        processed_at INT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS magic_links (
        token VARCHAR(64) PRIMARY KEY,
        email VARCHAR(255),
        expires_at INT,
        used TINYINT(1) DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Relay tables for cloud sync
    $pdo->exec("CREATE TABLE IF NOT EXISTS relay_sessions (
        session_id VARCHAR(64) PRIMARY KEY,
        email VARCHAR(255),
        device_name VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS relay_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id VARCHAR(64),
        direction VARCHAR(20),
        message LONGTEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        delivered_at TIMESTAMP NULL,
        INDEX idx_session (session_id),
        FOREIGN KEY (session_id) REFERENCES relay_sessions(session_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS relay_state (
        session_id VARCHAR(64) PRIMARY KEY,
        state LONGTEXT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES relay_sessions(session_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS relay_magic_links (
        token VARCHAR(64) PRIMARY KEY,
        email VARCHAR(255),
        expires_at INT,
        used_at INT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

} else {
    // SQLite
    // Some SQLite builds do not support expression defaults (strftime etc). Use a constant default and set timestamps in code instead.
    $pdo->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, stripe_customer_id TEXT, active INTEGER DEFAULT 0, plan TEXT, expires_at INTEGER, created_at INTEGER DEFAULT 0)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS stripe_events (id INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE, processed_at INTEGER)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS magic_links (token TEXT PRIMARY KEY, email TEXT, expires_at INTEGER, used INTEGER DEFAULT 0)');
    
    // Relay tables for cloud sync
    $pdo->exec('CREATE TABLE IF NOT EXISTS relay_sessions (session_id TEXT PRIMARY KEY, email TEXT, device_name TEXT, created_at INTEGER DEFAULT 0, last_seen INTEGER DEFAULT 0)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS relay_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, direction TEXT, message TEXT, created_at INTEGER DEFAULT 0, delivered_at INTEGER NULL, FOREIGN KEY (session_id) REFERENCES relay_sessions(session_id))');
    $pdo->exec('CREATE TABLE IF NOT EXISTS relay_state (session_id TEXT PRIMARY KEY, state TEXT, last_updated INTEGER DEFAULT 0, FOREIGN KEY (session_id) REFERENCES relay_sessions(session_id))');
    $pdo->exec('CREATE TABLE IF NOT EXISTS relay_magic_links (token TEXT PRIMARY KEY, email TEXT, expires_at INTEGER, used_at INTEGER NULL)');
}

echo "Migration complete\n";
?>