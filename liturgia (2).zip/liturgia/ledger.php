<?php
// Ledger product page
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Liturgia Ledger: Church Event and Attendance Tracking App</title>
  <meta name="description" content="Liturgia Ledger is a desktop app for church administrators. Track event attendance with barcode scan check-in, manage rooms and finances, and export full reports to Excel or CSV.">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://jacqueb.me/liturgia/ledger.php">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Liturgia">
  <meta property="og:url" content="https://jacqueb.me/liturgia/ledger.php">
  <meta property="og:title" content="Liturgia Ledger: Church Event and Attendance Tracking App">
  <meta property="og:description" content="Liturgia Ledger is a desktop app for church administrators. Track event attendance with barcode scan check-in, manage rooms and finances, and export full reports to Excel or CSV.">
  <meta property="og:image" content="https://jacqueb.me/liturgia/logo.png">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Liturgia Ledger: Church Event and Attendance Tracking App">
  <meta name="twitter:description" content="Liturgia Ledger is a desktop app for church administrators. Track event attendance with barcode scan check-in, manage rooms and finances, and export full reports to Excel or CSV.">
  <script type="application/ld+json">{"@context":"https://schema.org","@type":"SoftwareApplication","name":"Liturgia Ledger","applicationCategory":"BusinessApplication","operatingSystem":"Windows, macOS, Linux","description":"A desktop app for church administrators. Track event attendance with barcode scan check-in, manage rooms and finances, and export full reports to Excel or CSV.","url":"https://jacqueb.me/liturgia/ledger.php","downloadUrl":"https://jacqueb.me/liturgia/download-ledger.php"}</script>
  <link rel="stylesheet" href="/liturgia/style.css">
  <link rel="stylesheet" href="/liturgia/style-small.css">
  <link rel="icon" href="/liturgia/logo.png" type="image/png">
</head>
<body class="dark">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia" class="brand-logo"/>
        <span class="product">Liturgia <span class="product-sub">• Ledger</span></span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      <nav class="nav">
        <a href="/liturgia/index.php">Home</a>
        <a href="/liturgia/pricing.php">Pricing</a>
        <a href="/liturgia/account.php">Account</a>
        <a href="/liturgia/download.php">Download</a>
        <a href="/liturgia/apps.php">Apps</a>
      </nav>
    </div>
  </header>

  <main class="hero">
    <div class="container center">
      <h1>Liturgia <span style="font-weight:400;opacity:0.7">&bull; Ledger</span></h1>
      <p class="lede">Track attendance, rooms, and finances for your church events. Check people in with a barcode scan and know exactly who is there.</p>
      <div class="actions">
        <a class="btn primary" href="#download">Download the App</a>
        <a class="btn" href="/liturgia/apps.php">All Apps</a>
      </div>
    </div>
  </main>

  <section class="feature-showcase">
    <div class="container">
      <h2>Everything your event team needs</h2>
      <p class="section-lede">Built for church administrators running conferences, retreats, revivals, and weekly services.</p>
      <div class="feature-grid">

        <div class="feature-card feature-card--highlight">
          <span class="feature-tag">Standout feature</span>
          <h3>Check in by scan</h3>
          <p>Put a barcode scanner on the welcome table. Scan a member ID or printed code and the person is checked in instantly. No searching, no typing. Works for hundreds of people in a short time.</p>
        </div>

        <div class="feature-card">
          <h3>Event management</h3>
          <p>Create events for retreats, conferences, revival services, camp-outs, or anything else your church runs. Each event has its own attendee list, rooms, and finances.</p>
        </div>

        <div class="feature-card">
          <h3>Room assignment</h3>
          <p>Add lodging rooms, set capacity, and assign attendees with a click. See at a glance which rooms are full, which have space, and who is in each one.</p>
        </div>

        <div class="feature-card">
          <h3>Ticket and payment tracking</h3>
          <p>See who has paid before the event starts. Mark ticket fees and room deposits as paid or outstanding per attendee.</p>
        </div>

        <div class="feature-card">
          <h3>Purchases and merchandise</h3>
          <p>Attach purchases to each attendee: meals, books, shirts, whatever you sell. Track what has been collected and what is still owed.</p>
        </div>

        <div class="feature-card">
          <h3>Church directory</h3>
          <p>Keep a directory of every church with contact info and a member list. Add attendees directly from the directory so you are not typing the same names twice.</p>
        </div>

        <div class="feature-card">
          <h3>Export to Excel or CSV</h3>
          <p>Download a full event report in one click: attendees, check-in status, room assignments, and purchase totals as a .xlsx or .csv file.</p>
        </div>

      </div>
    </div>
  </section>

  <section class="ledger-download" id="download">
    <div class="container center">
      <h2>Download Liturgia &bull; Ledger</h2>
      <p class="section-lede">Available for Windows, macOS, and Linux. Uses your existing Liturgia account.</p>
      <div class="download-grid" style="margin-top:28px;justify-content:center;">

        <a class="btn download-btn" href="/liturgia/download-ledger.php?platform=windows" aria-label="Download for Windows">
          <span class="download-icon" aria-hidden="true">
            <svg class="download-logo" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="img">
              <path d="M3 3h8v8H3zM13 3h8v8h-8zM3 13h8v8H3zM13 13h8v8h-8z" fill="currentColor"/>
            </svg>
          </span>
          <span class="download-label">Windows</span>
        </a>

        <a class="btn download-btn" href="/liturgia/download-ledger.php?platform=mac" aria-label="Download for macOS">
          <span class="download-icon" aria-hidden="true">
            <img class="download-logo" src="https://cdn.simpleicons.org/apple/ffffff" alt="Apple logo"/>
          </span>
          <span class="download-label">macOS</span>
        </a>

        <a class="btn download-btn" href="/liturgia/download-ledger.php?platform=linux-appimage" aria-label="Download for Linux (AppImage)">
          <span class="download-icon" aria-hidden="true">
            <img class="download-logo" src="https://cdn.simpleicons.org/linux/ffffff" alt="Linux logo"/>
          </span>
          <span class="download-label">Linux (AppImage)</span>
        </a>

        <a class="btn download-btn" href="/liturgia/download-ledger.php?platform=linux-deb" aria-label="Download for Linux (.deb)">
          <span class="download-icon" aria-hidden="true">
            <img class="download-logo" src="https://cdn.simpleicons.org/debian/ffffff" alt="Debian logo"/>
          </span>
          <span class="download-label">Linux (.deb)</span>
        </a>

      </div>
      <p class="muted" style="margin-top:18px;">Or view the <a href="https://github.com/Jacqueb-1337/liturgia-ledger/releases/latest" target="_blank">release page on GitHub</a>.</p>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <small>&copy; Liturgia &bull; Worship</small>
    </div>
  </footer>

<script>
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>
</body>
</html>
