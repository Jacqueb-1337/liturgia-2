Liturgia License Backend (Stripe + PHP)

Overview
- Minimal self-hosted licensing server using Stripe Checkout + webhooks.
- Auth via magic-link (email). License status stored in SQLite for simplicity.

Quick deploy steps
1. Upload this `liturgia/` directory to your host (e.g., `/httpdocs/liturgia`).
2. Copy `.env.example` to `.env` and set values (Stripe keys, SITE_URL, JWT_SECRET).
3. Install dependencies locally with `composer install` and upload `vendor/` if your host doesn't have composer:
   - composer install --no-dev --optimize-autoloader
4. Run migration once to create the DB:
   - php migrate.php
5. Add a Stripe Product & Price for monthly/yearly; set `STRIPE_PRICE_MONTHLY` and `STRIPE_PRICE_YEARLY` in `.env`.
6. Set Stripe webhook URL to `https://yourdomain.com/licenses/webhook.php` and copy webhook secret to `STRIPE_WEBHOOK_SECRET`.
Security: After you run `admin/init.php` to finalize initialization, DELETE `admin/init.php` from the server (or rename it) to avoid accidental reuse.
API Endpoints
- POST /create-checkout-session.php {email} => {url}
- POST /auth/magic-link.php {email} => sends a magic link email
- GET /auth/verify.php?token=... => returns JWT on success
- GET /license-status.php (Authorization: Bearer <JWT>) => { active, plan, expires_at }
- POST /webhook.php => Stripe webhook (signature verified)

Security notes
- Keep `.env` out of webroot or protected. Use HTTPS. Rotate secrets if exposed.

Web UI
- `index.php` provides a simple web UI where users can request a magic link, paste a token, view account details, open the Stripe Customer Portal, and (future) download the client.

Post-init cleanup
- After running `admin/init.php` to finish initial configuration, DELETE or rename `admin/init.php` to prevent accidental reuse.

Client integration
- The Electron app can be configured to request a magic-link or use the token to call `license-status.php` and `create-portal-session.php`. The repository includes client-side code that stores the JWT in `keytar` and shows an Account modal in the app.

Electron dev notes
- `keytar` is a native module and must be built for Electron. If you see `Cannot find module 'keytar'` or a crash in the renderer, try:
  1) Install deps: `npm install` (or `npm ci`).
  2) Rebuild native modules for Electron: `npx electron-rebuild -f -w keytar` (or use the NPM script `npm run rebuild-native`).
  3) If you can't rebuild on your machine, the app will fallback to an in-memory stub (no secure storage) to allow development — see `renderer.js` for the fallback warning. For production builds, ensure `keytar` is correctly rebuilt so tokens are stored securely.

If you want, I can add a small helper script to automate rebuilds on your machine. (Recommended before packaging the app with `electron-builder`).