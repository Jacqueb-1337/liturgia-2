<?php
// get-user.php
// Usage: https://<site>/liturgia/get-user.php?secret=INIT_SECRET&email=... OR &cid=...
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
$secret = getenv('INIT_SECRET') ?: null;
$provided = $_GET['secret'] ?? null;
if (!$provided || !$secret || $provided !== $secret) {
    http_response_code(403);
    echo json_encode(['error'=>'forbidden']);
    exit;
}
$email = $_GET['email'] ?? null;
$cid = $_GET['cid'] ?? null; // note: intentionally named to support cid
$log = __DIR__ . '/data/stripe_webhook.log';
try {
    $pdo = get_db();
    if ($email) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :e LIMIT 1');
        $stmt->execute([':e'=>$email]);
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['ok'=>true,'user'=>$r]);
        exit;
    }
    if ($cid) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE stripe_customer_id = :cid LIMIT 1');
        $stmt->execute([':cid'=>$cid]);
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['ok'=>true,'user'=>$r]);
        exit;
    }
    http_response_code(400); echo json_encode(['error'=>'missing email or cid']); exit;
} catch (Exception $e) {
    @file_put_contents($log, date('c') . " - get-user: DB error: " . $e->getMessage() . "\n", FILE_APPEND);
    http_response_code(500); echo json_encode(['error'=>'db','detail'=>$e->getMessage()]); exit;
}
?>