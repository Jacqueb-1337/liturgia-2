<?php
// Simple diagnostic script to check license/user data
// Uses same db.php connection as the rest of the site

require __DIR__.'/db.php';

echo "<h2>License Diagnostic</h2>";

try {
    $conn = get_db();
    echo "<p>Connected to database successfully</p>";
    
    // List all tables
    echo "<h3>Database Tables</h3>";
    $stmt = $conn->query("SELECT name FROM sqlite_master WHERE type='table' UNION SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<pre>";
    print_r($tables);
    echo "</pre>";
    
    // Check user by email
    echo "<h3>User by Email: leeschapelsandtown@gmail.com</h3>";
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute(['leeschapelsandtown@gmail.com']);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($rows) {
        foreach ($rows as $row) {
            echo "<pre>";
            print_r($row);
            echo "</pre>";
        }
    } else {
        echo "<p style='color:red;'>No user found with that email</p>";
    }
    
    // Search for partial email match
    echo "<h3>Users matching 'lee' or 'sandtown'</h3>";
    $stmt = $conn->prepare("SELECT id, email FROM users WHERE email LIKE ? OR email LIKE ? LIMIT 5");
    $stmt->execute(['%lee%', '%sandtown%']);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($rows) {
        echo "<table border='1' cellpadding='10'>";
        foreach ($rows as $row) {
            echo "<tr><td>" . htmlspecialchars($row['id']) . "</td><td>" . htmlspecialchars($row['email']) . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No matches found</p>";
    }
    
    // Show all recent users
    echo "<h3>Most Recent Users (last 20)</h3>";
    $stmt = $conn->prepare("SELECT id, email, plan, active, created_at FROM users ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($rows) {
        echo "<table border='1' cellpadding='10'>";
        echo "<tr><th>ID</th><th>Email</th><th>Plan</th><th>Active</th><th>Created</th></tr>";
        foreach ($rows as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
            echo "<td>" . htmlspecialchars($row['plan'] ?? 'N/A') . "</td>";
            echo "<td>" . ($row['active'] ? 'Yes' : 'No') . "</td>";
            echo "<td>" . htmlspecialchars($row['created_at'] ?? 'N/A') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    $conn = null;
} catch (Exception $e) {
    echo "Error: " . htmlspecialchars($e->getMessage());
}
?>


