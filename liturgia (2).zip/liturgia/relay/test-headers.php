<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$headers = [];
foreach ($_SERVER as $key => $value) {
    if (substr($key, 0, 5) === 'HTTP_') {
        $header = str_replace(' ','-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
        $headers[$header] = $value;
    }
}

echo json_encode([
    'ok' => true,
    'http_authorization' => $_SERVER['HTTP_AUTHORIZATION'] ?? null,
    'all_headers' => $headers,
    'getallheaders' => function_exists('getallheaders') ? getallheaders() : 'not available'
]);
