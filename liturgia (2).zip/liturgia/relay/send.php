<?php
// Send a message through the relay
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../db.php';

try {
    $email = require_auth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $sessionId = $input['session_id'] ?? null;
    $direction = $input['direction'] ?? null; // 'to_mobile' or 'to_desktop'
    $message = $input['message'] ?? null;
    
    if (!$sessionId || !$direction || !$message) {
        throw new Exception('Missing required fields');
    }
    
    if (!in_array($direction, ['to_mobile', 'to_desktop'])) {
        throw new Exception('Invalid direction');
    }
    
    $pdo = get_db();
    
    // Verify session belongs to this user
    $stmt = $pdo->prepare("SELECT email FROM relay_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session || $session['email'] !== $email) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Store message
    $stmt = $pdo->prepare("INSERT INTO relay_messages (session_id, direction, message, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$sessionId, $direction, json_encode($message)]);
    
    echo json_encode([
        'ok' => true,
        'message_id' => $pdo->lastInsertId()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
