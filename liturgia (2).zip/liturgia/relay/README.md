# Liturgia Cloud Relay

Long-polling relay server for Liturgia remote control. Works from anywhere without port forwarding.

## Setup

1. Initialize database tables:
   ```
   Visit: https://jacqueb.me/liturgia/relay/init-db.php
   ```

2. Database tables created:
   - `relay_sessions` - Active desktop sessions
   - `relay_messages` - Commands/responses between clients

## API Endpoints

### Authentication
All endpoints require JWT token from existing Liturgia account system.

Send token via:
- Bearer token: `Authorization: Bearer <token>`
- Or in POST body: `{"token": "<token>", ...}`

### Desktop Client

**Register Session**
```
POST /liturgia/relay/register.php
Body: {"device_name": "My Desktop"}
Response: {"ok": true, "session_id": "abc123...", "email": "user@example.com"}
```

**Poll for Mobile Commands**
```
POST /liturgia/relay/poll.php
Body: {"session_id": "abc123", "direction": "to_desktop", "last_id": 0}
Response: {"ok": true, "messages": [{"id": 1, "message": {...}, "created_at": "..."}]}
```

**Send Response to Mobile**
```
POST /liturgia/relay/send.php
Body: {"session_id": "abc123", "direction": "to_mobile", "message": {...}}
Response: {"ok": true, "message_id": 1}
```

**Heartbeat (Keep-Alive)**
```
POST /liturgia/relay/heartbeat.php
Body: {"session_id": "abc123"}
Response: {"ok": true}
```

### Mobile Client

**List Desktop Sessions**
```
GET /liturgia/relay/sessions.php
Authorization: Bearer <token>
Response: {"ok": true, "sessions": [{session_id, device_name, last_seen}, ...]}
```

**Send Command to Desktop**
```
POST /liturgia/relay/send.php
Body: {"session_id": "abc123", "direction": "to_desktop", "message": {"type": "NEXT"}}
Response: {"ok": true, "message_id": 1}
```

**Poll for Desktop Responses**
```
POST /liturgia/relay/poll.php
Body: {"session_id": "abc123", "direction": "to_mobile", "last_id": 0}
Response: {"ok": true, "messages": [...]}
```

## Message Flow

1. Desktop registers → gets `session_id`
2. Mobile lists sessions → picks desktop session
3. Mobile sends command → polls for response
4. Desktop polls for commands → processes → sends response
5. Messages auto-expire after 1 hour
6. Sessions auto-expire after 5 minutes idle

## Long Polling

- Poll timeout: 25 seconds
- If no messages, returns empty array
- Desktop/Mobile should immediately re-poll
- Use `last_id` to get only new messages

## Example Message

```json
{
  "type": "NEXT_VERSE",
  "payload": {}
}
```

## Security

- All endpoints require valid JWT authentication
- Sessions belong to authenticated user only
- Can't access other users' sessions/messages
- Auto-cleanup prevents data accumulation
