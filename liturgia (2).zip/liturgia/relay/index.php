<!DOCTYPE html>
<html>
<head>
    <title>Liturgia Relay Status</title>
    <style>
        body { font-family: system-ui; max-width: 800px; margin: 40px auto; padding: 20px; }
        .status { padding: 12px; border-radius: 6px; margin: 10px 0; }
        .ok { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
        pre { background: #f5f5f5; padding: 12px; border-radius: 4px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f5f5f5; font-weight: 600; }
    </style>
</head>
<body>
    <h1>🔗 Liturgia Cloud Relay</h1>
    <p>Long-polling relay server for remote control</p>
    
    <?php
    require_once __DIR__ . '/../db.php';
    
    try {
        $pdo = get_db();
        
        // Check if tables exist
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        
        if ($driver === 'mysql') {
            $stmt = $pdo->query("SHOW TABLES LIKE 'relay_sessions'");
            $hasSessions = $stmt->rowCount() > 0;
            $stmt = $pdo->query("SHOW TABLES LIKE 'relay_messages'");
            $hasMessages = $stmt->rowCount() > 0;
        } else {
            $stmt = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='relay_sessions'");
            $hasSessions = $stmt->rowCount() > 0;
            $stmt = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='relay_messages'");
            $hasMessages = $stmt->rowCount() > 0;
        }
        
        if ($hasSessions && $hasMessages) {
            echo '<div class="status ok">✓ Database tables initialized</div>';
            
            // Get stats
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM relay_sessions");
            $sessionCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM relay_messages WHERE delivered_at IS NULL");
            $pendingCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            echo "<h2>Statistics</h2>";
            echo "<table>";
            echo "<tr><th>Metric</th><th>Value</th></tr>";
            echo "<tr><td>Active Sessions</td><td>$sessionCount</td></tr>";
            echo "<tr><td>Pending Messages</td><td>$pendingCount</td></tr>";
            echo "<tr><td>Database Driver</td><td>$driver</td></tr>";
            echo "</table>";
            
            // Show recent sessions
            if ($sessionCount > 0) {
                echo "<h2>Active Sessions</h2>";
                $stmt = $pdo->query("SELECT session_id, email, device_name, last_seen FROM relay_sessions ORDER BY last_seen DESC LIMIT 10");
                $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "<table>";
                echo "<tr><th>Device</th><th>Email</th><th>Last Seen</th></tr>";
                foreach ($sessions as $s) {
                    $email = htmlspecialchars($s['email']);
                    $device = htmlspecialchars($s['device_name']);
                    $lastSeen = htmlspecialchars($s['last_seen']);
                    echo "<tr><td>$device</td><td>$email</td><td>$lastSeen</td></tr>";
                }
                echo "</table>";
            }
        } else {
            echo '<div class="status error">✗ Database tables not initialized</div>';
            echo '<p>Run <a href="init-db.php">init-db.php</a> to create tables</p>';
        }
        
    } catch (Exception $e) {
        echo '<div class="status error">✗ Database error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
    ?>
    
    <h2>API Endpoints</h2>
    <ul>
        <li><code>POST /liturgia/relay/register.php</code> - Register desktop session</li>
        <li><code>GET  /liturgia/relay/sessions.php</code> - List active sessions</li>
        <li><code>POST /liturgia/relay/send.php</code> - Send message</li>
        <li><code>POST /liturgia/relay/poll.php</code> - Long-poll for messages</li>
        <li><code>POST /liturgia/relay/heartbeat.php</code> - Keep session alive</li>
    </ul>
    
    <p style="color: #888; margin-top: 40px;">
        <a href="README.md">View API Documentation</a>
    </p>
</body>
</html>
