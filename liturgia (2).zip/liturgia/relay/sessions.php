<?php
// Mobile: List active desktop sessions for authenticated user
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../db.php';

try {
    $email = require_auth();
    
    $pdo = get_db();
    
    // Cleanup stale sessions (no heartbeat in 10 minutes)
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'mysql') {
        $pdo->exec("DELETE FROM relay_sessions WHERE last_seen < DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
    } else {
        $pdo->exec("DELETE FROM relay_sessions WHERE last_seen < datetime('now', '-10 minutes')");
    }
    
    // Get active sessions for this user (only show sessions active in last 60 seconds)
    if ($driver === 'mysql') {
        $stmt = $pdo->prepare("SELECT session_id, device_name, last_seen, created_at FROM relay_sessions WHERE email = ? AND last_seen >= DATE_SUB(NOW(), INTERVAL 60 SECOND) ORDER BY last_seen DESC");
    } else {
        $stmt = $pdo->prepare("SELECT session_id, device_name, last_seen, created_at FROM relay_sessions WHERE email = ? AND last_seen >= datetime('now', '-60 seconds') ORDER BY last_seen DESC");
    }
    $stmt->execute([$email]);
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'ok' => true,
        'sessions' => $sessions
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
