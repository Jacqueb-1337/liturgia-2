<?php
// Deregister session (called when desktop app shuts down)
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../db.php';

try {
    $email = require_auth();
    
    $data = get_relay_input();
    
    if (!isset($data['session_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing session_id']);
        exit;
    }
    
    $sessionId = $data['session_id'];
    $pdo = get_db();
    
    // Verify session belongs to authenticated user
    $stmt = $pdo->prepare("SELECT email FROM relay_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session || $session['email'] !== $email) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Delete the session (orphan any pending messages)
    $stmt = $pdo->prepare("DELETE FROM relay_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    
    echo json_encode([
        'ok' => true,
        'message' => 'Session deregistered'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
