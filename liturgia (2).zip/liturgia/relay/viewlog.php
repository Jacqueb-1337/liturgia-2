<?php
// Quick diagnostic - view relay auth log
header('Content-Type: text/plain');

$logfile = __DIR__ . '/../data/relay_auth.log';

if (file_exists($logfile)) {
    echo "=== Last 50 lines of relay_auth.log ===\n\n";
    $lines = file($logfile);
    echo implode('', array_slice($lines, -50));
} else {
    echo "Log file not found at: $logfile\n";
}
