<?php
// Validate magic link token for relay
error_reporting(E_ALL);
ini_set('display_errors', '0');
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Server error: ' . $errstr]);
    exit;
});

set_exception_handler(function($e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Exception: ' . $e->getMessage()]);
    exit;
});

require_once __DIR__ . '/../../helpers.php';
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth/db.php';
require_once __DIR__ . '/../cors.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$token = $input['token'] ?? null;

if (!$token) {
    http_response_code(400);
    echo json_encode(['error' => 'No token provided']);
    exit;
}

try {
    $pdo = get_db();
    
    // First try as a magic link token
    $stmt = $pdo->prepare("
        SELECT email, expires_at, used_at FROM relay_magic_links 
        WHERE token = ? AND used_at IS NULL
    ");
    $stmt->execute([$token]);
    $magic = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($magic) {
        // Check if token is expired
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        $isMySQL = ($driver === 'mysql');
        
        $expiresTime = strtotime($magic['expires_at']);
        $now = time();
        
        if ($expiresTime > $now) {
            // Token is valid! DON'T mark as used yet - we need it for subsequent requests
            // It will be cleaned up when it expires
            
            http_response_code(200);
            echo json_encode([
                'valid' => true,
                'email' => $magic['email'],
                'type' => 'magic_link'
            ]);
        } else {
            http_response_code(401);
            echo json_encode(['valid' => false, 'error' => 'Token expired']);
        }
        exit;
    }
    
    // Try as JWT
    $payload = jwt_decode_token($token);
    if ($payload && isset($payload['email'])) {
        http_response_code(200);
        echo json_encode([
            'valid' => true,
            'email' => $payload['email'],
            'type' => 'jwt'
        ]);
        exit;
    }
    
    // Try as device token
    try {
        $row = token_row_from_raw($token);
        if ($row && !empty($row['email'])) {
            http_response_code(200);
            echo json_encode([
                'valid' => true,
                'email' => $row['email'],
                'type' => 'device_token'
            ]);
            exit;
        }
    } catch (Exception $e) {
        // Fall through to invalid response
    }
    
    // Token not found or invalid
    http_response_code(401);
    echo json_encode(['valid' => false, 'error' => 'Invalid token']);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
