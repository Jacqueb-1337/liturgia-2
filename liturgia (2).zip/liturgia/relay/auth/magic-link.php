<?php
// Reuse website's auth/magic-link.php - redirect requests there
// This keeps device tokens in a single auth database
require_once __DIR__ . '/../../db.php';
require_once __DIR__ . '/../../auth/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Read email from POST or JSON body
$input = [];
if (!empty($_POST)) {
    $input = $_POST;
} else {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
}

$email = $input['email'] ?? null;

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email']);
    exit;
}

try {
    // Use the same create_token_for() function from auth/db.php
    $result = create_token_for($email, 'Magic link', 'email');
    if (!$result || !isset($result['token'])) {
        throw new Exception('Failed to create token');
    }
    
    $token = $result['token'];
    
    // Send email
    $subject = 'Your Liturgia sign-in link';
    $body = "Sign in to Liturgia:\n\nToken: $token\n\nThis token is persistent and can be revoked from your account.";
    $headers = 'From: no-reply@' . $_SERVER['HTTP_HOST'];
    
    @mail($email, $subject, $body, $headers);
    
    echo json_encode(['ok' => true, 'message' => 'Magic link sent']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
