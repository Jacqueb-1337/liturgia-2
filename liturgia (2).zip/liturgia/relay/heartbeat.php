<?php
// Update session last_seen timestamp (keep-alive)
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../db.php';

try {
    $email = require_auth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $sessionId = $input['session_id'] ?? null;
    
    if (!$sessionId) {
        throw new Exception('Missing session_id');
    }
    
    $pdo = get_db();
    
    // Verify and update
    $stmt = $pdo->prepare("UPDATE relay_sessions SET last_seen = NOW() WHERE session_id = ? AND email = ?");
    $stmt->execute([$sessionId, $email]);
    
    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(['error' => 'Session not found']);
        exit;
    }
    
    echo json_encode(['ok' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
