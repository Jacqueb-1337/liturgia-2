<?php
error_log('[poll.php] START');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { echo '{}'; exit; }

error_log('[poll.php] Before requires');
require_once __DIR__ . '/auth.php';
error_log('[poll.php] After auth');
require_once __DIR__ . '/../db.php';
error_log('[poll.php] After db');

try {
    $email = require_auth();
    error_log('[poll.php] Auth succeeded, email: ' . $email);
    
    $input = get_relay_input();
    error_log('[poll.php] Input: ' . json_encode($input));
    $sessionId = $input['session_id'] ?? null;
    $direction = $input['direction'] ?? null; // 'to_mobile' or 'to_desktop'
    $lastId = $input['last_id'] ?? 0;
    
    error_log('[poll.php] Session ID: ' . ($sessionId ?? 'NULL'));
    error_log('[poll.php] Direction: ' . ($direction ?? 'NULL'));
    
    if (!$sessionId || !$direction) {
        error_log('[poll.php] Missing required fields');
        throw new Exception('Missing required fields');
    }
    
    $pdo = get_db();
    error_log('[poll.php] DB connected');
    
    // Verify session belongs to this user
    $stmt = $pdo->prepare("SELECT email FROM relay_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    error_log('[poll.php] Session lookup result: ' . json_encode($session));
    error_log('[poll.php] Email match: email=' . $email . ', session_email=' . ($session['email'] ?? 'NULL'));
    
    if (!$session || $session['email'] !== $email) {
        error_log('[poll.php] FORBIDDEN - session not found or email mismatch');
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Update last_seen
    $stmt = $pdo->prepare("UPDATE relay_sessions SET last_seen = NOW() WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    
    // Long-poll for up to N seconds (default 3, can be overridden via timeout_seconds parameter)
    // Short timeout ensures rapid state delivery even if no messages are waiting
    $timeoutSeconds = (int)($input['timeout_seconds'] ?? 2);
    if ($timeoutSeconds < 1) $timeoutSeconds = 1;
    if ($timeoutSeconds > 10) $timeoutSeconds = 10;
    
    error_log('[poll.php] Long-poll timeout: ' . $timeoutSeconds . 's');
    $timeout = time() + $timeoutSeconds;
    $messages = [];
    
    while (time() < $timeout && empty($messages)) {
        $stmt = $pdo->prepare("SELECT id, message, created_at FROM relay_messages WHERE session_id = ? AND direction = ? AND id > ? AND delivered_at IS NULL ORDER BY id ASC LIMIT 10");
        $stmt->execute([$sessionId, $direction, $lastId]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($messages)) {
            usleep(250000); // 0.25 second (check every 250ms for faster response)
        }
    }
    
    // Mark messages as delivered
    if (!empty($messages)) {
        $ids = array_column($messages, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("UPDATE relay_messages SET delivered_at = NOW() WHERE id IN ($placeholders)");
        $stmt->execute($ids);
    }
    
    // Decode message JSON
    foreach ($messages as &$msg) {
        $msg['message'] = json_decode($msg['message'], true);
    }
    
    // Get current state for this session
    $stmt = $pdo->prepare("SELECT state FROM relay_state WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $stateRow = $stmt->fetch(PDO::FETCH_ASSOC);
    $state = $stateRow ? json_decode($stateRow['state'], true) : ['bible' => [], 'songs' => [], 'schedule' => [], 'lastUpdated' => time()];
    
    echo json_encode([
        'ok' => true,
        'messages' => $messages,
        'state' => $state
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
