<?php
error_log('[update-state.php] START');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { echo '{}'; exit; }

error_log('[update-state.php] Before requires');
require_once __DIR__ . '/auth.php';
error_log('[update-state.php] After auth');
require_once __DIR__ . '/../db.php';
error_log('[update-state.php] After db');

try {
    
    $email = require_auth();
    error_log('[update-state.php] Auth OK: ' . $email);
    
    $data = get_relay_input();
    error_log('[update-state.php] Input received');
    
    if (empty($data['session_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing session_id']);
        exit;
    }
    
    if (!isset($data['state'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing state']);
        exit;
    }
    
    $sessionId = $data['session_id'];
    $pdo = get_db();
    
    // Verify session (may not exist yet if freshly registered)
    $stmt = $pdo->prepare("SELECT email FROM relay_sessions WHERE session_id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session) {
        // Session doesn't exist - this could happen if registration hasn't created it yet
        error_log('[update-state.php] Session not found - creating...');
        $stmt = $pdo->prepare("INSERT INTO relay_sessions (session_id, email, device_name, created_at, last_seen) VALUES (?, ?, 'Desktop', datetime('now'), datetime('now'))");
        $stmt->execute([$sessionId, $email]);
    } else if ($session['email'] !== $email) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    
    // Store state - just try the simpler SQLite approach
    error_log('[update-state.php] Storing state for ' . $sessionId);
    $stateJson = is_string($data['state']) ? $data['state'] : json_encode($data['state']);
    
    try {
        // Try DELETE and INSERT (simpler than INSERT OR REPLACE which has compatibility issues)
        $pdo->prepare("DELETE FROM relay_state WHERE session_id = ?")->execute([$sessionId]);
        
        // Use current timestamp that works with both MySQL and SQLite
        $now = time();
        $stmt = $pdo->prepare("INSERT INTO relay_state (session_id, state, last_updated) VALUES (?, ?, ?)");
        $stmt->execute([$sessionId, $stateJson, $now]);
        error_log('[update-state.php] State stored successfully');
    } catch (Exception $innerEx) {
        error_log('[update-state.php] Store error: ' . $innerEx->getMessage());
        throw $innerEx;
    }
    
    echo json_encode(['ok' => true]);
    
} catch (Exception $e) {
    error_log('[update-state.php] Exception: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
