<?php
// test-token.php - debug token validation
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../db.php';

header('Content-Type: application/json');

try {
    error_log('[test-token] Starting test');
    
    // Get the authorization header
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
    } else {
        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (substr($key, 0, 5) == 'HTTP_') {
                $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
                $headers[$header] = $value;
            }
        }
    }
    
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    error_log('[test-token] Auth header: ' . substr($auth, 0, 100));
    
    // Test JWT decode
    if (preg_match('/Bearer\s+(.+)/i', $auth, $matches)) {
        $token = $matches[1];
        error_log('[test-token] Token: ' . substr($token, 0, 50) . '...');
        
        // Try JWT decode
        require_once __DIR__ . '/../auth/db.php';
        $payload = decode_jwt_payload($token);
        
        if ($payload) {
            error_log('[test-token] JWT decoded: ' . json_encode($payload));
            echo json_encode([
                'ok' => true,
                'type' => 'jwt',
                'payload' => $payload
            ]);
        } else {
            error_log('[test-token] Token is not valid JWT');
            echo json_encode([
                'ok' => false,
                'error' => 'Invalid JWT',
                'token_parts' => count(explode('.', $token))
            ]);
        }
    } else {
        error_log('[test-token] No Bearer token found');
        echo json_encode(['ok' => false, 'error' => 'No Bearer token']);
    }
} catch (Exception $e) {
    error_log('[test-token] Exception: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
