<?php
// Initialize relay database tables
require_once __DIR__ . '/../db.php';

try {
    $pdo = get_db();
    
    // Detect database type
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $isMySQL = ($driver === 'mysql');
    
    // Table for active sessions (desktop clients)
    if ($isMySQL) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_sessions (
            session_id VARCHAR(64) PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            device_name VARCHAR(255),
            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_email (email),
            INDEX idx_last_seen (last_seen)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            session_id VARCHAR(64) NOT NULL,
            direction VARCHAR(10) NOT NULL,
            message TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            delivered_at DATETIME NULL,
            INDEX idx_session (session_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_state (
            session_id VARCHAR(64) PRIMARY KEY,
            state LONGTEXT NOT NULL,
            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES relay_sessions(session_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        // Cleanup old sessions (>5 minutes idle)
        $pdo->exec("DELETE FROM relay_sessions WHERE last_seen < DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        
        // Cleanup old messages (>1 hour)
        $pdo->exec("DELETE FROM relay_messages WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_sessions (
            session_id VARCHAR(64) PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            device_name VARCHAR(255),
            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_email ON relay_sessions(email)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_last_seen ON relay_sessions(last_seen)");
        
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id VARCHAR(64) NOT NULL,
            direction VARCHAR(10) NOT NULL,
            message TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            delivered_at DATETIME NULL
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_session ON relay_messages(session_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_created ON relay_messages(created_at)");
        
        $pdo->exec("CREATE TABLE IF NOT EXISTS relay_state (
            session_id VARCHAR(64) PRIMARY KEY,
            state TEXT NOT NULL,
            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Cleanup old sessions (>5 minutes idle)
        $pdo->exec("DELETE FROM relay_sessions WHERE last_seen < datetime('now', '-5 minutes')");
        
        // Cleanup old messages (>1 hour)
        $pdo->exec("DELETE FROM relay_messages WHERE created_at < datetime('now', '-1 hour')");
    }
    
    echo "Relay database initialized successfully\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
