<?php
error_log('[register.php] START');
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Auth-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { echo '{}'; exit; }

error_log('[register.php] Before requires');
require_once __DIR__ . '/auth.php';
error_log('[register.php] After auth');
require_once __DIR__ . '/../db.php';
error_log('[register.php] After db');

try {
    error_log('[register.php] Calling require_auth...');
    $email = require_auth();
    error_log('[register.php] Got email: ' . $email);
    
    $input = get_relay_input();
    error_log('[register.php] Input keys: ' . implode(',', array_keys($input)));
    $deviceName = $input['device_name'] ?? 'Desktop';
    error_log('[register.php] Device: ' . $deviceName);
    
    $pdo = get_db();
    error_log('[register.php] Got DB connection');
    $dbType = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    error_log('[register.php] DB type: ' . $dbType);
    
    // Check if there's an existing session for this device
    $stmt = $pdo->prepare("SELECT session_id FROM relay_sessions WHERE email = ? AND device_name = ?");
    $stmt->execute([$email, $deviceName]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing) {
        // Reuse existing session, just update last_seen
        $sessionId = $existing['session_id'];
        error_log('[register.php] Reusing existing session: ' . $sessionId);
        if ($dbType === 'mysql') {
            $stmt = $pdo->prepare("UPDATE relay_sessions SET last_seen = NOW() WHERE session_id = ?");
            $stmt->execute([$sessionId]);
        } else {
            $stmt = $pdo->prepare("UPDATE relay_sessions SET last_seen = ? WHERE session_id = ?");
            $stmt->execute([time(), $sessionId]);
        }
    } else {
        // Create new session
        $sessionId = bin2hex(random_bytes(16));
        error_log('[register.php] Creating new session: ' . $sessionId);
        $now = time();
        if ($dbType === 'mysql') {
            $stmt = $pdo->prepare("INSERT INTO relay_sessions (session_id, email, device_name, created_at, last_seen) VALUES (?, ?, ?, NOW(), NOW())");
            $stmt->execute([$sessionId, $email, $deviceName]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO relay_sessions (session_id, email, device_name, created_at, last_seen) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$sessionId, $email, $deviceName, $now, $now]);
        }
    }
    
    error_log('[register.php] Session created successfully');
    echo json_encode([
        'ok' => true,
        'session_id' => $sessionId,
        'email' => $email
    ]);
    error_log('[register.php] Response sent');
} catch (Exception $e) {
    error_log('[register.php] EXCEPTION: ' . $e->getMessage());
    error_log('[register.php] TRACE: ' . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
