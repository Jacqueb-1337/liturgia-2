<?php
// Test authentication endpoint - logs what we receive
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

// Get Bearer token
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token_from_header = null;
if (preg_match('/Bearer\s+(.+)/i', $auth, $m)) {
    $token_from_header = $m[1];
}

// Get token from POST body
$body = file_get_contents('php://input');
$input = json_decode($body, true) ?? [];
$token_from_body = $input['token'] ?? null;

echo json_encode([
    'header_token' => $token_from_header ? substr($token_from_header, 0, 20) . '...' : null,
    'body_token' => $token_from_body ? substr($token_from_body, 0, 20) . '...' : null,
    'body_raw_length' => strlen($body),
    'request_method' => $_SERVER['REQUEST_METHOD'],
    'auth_header' => $auth ? 'present' : 'missing'
]);
