<?php
// Apps page — lists all Liturgia suite apps
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Liturgia Apps — Church Software for Worship Teams and Administrators</title>
  <meta name="description" content="The Liturgia suite includes Liturgia Worship for Bible verse and song presentations and Liturgia Ledger for church event and attendance management. Focused tools for church teams.">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://jacqueb.me/liturgia/apps.php">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Liturgia">
  <meta property="og:url" content="https://jacqueb.me/liturgia/apps.php">
  <meta property="og:title" content="Liturgia Apps — Church Software for Worship Teams and Administrators">
  <meta property="og:description" content="The Liturgia suite includes Liturgia Worship for Bible verse and song presentations and Liturgia Ledger for church event and attendance management.">
  <meta property="og:image" content="https://jacqueb.me/liturgia/logo.png">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Liturgia Apps — Church Software for Worship Teams and Administrators">
  <meta name="twitter:description" content="The Liturgia suite includes Liturgia Worship for Bible verse and song presentations and Liturgia Ledger for church event and attendance management.">
  <link rel="stylesheet" href="/liturgia/style.css">
  <link rel="stylesheet" href="/liturgia/style-small.css">
  <link rel="icon" href="/liturgia/logo.png" type="image/png">
</head>
<body class="dark">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia" class="brand-logo"/>
        <span class="product">Liturgia <span class="product-sub">• Worship</span></span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      <nav class="nav">
        <a href="/liturgia/index.php">Home</a>
        <a href="/liturgia/pricing.php">Pricing</a>
        <a href="/liturgia/account.php">Account</a>
        <a href="/liturgia/download.php">Download</a>
        <span class="nav-current">Apps</span>
      </nav>
    </div>
  </header>

  <main class="hero">
    <div class="container center">
      <h1>All Apps</h1>
      <p class="lede">The Liturgia suite: calm, focused tools built for church teams.</p>
    </div>
  </main>

  <section class="feature-showcase">
    <div class="container">
      <div class="apps-grid">

        <div class="app-card">
          <div class="app-card-icon">
            <img src="/liturgia/logo.png" alt="Liturgia Worship" class="app-card-logo"/>
          </div>
          <h2 class="app-card-name">Liturgia <span class="product-sub-inline">• Worship</span></h2>
          <p class="app-card-desc">Present Bible verses and worship songs on your screens. Live speech recognition surfaces matching verses as you preach, a mobile remote lets you control slides from anywhere, and a service schedule keeps everything in order.</p>
          <div class="app-card-actions">
            <a class="btn primary" href="/liturgia/index.php">Learn More</a>
            <a class="btn" href="/liturgia/download.php">Download</a>
          </div>
        </div>

        <div class="app-card">
          <div class="app-card-icon app-card-icon--ledger">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
              <rect x="3" y="3" width="22" height="22" rx="5" stroke="currentColor" stroke-width="2"/>
              <path d="M8 10h12M8 14h12M8 18h7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
            </svg>
          </div>
          <h2 class="app-card-name">Liturgia <span class="product-sub-inline">• Ledger</span></h2>
          <p class="app-card-desc">Track attendance, rooms, and finances for every church event. Check people in with a barcode scan, manage your church directory, assign lodging rooms, and export full reports to Excel all in one place.</p>
          <div class="app-card-actions">
            <a class="btn primary" href="/liturgia/ledger.php">Learn More</a>
            <a class="btn" href="/liturgia/ledger.php#download">Download</a>
          </div>
        </div>

      </div>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <small>&copy; Liturgia &bull; Worship</small>
    </div>
  </footer>

<script>
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>
</body>
</html>
