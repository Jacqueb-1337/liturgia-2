// send_webhook.js
// Usage: set WHSEC and URL env vars, then: node send_webhook.js
// Example (Windows PowerShell):
// $env:WHSEC='whsec_ZKr5Fr3V0d9VY7PYlZxWjWrHn3w1xWux'; $env:URL='https://jacqueb.me/liturgia/webhook.php'; node send_webhook.js

const fs = require('fs');
const crypto = require('crypto');
const https = require('https');

const payloadPath = './payload.json';
const webhookUrl = process.env.URL || 'https://jacqueb.me/liturgia/webhook.php';
const whsec = process.env.WHSEC || process.env.STRIPE_WEBHOOK_SECRET || '';

if (!fs.existsSync(payloadPath)) {
  console.error('payload.json not found in the current folder. Save your payload to', payloadPath);
  process.exit(1);
}
if (!whsec) {
  console.error('WHSEC not set. Set environment variable WHSEC to your live signing secret (whsec_...).');
  process.exit(1);
}

const payload = fs.readFileSync(payloadPath, 'utf8');
const ts = Math.floor(Date.now() / 1000).toString();
const signed_payload = ts + '.' + payload;
const signature = crypto.createHmac('sha256', whsec).update(signed_payload).digest('hex');
const sigHeader = `t=${ts},v1=${signature}`;

const url = new URL(webhookUrl);
const options = {
  method: 'POST',
  hostname: url.hostname,
  path: url.pathname + url.search,
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload, 'utf8'),
    'Stripe-Signature': sigHeader
  }
};

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => data += chunk);
  res.on('end', () => {
    console.log('Status:', res.statusCode);
    console.log('Response body:', data);
  });
});
req.on('error', (err) => console.error('Request error:', err.message));
req.write(payload);
req.end();
