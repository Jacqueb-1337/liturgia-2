<?php
require __DIR__.'/../helpers.php';
require __DIR__.'/../db.php';
require_once __DIR__ . '/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$token = $_GET['token'] ?? null;
$source = $_GET['source'] ?? 'web';  // default to web if not specified
if (!$token) { http_response_code(400); echo 'Invalid token'; exit; }

try {
    // Validate the device token (id.secret format) from auth.db
    $pdo_auth = get_db_conn();
    if (!$pdo_auth) throw new Exception('auth DB unavailable');
    
    // Parse token: format is "id.secret"
    @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Verify attempt token={$token}\n", FILE_APPEND);
    
    $token_parts = explode('.', $token);
    if (count($token_parts) !== 2) {
        @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Invalid token format (expected id.secret)\n", FILE_APPEND);
        http_response_code(400);
        echo 'Token invalid or expired';
        exit;
    }
    list($id, $secret) = $token_parts;
    
    // Lookup token in auth.db tokens table
    $stmt = $pdo_auth->prepare('SELECT id, email, token_hash, revoked_at FROM tokens WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$row) {
        @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Token not found in DB\n", FILE_APPEND);
        http_response_code(400);
        echo 'Token invalid or expired';
        exit;
    }
    
    // Check if token is revoked
    if (!empty($row['revoked_at'])) {
        @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Token has been revoked\n", FILE_APPEND);
        http_response_code(400);
        echo 'Token invalid or expired';
        exit;
    }
    
    // Verify the secret matches
    if (!password_verify($secret, $row['token_hash'])) {
        @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Token secret mismatch\n", FILE_APPEND);
        http_response_code(400);
        echo 'Token invalid or expired';
        exit;
    }
    
    $email = $row['email'];
    @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Token validated for email={$email}\n", FILE_APPEND);
    
    // Ensure user exists in main users table
    try {
        $pdo = get_db();
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :e LIMIT 1');
        $stmt->execute([':e' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            // Only grant founder status to first 50 users
            $userCount = 0;
            try {
                $countStmt = $pdo->query('SELECT COUNT(*) as cnt FROM users');
                $countRow = $countStmt->fetch(PDO::FETCH_ASSOC);
                $userCount = intval($countRow['cnt'] ?? 0);
            } catch (Exception $e) {}
            
            $now = time();
            $oneYearLater = $now + (365 * 24 * 60 * 60);
            
            if ($userCount < 50) {
                // First 50 users get founder status with 1 year free
                $ins = $pdo->prepare('INSERT INTO users (email, active, created_at, founder, expires_at) VALUES (:e,1,:created,1,:expires)');
                $ins->execute([':e'=>$email, ':created'=>$now, ':expires'=>$oneYearLater]);
            } else {
                // After 50 users, no access until they pay
                $ins = $pdo->prepare('INSERT INTO users (email, active, created_at) VALUES (:e,0,:created)');
                $ins->execute([':e'=>$email, ':created'=>$now]);
            }
            $id = $pdo->lastInsertId();
        } else {
            $id = $user['id'];
        }

        $payload = ['sub'=>$id, 'email'=>$email, 'iat'=>time(), 'exp'=>time()+3600];
        $jwt = jwt_encode($payload);
    } catch (Exception $e) {
        http_response_code(500);
        $msg = $e->getMessage();
        error_log('Verify error: ' . $msg);
        @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Verify error: " . $msg . "\n", FILE_APPEND);
        if (isset($_GET['debug']) && $_GET['debug'] === '1') echo json_encode(['error'=>$msg]);
        exit;
    }

    // Handle different sources with appropriate redirects
    if ($source === 'app') {
        // Mobile/Desktop app: Show intermediate page that deep links to app
        // Pass the original device token (not JWT) since the app validates device tokens
        $deepLink = 'liturgia://auth?token=' . urlencode($token);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Opening Liturgia App...</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; padding: 40px 20px; text-align: center; background: #f5f5f5; }
                .container { max-width: 400px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
                h2 { color: #0078d4; margin-bottom: 20px; }
                .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #0078d4; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 20px auto; }
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                .button { display: inline-block; background: #0078d4; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 20px; }
                .message { color: #666; margin-top: 15px; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>Opening Liturgia App...</h2>
                <div class="spinner"></div>
                <p class="message">If the app doesn't open automatically, tap the button below:</p>
                <a href="<?php echo htmlspecialchars($deepLink); ?>" class="button">Open Liturgia App</a>
            </div>
            <script>
                // Attempt to open the app immediately
                window.location.href = '<?php echo addslashes($deepLink); ?>';
            </script>
        </body>
        </html>
        <?php
        exit;
    } else if ($source === 'ledger') {
        // Redirect to Liturgia Ledger deep link: liturgia-ledger://auth?token=<jwt>
        $deepLink = 'liturgia-ledger://auth?token=' . urlencode($jwt);
        header('Location: ' . $deepLink);
        exit;
    } else if ($source === 'web') {
        // Web flow: set session cookie and redirect back to account page with token
        // Set secure auth cookie that the website can use
        $cookieExpire = time() + (7 * 24 * 60 * 60); // 7 days
        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        setcookie('auth_token', $jwt, $cookieExpire, '/', '', $isSecure, true);
        
        // Redirect back to account page so it can detect the auth cookie and update UI
        $scheme = $isSecure ? 'https' : 'http';
        $accountUrl = $scheme . '://' . $_SERVER['HTTP_HOST'] . '/liturgia/account.php?auth=success';
        header('Location: ' . $accountUrl);
        exit;
    }

    // Fallback: If requested by browser (HTML), show a friendly page with token and copy button (this is legacy/manual flow)
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    if (strpos($accept, 'text/html') !== false) {
        ?><!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Liturgia Sign-in Token</title>
    <style>body{font-family:Arial,Helvetica,sans-serif;padding:24px;}textarea{width:100%;height:80px;font-size:14px}</style>
  </head>
  <body>
    <h2>Sign-in token</h2>
    <p>Copy the token below and paste it into the Liturgia app's "Enter Token" dialog.</p>
    <textarea id="token" readonly><?php echo htmlspecialchars($jwt); ?></textarea>
    <div style="margin-top:12px;"><button id="copy">Copy to clipboard</button></div>
    <script>
      document.getElementById('copy').onclick = function(){
        const t = document.getElementById('token');
        t.select(); navigator.clipboard.writeText(t.value);
        alert('Token copied to clipboard');
      };
    </script>
  </body>
</html>
<?php
        exit;
    }

    // API response: return JSON
    header('Content-Type: application/json');
    echo json_encode(['token'=>$jwt]);

} catch (Exception $e) {
    http_response_code(500);
    @file_put_contents(__DIR__.'/../data/magic_links.log', date('c') . " - Outer verify exception: " . $e->getMessage() . "\n", FILE_APPEND);
    echo 'Internal server error';
    exit;
}
?>
```