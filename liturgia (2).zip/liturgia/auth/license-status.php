<?php
require_once __DIR__ . '/auth/_helpers.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $token = get_raw_token();
    if (!$token) json_err(401, 'no token');
    // defensive: predefine $pdo for legacy code paths and support debug
    $pdo = null;
    $debug = !empty($_REQUEST['debug']);
    if ($debug) {
        @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - license-status debug request token_present=" . ($token ? '1' : '0') . " headers=" . json_encode(getallheaders()) . " GET=" . json_encode($_GET) . " POST=" . json_encode($_POST) . "\n", FILE_APPEND);
    }

    // First, attempt to decode JWT and return best-effort status
    $payload = decode_jwt_payload($token);
    if ($payload && ( !empty($payload['email']) || !empty($payload['sub']) )) {
        $ident = !empty($payload['email']) ? $payload['email'] : $payload['sub'];
        $status = [ 'email' => is_string($ident) ? $ident : null, 'plan' => 'token', 'active' => true ];
        if (!empty($payload['exp'])) $status['expires_at'] = intval($payload['exp']);
        // Try to enrich from DB, if available, but be defensive to avoid 500s
        try {
            // central DB preferred
            try {
                require_once __DIR__ . '/db.php';
                $pdoMain = get_db();
            } catch (Exception $e) { $pdoMain = null; }
            if ($pdoMain && $ident) {
                if (is_numeric($ident)) {
                    $stmt = $pdoMain->prepare('SELECT plan,expires_at,active,founder FROM users WHERE id = :id LIMIT 1');
                    $stmt->execute([':id' => intval($ident)]);
                } else {
                    $stmt = $pdoMain->prepare('SELECT plan,expires_at,active,founder FROM users WHERE email = :email LIMIT 1');
                    $stmt->execute([':email' => $ident]);
                }
                $u = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($u) {
                    if (!empty($u['plan'])) $status['plan'] = $u['plan'];
                    $status['active'] = !empty($u['active']);
                    if (!empty($u['expires_at'])) $status['expires_at'] = intval($u['expires_at']);
                    if (!empty($u['founder'])) $status['founder'] = true;
                }
            }

            // fallback helpers
            if (is_numeric($ident) && function_exists('query_licenses_user_by_uid')) {
                $dbRow = query_licenses_user_by_uid(intval($ident));
            } elseif (function_exists('query_licenses_user_by_email')) {
                $dbRow = query_licenses_user_by_email($ident);
            } else {
                $dbRow = false;
            }
            if ($dbRow) {
                if (!empty($dbRow['plan'])) $status['plan'] = $dbRow['plan'];
                $status['active'] = !empty($dbRow['active']);
                if (!empty($dbRow['expires_at'])) $status['expires_at'] = intval($dbRow['expires_at']);
                if (!empty($dbRow['founder'])) $status['founder'] = true;
            }
        } catch (Exception $e) {
            error_log('license-status DB enrich error: ' . $e->getMessage());
        }
        // fallback: check tokens.json for founder flag
        echo json_encode($status);
        exit;
    }

    // Not a JWT: attempt to find persistent token in tokens.json
    // First try auth DB token lookup if available
    // Defensive: define $pdo for older deployments that may reference it directly
    $pdo = null;
    try {
        require_once __DIR__ . '/db.php';
        $pdo = get_db();
    } catch (Exception $e) { $pdo = null; }

    $deviceRow = false;
    try {
        if (file_exists(__DIR__ . '/auth/db.php')) {
            require_once __DIR__ . '/auth/db.php';
            if (function_exists('token_row_from_raw')) {
                $deviceRow = token_row_from_raw($token);
            }
        }
    } catch (Exception $e) { error_log('license-status token lookup error: ' . $e->getMessage()); }

    if ($deviceRow) {
        $identifier = !empty($deviceRow['email']) ? $deviceRow['email'] : (!empty($deviceRow['uid']) ? $deviceRow['uid'] : ($deviceRow['user_id'] ?? null));
        $status = ['email' => is_string($identifier) ? $identifier : null, 'plan' => ($deviceRow['plan'] ?? 'token'), 'active' => true];
        try {
            require_once __DIR__ . '/db.php';
            $pdoMain = get_db();
            if ($pdoMain && $identifier) {
                if (is_numeric($identifier)) {
                    $stmt = $pdoMain->prepare('SELECT plan,expires_at,active,founder FROM users WHERE id = :id LIMIT 1');
                    $stmt->execute([':id' => intval($identifier)]);
                } else {
                    $stmt = $pdoMain->prepare('SELECT plan,expires_at,active,founder FROM users WHERE email = :email LIMIT 1');
                    $stmt->execute([':email' => $identifier]);
                }
                $u = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($u) {
                    if (!empty($u['plan'])) $status['plan'] = $u['plan'];
                    $status['active'] = !empty($u['active']);
                    if (!empty($u['expires_at'])) $status['expires_at'] = intval($u['expires_at']);
                    if (!empty($u['founder'])) $status['founder'] = true;
                }
            }
        } catch (Exception $e) { error_log('license-status DB enrich error: ' . $e->getMessage()); }
        echo json_encode($status);
        exit;
    }

    $all = load_tokens();
    foreach ($all as $t) {
        if (!empty($t['token']) && hash_equals($t['token'], $token)) {
            $status = ['email' => $t['email'] ?? null, 'plan' => ($t['plan'] ?? 'token'), 'active' => true, 'expires_at' => ($t['expires_at'] ?? null)];
            echo json_encode($status);
            exit;
        }
    }

    json_err(401, 'invalid token');
} catch (Throwable $th) {
    error_log('license-status top error: ' . $th->getMessage());
    @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - license-status top error: " . $th->getMessage() . "\n", FILE_APPEND);
    json_err(500, 'internal error');
}
