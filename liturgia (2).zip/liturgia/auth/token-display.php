<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Liturgia Token</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      padding: 40px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }
    h1 {
      color: #333;
      margin-bottom: 20px;
      font-size: 28px;
    }
    .token-box {
      background: #f5f5f5;
      border: 2px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      margin: 20px 0;
      word-break: break-all;
      font-family: 'Courier New', monospace;
      font-size: 14px;
      color: #333;
      user-select: all;
    }
    .copy-btn {
      background: #0078d4;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      transition: background 0.2s;
    }
    .copy-btn:hover {
      background: #005a9e;
    }
    .copy-btn:active {
      transform: scale(0.98);
    }
    .success {
      color: #107c10;
      margin-top: 10px;
      font-weight: 500;
      display: none;
    }
    .instructions {
      color: #666;
      font-size: 14px;
      margin-top: 20px;
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Your Liturgia Token</h1>
    <p style="color: #666; margin-bottom: 20px;">Copy this token and paste it into the Liturgia app:</p>
    <div class="token-box" id="tokenBox"><?php echo htmlspecialchars($_GET['token'] ?? 'No token provided'); ?></div>
    <button class="copy-btn" onclick="copyToken()">Copy Token</button>
    <div class="success" id="successMsg">Token copied to clipboard!</div>
    <div class="instructions">
      Open Liturgia, go to Settings > Account, and paste this token in the "Sign-in Token" field.
    </div>
  </div>
  
  <script>
    function copyToken() {
      const tokenBox = document.getElementById('tokenBox');
      const text = tokenBox.textContent;
      
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
          showSuccess();
        }).catch(() => {
          fallbackCopy(text);
        });
      } else {
        fallbackCopy(text);
      }
    }
    
    function fallbackCopy(text) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        showSuccess();
      } catch (err) {
        alert('Please manually select and copy the token');
      }
      document.body.removeChild(textarea);
    }
    
    function showSuccess() {
      const msg = document.getElementById('successMsg');
      msg.style.display = 'block';
      setTimeout(() => {
        msg.style.display = 'none';
      }, 3000);
    }
  </script>
</body>
</html>
