<?php
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';
// Temporary debug logging when ?debug=1 is provided
$__debug = !empty($_REQUEST['debug']);
if ($__debug) {
    @file_put_contents(__DIR__ . '/../data/auth.log', date('c') . " - show-token debug: headers=" . json_encode(getallheaders()) . " GET=" . json_encode($_GET) . " POST=" . json_encode($_POST) . "\n", FILE_APPEND);
}

function getBearerToken(){
  $hdr = null;
  foreach (getallheaders() as $k=>$v) { if (strtolower($k) === 'authorization') { $hdr = $v; break; } }
  if ($hdr && preg_match('/Bearer\s+(\S+)/', $hdr, $m)) return $m[1];
  if (!empty($_POST['token'])) return $_POST['token'];
  if (!empty($_GET['token'])) return $_GET['token'];
  return null;
}

$auth = getBearerToken();
@file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - show-token called id=" . ($_GET['id'] ?? '') . " bearer=" . ($auth ? '1' : '0') . "\n", FILE_APPEND);
if (!$auth) { http_response_code(401); echo json_encode(['error'=>'no-token']); exit; }
$email = email_from_auth_token($auth);
if (!$email) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - show-token auth-invalid token_present=1\n", FILE_APPEND); http_response_code(401); echo json_encode(['error'=>'invalid-token']); exit; }
$id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$id) { http_response_code(400); echo json_encode(['error'=>'missing-id']); exit; }
// Attempt to reveal the token if it hasn't been revealed yet and caller is authorized
$revealed = reveal_token_by_id($email, $id);
if ($revealed) {
  // Log a short, non-sensitive preview for diagnostics (do NOT write full token)
  $preview = substr($revealed, 0, 24);
  $startsWithDot = (substr($revealed,0,1) === '.') ? 1 : 0;
  @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - show-token revealed id={$id} owner={$email} preview={$preview} starts_with_dot={$startsWithDot}\n", FILE_APPEND);
  echo json_encode(['ok'=>true,'token'=>$revealed]);
} else {
  // log failure detail: see if token row exists and who owns it
  $pdo = get_db_conn();
  $row = null;
  try {
    $stmt = $pdo->prepare('SELECT id,email,raw_secret,revealed_at FROM tokens WHERE id = :id LIMIT 1');
    $stmt->execute([':id'=>$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
  } catch (Exception $e) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - show-token db-error id={$id} msg=" . $e->getMessage() . "\n", FILE_APPEND); }
  if ($row) {
    @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - show-token failure id={$id} owner_db={$row['email']} caller={$email} revealed_at=" . ($row['revealed_at']?:'') . " raw_present=" . (!empty($row['raw_secret'])?'1':'0') . "\n", FILE_APPEND);
    if ($row['email'] !== $email) {
      http_response_code(401);
      echo json_encode(['error'=>'unauthorized','message'=>'caller does not own token']);
      exit;
    }
    // Owner but already revealed or raw secret missing
    http_response_code(403);
    echo json_encode(['error'=>'token_not_retrievable','message'=>'Token already revealed and raw secret removed']);
    exit;
  }
  // not found
  http_response_code(404);
  echo json_encode(['error'=>'not_found']);
}
