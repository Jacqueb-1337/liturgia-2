<?php
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';
// Log every request (informational) so we can see if Authorization header is present
$hdrs = function_exists('getallheaders') ? getallheaders() : [];
@file_put_contents(__DIR__ . '/../data/auth.log', date('c') . " - list-tokens request: auth=" . (!empty($hdrs['Authorization']) || !empty($hdrs['authorization']) ? '1' : '0') . " GET=" . json_encode(array_keys($_GET)) . " POST=" . json_encode(array_keys($_POST)) . "\n", FILE_APPEND);
// Temporary debug logging when ?debug=1 is provided
$__debug = !empty($_REQUEST['debug']);
if ($__debug) {
    @file_put_contents(__DIR__ . '/../data/auth.log', date('c') . " - list-tokens debug: headers=" . json_encode($hdrs) . " GET=" . json_encode($_GET) . " POST=" . json_encode($_POST) . "\n", FILE_APPEND);
}
function getBearerToken(){
  $hdr = null;
  foreach (getallheaders() as $k=>$v) { if (strtolower($k) === 'authorization') { $hdr = $v; break; } }
  if ($hdr && preg_match('/Bearer\s+(\S+)/', $hdr, $m)) return $m[1];
  if (!empty($_POST['token'])) return $_POST['token'];
  if (!empty($_GET['token'])) return $_GET['token'];
  return null;
}

$auth = getBearerToken();
@file_put_contents(__DIR__ . '/../data/auth.log', date('c') . " - list-tokens token_present=" . ($auth ? '1' : '0') . "\n", FILE_APPEND);
if (!$auth) { http_response_code(401); echo json_encode(['error'=>'no-token']); exit; }

// Try to get email from the token (works for both JWT and device tokens)
$email = null;

// First, try JWT decode
$payload = decode_jwt_payload($auth);
if ($payload && !empty($payload['email'])) {
  $email = $payload['email'];
}

// If not a JWT, try device token lookup
if (!$email) {
  $email = email_from_auth_token($auth);
}

if (!$email) { http_response_code(401); echo json_encode(['error'=>'invalid-token']); exit; }

// Now fetch all tokens for this email
$tokens = list_tokens_for($email);
echo json_encode(['tokens'=>$tokens]);
