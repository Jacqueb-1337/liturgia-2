<?php
// global handlers for diagnostics (install first so we catch include-time failures)
set_exception_handler(function($e){ @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - magic-link uncaught exception: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'internal']); exit; });
register_shutdown_function(function(){ $err = error_get_last(); if ($err) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - magic-link shutdown error: " . json_encode($err) . "\n", FILE_APPEND); if (!headers_sent()) header('Content-Type: application/json', true, 500); echo json_encode(['ok'=>false,'error'=>'fatal','message'=>$err['message']]); } });

// CORS headers for mobile app access
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// log the incoming request for diagnostics
@file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - magic-link request: method=" . $_SERVER['REQUEST_METHOD'] . " GET=" . json_encode($_GET) . " POST=" . json_encode($_POST) . " raw=" . substr(file_get_contents('php://input'),0,500) . "\n", FILE_APPEND);
require_once __DIR__ . '/db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'method']); exit; }
$email = isset($_POST['email']) ? trim($_POST['email']) : (isset($_GET['email']) ? trim($_GET['email']) : null);
$source = isset($_POST['source']) ? trim($_POST['source']) : (isset($_GET['source']) ? trim($_GET['source']) : 'web');
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'invalid-email']); exit; }

// Create a persistent device token for the magic link (id.secret) and send it by email.
$label = 'Magic link';
$device = 'email';
try {
  $res = create_token_for($email, $label, $device);
  if (!$res) { throw new Exception('token create failed'); }
  $token = $res['token'];
  // Build magic URL (include source parameter so verify.php knows context)
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $base = $scheme . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
  $magicUrl = $base . '/verify.php?token=' . urlencode($token) . '&source=' . urlencode($source);
  
  // QR code uses deep link for app (so scanning opens the app directly)
  if ($source === 'app') {
    $tokenDisplayUrl = 'liturgia://auth?token=' . urlencode($token);
    $qrTitle = 'Scan to Open in App';
    $qrDesc = 'Scan this QR code with your phone camera to open the Liturgia app and sign in automatically';
  } else {
    $tokenDisplayUrl = $base . '/token-display.php?token=' . urlencode($token);
    $qrTitle = 'Scan to Copy Token on Mobile';
    $qrDesc = 'Scan this QR code with your phone to easily copy the token';
  }
  $qrCodeUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($tokenDisplayUrl);

  // Send HTML email with QR code
  $subject = 'Your Liturgia sign-in link';
  $body = "<!DOCTYPE html>
<html>
<head>
  <meta charset=\"UTF-8\">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #0078d4; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
    .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px; }
    .qr-section { text-align: center; margin: 30px 0; padding: 20px; background: white; border-radius: 8px; }
    .token-box { background: white; border: 2px solid #0078d4; border-radius: 6px; padding: 15px; margin: 20px 0; font-family: monospace; word-break: break-all; }
    .footer { text-align: center; color: #666; font-size: 12px; margin-top: 20px; }
  </style>
</head>
<body>
  <div class=\"container\">
    <div class=\"header\">
      <h1>Your Liturgia Sign-In Link</h1>
    </div>
    <div class=\"content\">
      <p>Click the button below to sign in to Liturgia:</p>
      <p style=\"text-align: center;\">
        <a href=\"$magicUrl\" style=\"display: inline-block; background: #0078d4; color: white !important; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; font-weight: bold;\">Sign In to Liturgia</a>
      </p>
      
      <div class=\"qr-section\">
        <h3 style=\"margin-bottom: 15px;\">$qrTitle</h3>
        <img src=\"$qrCodeUrl\" alt=\"QR Code\" width=\"200\" height=\"200\" style=\"display: block; margin: 0 auto;\" />
        <p style=\"color: #666; font-size: 14px; margin-top: 15px;\">
          $qrDesc
        </p>
      </div>
      
      <p><strong>Or use this token directly:</strong></p>
      <div class=\"token-box\">$token</div>
      
      <p style=\"font-size: 14px; color: #666;\">
        This token is persistent and can be used to sign in to Liturgia on any device. 
        You can revoke it from your account settings at any time.
      </p>
      
      <div class=\"footer\">
        <p>If you didn't request this link, you can safely ignore this email.</p>
      </div>
    </div>
  </div>
</body>
</html>";
  $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
  @mail($email, $subject, $body, $headers);

  echo json_encode(['ok'=>true,'message'=>'sent']);
} catch (Throwable $e) {
  @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - magic-link error: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND);
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'server_error','message'=>'Failed to create/send magic link','details'=>$e->getMessage()]);
  exit;
}
