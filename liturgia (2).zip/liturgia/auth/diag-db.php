<?php
// diag v2
header('Content-Type: application/json');
$path = __DIR__ . '/auth.db';
$out = [
  '__DIR__' => __DIR__,
  'auth_db_path' => $path,
  'exists' => file_exists($path),
  'readable' => is_readable($path),
  'size' => file_exists($path) ? filesize($path) : null,
  'data_dir_writable' => is_writable(__DIR__ . '/data'),
];
if ($out['exists'] && $out['readable']) {
  try {
    $pdo = new PDO('sqlite:' . $path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $out['token_count'] = (int)$pdo->query('SELECT COUNT(*) FROM tokens WHERE revoked_at IS NULL')->fetchColumn();
    $out['total_tokens'] = (int)$pdo->query('SELECT COUNT(*) FROM tokens')->fetchColumn();
    $out['recent_tokens'] = $pdo->query(
      'SELECT id, email, created_at, last_seen, raw_secret IS NOT NULL as has_raw FROM tokens ORDER BY created_at DESC LIMIT 5'
    )->fetchAll(PDO::FETCH_ASSOC);
    $out['db_ok'] = true;
  } catch (Exception $e) {
    $out['db_error'] = $e->getMessage();
    $out['db_ok'] = false;
  }
}
if (!isset($pdo)) {
  $pdo = new PDO('sqlite:' . $path);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
$logPath = __DIR__ . '/../data/magic_links.log';
if (file_exists($logPath)) {
  $lines = file($logPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  $out['magic_links_log_tail'] = array_slice($lines, -30);
} else {
  $out['magic_links_log'] = 'not found at ' . $logPath;
}

$authLogPath = __DIR__ . '/data/auth.log';
if (file_exists($authLogPath)) {
  $lines = file($authLogPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  $out['auth_log_tail'] = array_slice($lines, -20);
} else {
  $out['auth_log'] = 'not found at ' . $authLogPath;
}

$stmt = $pdo->prepare('SELECT id, email, token_hash, raw_secret, created_at FROM tokens WHERE id = :id LIMIT 1');
$stmt->execute([':id' => '7228959ac189b841']);
$row2 = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row2) {
  $out['test_verify'] = password_verify($row2['raw_secret'], $row2['token_hash']);
  $out['test_token_id'] = $row2['id'];
  $out['test_email'] = $row2['email'];
}
echo json_encode($out, JSON_PRETTY_PRINT);
