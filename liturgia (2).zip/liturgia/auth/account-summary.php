<?php
header('Content-Type: application/json');
// Include the auth DB helpers and the main app DB helper (needed to lookup users.founder)
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../db.php'; // defines get_db() for users table access (MySQL/SQLite)

// Install global handlers to catch fatal errors and write to auth log for debugging
set_exception_handler(function($e){ @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary uncaught exception: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n", FILE_APPEND); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'internal']); exit; });
register_shutdown_function(function(){ $err = error_get_last(); if ($err) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary shutdown error: " . json_encode($err) . "\n", FILE_APPEND); if (!headers_sent()) header('Content-Type: application/json', true, 500); echo json_encode(['ok'=>false,'error'=>'fatal','message'=>$err['message']]); } });

function getBearerToken(){
  $hdr = null;
  foreach (getallheaders() as $k=>$v) { if (strtolower($k) === 'authorization') { $hdr = $v; break; } }
  if ($hdr && preg_match('/Bearer\s+(\S+)/', $hdr, $m)) return $m[1];
  if (!empty($_POST['token'])) return $_POST['token'];
  if (!empty($_GET['token'])) return $_GET['token'];
  return null;
}

$auth = getBearerToken();
if (!$auth) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'no-token']); exit; }
$payload = decode_jwt_payload($auth);
$email = null; $status = null;
// If we have a JWT, prefer a direct main-DB lookup (authoritative) to avoid fragile internal HTTP calls
if ($payload && !empty($payload['email'])) {
  $email = $payload['email'];
  // 1) Prefer direct DB lookup if available
  if (function_exists('get_db')) {
    try {
      $pdoMain = get_db();
      $stmt2 = $pdoMain->prepare('SELECT id, email, active, plan, expires_at, founder FROM users WHERE email = :email LIMIT 1');
      $stmt2->execute([':email'=>$email]);
      $u2 = $stmt2->fetch(PDO::FETCH_ASSOC);
      if ($u2) {
        $status = ['active'=>(bool)$u2['active'],'plan'=>$u2['plan'],'expires_at'=>$u2['expires_at'],'email'=>$u2['email'],'founder'=>!empty($u2['founder'])];
      } else {
        // User doesn't exist - just fail (user creation happens in verify.php magic link flow)
        $status = null;
      }
    } catch (Exception $e) {
      @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary main DB lookup failed: " . $e->getMessage() . "\n", FILE_APPEND);
    }
  }
  // 2) Fallback: try internal HTTP call to license-status.php if DB lookup didn't yield results
  if (!$status) {
    try {
      $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
      $url = $scheme . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . '/license-status.php';
      $opts = ['http'=>['method'=>'GET','header'=>"Authorization: Bearer $auth\r\n",'timeout'=>3]];
      $ctx = stream_context_create($opts);
      $res = @file_get_contents($url, false, $ctx);
      if ($res) { $j = json_decode($res, true); if ($j) $status = $j; }
    } catch (Exception $e) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary license-status HTTP call failed: " . $e->getMessage() . "\n", FILE_APPEND); }
  }
}
// Fallback: check DB accounts table using email derived from JWT or device token
if (!$status) {
  if (!$email) $email = email_from_auth_token($auth);
  if ($email) {
    // First, prefer authoritative main users table (plan & expires) when available
    if (function_exists('get_db')) {
      try {
        $pdoMain = get_db();
        $stmtu = $pdoMain->prepare('SELECT id, email, active, plan, expires_at, founder FROM users WHERE email = :email LIMIT 1');
        $stmtu->execute([':email'=>$email]);
        $urow = $stmtu->fetch(PDO::FETCH_ASSOC);
        if ($urow) {
          $status = ['active'=>(bool)$urow['active'],'plan'=>$urow['plan'],'expires_at'=>$urow['expires_at'],'email'=>$urow['email'],'founder'=>!empty($urow['founder'])];
        }
      } catch (Exception $e) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary fallback users lookup failed: " . $e->getMessage() . "\n", FILE_APPEND); }
    }
    // If main users table didn't yield results, fallback to auth accounts table
    if (!$status) {
      $s = get_account_summary_for($email);
      if ($s) $status = $s;
    }
  }
}
// If we still don't have billing info, attempt to include founder flag from users table
if (!$status) {
  if (!function_exists('get_db')) {
    @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary: get_db() not available, cannot lookup users table for founder flag\n", FILE_APPEND);
  } else {
    try {
      $pdo = get_db();
      $stmt = $pdo->prepare('SELECT founder FROM users WHERE email = :email LIMIT 1');
      $stmt->execute([':email'=>$email]);
      $r = $stmt->fetch(PDO::FETCH_ASSOC);
      if ($r) $status = ['plan'=>'token','expires_at'=>null,'active'=>true,'founder'=>!empty($r['founder'])];
    } catch (Exception $e) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary users lookup failed: " . $e->getMessage() . "\n", FILE_APPEND); }
  }
}

// Enrich existing status with founder flag from main users DB if email is known
if ($email) {
  try {
    if (function_exists('get_db')) {
      // Log DB driver/target for diagnostics
      $drv = getenv('DB_DRIVER') ?: (getenv('DB_HOST') ? 'mysql' : 'sqlite');
      $dbName = getenv('DB_NAME') ?: (getenv('DB_PATH') ?: '');
      @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary: enriching founder; db_driver={$drv} db_name={$dbName} email={$email}\n", FILE_APPEND);
      $pdoMain = get_db();
      $stmtf = $pdoMain->prepare('SELECT founder FROM users WHERE email = :email LIMIT 1');
      $stmtf->execute([':email'=>$email]);
      $rf = $stmtf->fetch(PDO::FETCH_ASSOC);
      @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary: founder lookup result for email={$email}: " . json_encode($rf) . "\n", FILE_APPEND);
      if ($rf) {
        if (!$status) $status = ['plan'=>'token','expires_at'=>null,'active'=>true];
        $status['founder'] = !empty($rf['founder']);
      }
    } else {
      @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary: get_db() not available to enrich founder flag\n", FILE_APPEND);
    }
  } catch (Exception $e) { @file_put_contents(__DIR__ . '/data/auth.log', date('c') . " - account-summary founder enrichment failed: " . $e->getMessage() . "\n", FILE_APPEND); }
}

if ($status) echo json_encode(['ok'=>true,'status'=>$status]); else echo json_encode(['ok'=>false]);
