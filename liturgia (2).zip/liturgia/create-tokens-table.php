<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/plain');

echo "Starting token table creation...\n\n";

try {
    $dbPath = __DIR__ . '/db.php';
    echo "Looking for db.php at: $dbPath\n";
    
    if (!file_exists($dbPath)) {
        die("ERROR: db.php not found at $dbPath\n");
    }
    
    require_once $dbPath;
    echo "✓ db.php loaded\n\n";
    
    if (!function_exists('getDB')) {
        die("ERROR: getDB() function not found in db.php\n");
    }
    
    echo "Getting database connection...\n";
    $pdo = getDB();
    echo "✓ Connected to database\n\n";
    
    echo "Creating tokens table in MySQL database...\n\n";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS tokens (
        id VARCHAR(255) PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        label VARCHAR(255),
        device VARCHAR(255),
        token_hash TEXT NOT NULL,
        raw_secret TEXT DEFAULT NULL,
        legacy TINYINT DEFAULT 0,
        persistent TINYINT DEFAULT 1,
        created_at DATETIME,
        last_seen DATETIME,
        revoked_at DATETIME,
        revealed_at DATETIME,
        INDEX idx_email (email),
        INDEX idx_revoked (revoked_at)
    )");
    
    echo "✓ tokens table created\n\n";
    
    echo "Checking for existing tokens in SQLite...\n";
    
    $sqlitePath = __DIR__ . '/data/auth.sqlite';
    if (file_exists($sqlitePath)) {
        $sqlite = new PDO("sqlite:$sqlitePath");
        $tokens = $sqlite->query("SELECT * FROM tokens WHERE revoked_at IS NULL")->fetchAll(PDO::FETCH_ASSOC);
        
        echo "Found " . count($tokens) . " active tokens in SQLite\n\n";
        
        if (count($tokens) > 0) {
            echo "Copying tokens to MySQL...\n";
            
            $stmt = $pdo->prepare("INSERT INTO tokens (id, email, label, device, token_hash, raw_secret, legacy, persistent, created_at, last_seen, revoked_at, revealed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE last_seen = VALUES(last_seen)");
            
            foreach ($tokens as $token) {
                $stmt->execute([
                    $token['id'],
                    $token['email'],
                    $token['label'],
                    $token['device'],
                    $token['token_hash'],
                    $token['raw_secret'] ?? null,
                    $token['legacy'] ?? 0,
                    $token['persistent'] ?? 1,
                    $token['created_at'],
                    $token['last_seen'],
                    $token['revoked_at'],
                    $token['revealed_at'] ?? null
                ]);
            }
            
            echo "✓ Copied " . count($tokens) . " tokens\n\n";
        }
    } else {
        echo "No SQLite database found at $sqlitePath\n\n";
    }
    
    $count = $pdo->query("SELECT COUNT(*) FROM tokens")->fetchColumn();
    echo "Total tokens in MySQL: $count\n\n";
    
    echo "Done! WebSocket server should now be able to authenticate users.\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}
?>
