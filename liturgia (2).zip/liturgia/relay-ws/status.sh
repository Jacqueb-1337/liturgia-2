#!/bin/bash
if pgrep -f "node.*server.js" > /dev/null; then
    echo "WebSocket server is running"
    pgrep -f "node.*server.js" | while read pid; do
        echo "  PID: $pid"
        ps -p $pid -o etime= | xargs echo "  Uptime:"
    done
else
    echo "WebSocket server is NOT running"
fi
