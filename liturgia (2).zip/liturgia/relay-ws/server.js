require('dotenv').config();
// v2 - fixed device token verification (split id.secret, re-read db from disk)
const WebSocket = require('ws');
const http = require('http');
const https = require('https');
const url = require('url');
const mysql = require('mysql2/promise');
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3001;
const DB_CONFIG = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'jacqueb_lturgia',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'jacqueb_liturgia'
};

const SQLITE_PATH = path.join(__dirname, '../httpdocs/liturgia/auth/auth.db');

let dbPool;
let sqliteDb;
let SQL;
let sqliteError = null;

async function initDatabase() {
  dbPool = mysql.createPool({
    ...DB_CONFIG,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });
  console.log('[DB] MySQL pool created');
  
  try {
    SQL = await initSqlJs();
    const buffer = fs.readFileSync(SQLITE_PATH);
    sqliteDb = new SQL.Database(buffer);
    console.log('[DB] SQLite connected:', SQLITE_PATH);
  } catch (err) {
    sqliteError = err.message;
    console.error('[DB] Failed to connect to SQLite:', err.message);
    console.error('[DB] Path attempted:', SQLITE_PATH);
  }
}

function decodeJwt(token) {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const payload = Buffer.from(parts[1], 'base64').toString('utf8');
    return JSON.parse(payload);
  } catch (err) {
    return null;
  }
}

async function verifyToken(token) {
  if (!token) return null;
  
  console.log('[Auth] Verifying token:', token.substring(0, 20) + '...');
  
  const payload = decodeJwt(token);
  if (payload && payload.email) {
    console.log('[Auth] JWT token valid for:', payload.email);
    return payload.email;
  }
  
  try {
    const dotIndex = token.indexOf('.');
    if (dotIndex === -1) {
      console.log('[Auth] Token has no dot separator, not a device token');
      return null;
    }
    const id = token.substring(0, dotIndex);
    const secret = token.substring(dotIndex + 1);

    if (!SQL) {
      console.error('[Auth] sql.js not initialized, cannot check device tokens');
      return null;
    }
    const buffer = fs.readFileSync(SQLITE_PATH);
    const db = new SQL.Database(buffer);
    const result = db.exec('SELECT email, raw_secret FROM tokens WHERE id = ? AND revoked_at IS NULL', [id]);
    db.close();

    if (result.length > 0 && result[0].values.length > 0) {
      const [email, rawSecret] = result[0].values[0];
      if (rawSecret && rawSecret === secret) {
        console.log('[Auth] Device token valid for:', email);
        return email;
      }
      console.log('[Auth] Device token secret mismatch');
      return null;
    } else {
      console.log('[Auth] Token not found or revoked');
      return null;
    }
  } catch (err) {
    console.error('[Auth] Token verification failed:', err.message);
    return null;
  }
}

async function verifySession(sessionId, email) {
  try {
    const [rows] = await dbPool.query(
      'SELECT email FROM relay_sessions WHERE session_id = ?',
      [sessionId]
    );
    if (rows.length === 0) {
      await dbPool.query(
        'INSERT INTO relay_sessions (session_id, email, device_name, created_at, last_seen) VALUES (?, ?, ?, NOW(), NOW())',
        [sessionId, email, 'WebSocket']
      );
      return true;
    }
    return rows[0].email === email;
  } catch (err) {
    console.error('[Session] Verification failed:', err);
    return false;
  }
}

async function storeMessage(sessionId, direction, message) {
  try {
    await dbPool.query(
      'INSERT INTO relay_messages (session_id, direction, message, created_at) VALUES (?, ?, ?, NOW())',
      [sessionId, direction, JSON.stringify(message)]
    );
  } catch (err) {
    console.error('[DB] Store message failed:', err);
  }
}

async function updateState(sessionId, state) {
  try {
    await dbPool.query(
      'UPDATE relay_sessions SET current_state = ?, last_seen = NOW() WHERE session_id = ?',
      [JSON.stringify(state), sessionId]
    );
  } catch (err) {
    console.error('[DB] Update state failed:', err);
  }
}

const sessions = new Map();

function getSessionClients(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, { desktop: null, mobile: null });
  }
  return sessions.get(sessionId);
}

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      activeSessions: sessions.size
    }));
  } else if (req.url === '/diag') {
    (async () => {
      const result = { status: 'ok', checks: {} };
      
      try {
        result.checks.db_pool = dbPool ? 'initialized' : 'not initialized';
      } catch (e) {
        result.checks.db_pool = 'error: ' + e.message;
      }
      
      try {
        const [rows] = await dbPool.query('SELECT 1 as test');
        result.checks.db_connection = rows[0].test === 1 ? 'ok' : 'failed';
      } catch (e) {
        result.checks.db_connection = 'error: ' + e.message;
      }
      
      try {
        result.checks.sqlite_path = SQLITE_PATH;
        result.checks.sqlite_exists = sqliteDb ? 'connected' : 'not connected';
        if (sqliteError) {
          result.checks.sqlite_error = sqliteError;
        }
      } catch (e) {
        result.checks.sqlite_exists = 'error: ' + e.message;
      }
      
      if (sqliteDb) {
        try {
          const queryResult = sqliteDb.exec('SELECT COUNT(*) as count FROM tokens WHERE revoked_at IS NULL');
          if (queryResult.length > 0 && queryResult[0].values.length > 0) {
            result.checks.active_tokens = queryResult[0].values[0][0];
          }
        } catch (e) {
          result.checks.active_tokens = 'error: ' + e.message;
        }
      }
      
      try {
        const [tables] = await dbPool.query("SHOW TABLES LIKE 'relay_sessions'");
        result.checks.relay_sessions_table = tables.length > 0 ? 'exists' : 'missing';
      } catch (e) {
        result.checks.relay_sessions_table = 'error: ' + e.message;
      }
      
      result.checks.env = {
        DB_HOST: process.env.DB_HOST || 'not set',
        DB_USER: process.env.DB_USER || 'not set',
        DB_NAME: process.env.DB_NAME || 'not set',
        DB_PASS: process.env.DB_PASS ? '***set***' : 'not set'
      };
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    })().catch(err => {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'error', error: err.message }));
    });
  } else if (req.url === '/restart' && req.method === 'POST') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Restarting server...\n');
    setTimeout(() => {
      process.exit(0);
    }, 100);
  } else {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Liturgia WebSocket Relay Server\nConnect via WebSocket to this endpoint.\n');
  }
});

const wss = new WebSocket.Server({ server });

wss.on('connection', async (ws, req) => {
  const params = url.parse(req.url, true).query;
  const token = params.token || req.headers['x-auth-token'];
  const sessionId = params.session_id;
  const clientType = params.client_type;

  console.log(`[Connection] New connection attempt - session: ${sessionId}, type: ${clientType}`);

  if (!token || !sessionId || !clientType) {
    console.log('[Connection] Missing auth parameters');
    ws.close(1008, 'Missing auth parameters');
    return;
  }

  const email = await verifyToken(token);
  if (!email) {
    console.log('[Connection] Invalid token');
    ws.close(1008, 'Invalid token');
    return;
  }

  const validSession = await verifySession(sessionId, email);
  if (!validSession) {
    console.log('[Connection] Invalid session');
    ws.close(1008, 'Invalid session');
    return;
  }

  console.log(`[Connection] Authenticated - email: ${email}, session: ${sessionId}, type: ${clientType}`);

  const clients = getSessionClients(sessionId);
  
  if (clientType === 'desktop') {
    if (clients.desktop) {
      console.log('[Connection] Closing existing desktop connection');
      clients.desktop.close(1000, 'New connection');
    }
    clients.desktop = ws;
  } else if (clientType === 'mobile') {
    if (clients.mobile) {
      console.log('[Connection] Closing existing mobile connection');
      clients.mobile.close(1000, 'New connection');
    }
    clients.mobile = ws;
  } else {
    ws.close(1008, 'Invalid client_type');
    return;
  }

  ws.sessionId = sessionId;
  ws.clientType = clientType;
  ws.email = email;
  ws.isAlive = true;

  ws.on('pong', () => {
    ws.isAlive = true;
  });

  if (clientType === 'mobile') {
    try {
      const [rows] = await dbPool.query(
        'SELECT current_state FROM relay_sessions WHERE session_id = ?',
        [sessionId]
      );
      if (rows.length > 0 && rows[0].current_state) {
        const cachedState = JSON.parse(rows[0].current_state);
        ws.send(JSON.stringify({ type: 'state', state: cachedState }));
        console.log(`[Connection] Sent cached state to mobile for session ${sessionId}`);
      }
    } catch (err) {
      console.error('[Connection] Failed to send cached state:', err);
    }
  }

  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data);
      console.log(`[Message] From ${clientType} (${sessionId}):`, message.type || 'unknown');

      if (message.type === 'command') {
        const targetClient = clientType === 'mobile' ? clients.desktop : clients.mobile;
        if (targetClient && targetClient.readyState === WebSocket.OPEN) {
          targetClient.send(JSON.stringify(message));
          console.log(`[Relay] Command relayed to ${clientType === 'mobile' ? 'desktop' : 'mobile'}`);
        } else {
          console.log(`[Store] Target offline, storing to DB`);
          const direction = clientType === 'mobile' ? 'to_desktop' : 'to_mobile';
          await storeMessage(sessionId, direction, message);
        }
      } else if (message.type === 'state') {
        const targetClient = clientType === 'desktop' ? clients.mobile : clients.desktop;
        if (targetClient && targetClient.readyState === WebSocket.OPEN) {
          targetClient.send(JSON.stringify(message));
          console.log(`[Relay] State relayed to ${clientType === 'desktop' ? 'mobile' : 'desktop'}`);
        }
        updateState(sessionId, message.state).catch(err => {
          console.error('[DB] Background state update failed:', err);
        });
      } else if (message.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong' }));
      }
    } catch (err) {
      console.error('[Message] Parse error:', err);
    }
  });

  ws.on('close', () => {
    console.log(`[Disconnect] ${clientType} (${sessionId})`);
    if (clientType === 'desktop') {
      clients.desktop = null;
    } else if (clientType === 'mobile') {
      clients.mobile = null;
    }
    
    if (!clients.desktop && !clients.mobile) {
      sessions.delete(sessionId);
      console.log(`[Cleanup] Session ${sessionId} removed`);
    }
  });

  ws.on('error', (err) => {
    console.error(`[Error] ${clientType} (${sessionId}):`, err.message);
  });

  ws.send(JSON.stringify({ type: 'connected', clientType }));
});

const heartbeat = setInterval(() => {
  wss.clients.forEach(async (ws) => {
    if (ws.isAlive === false) {
      console.log(`[Heartbeat] Terminating dead connection: ${ws.clientType} (${ws.sessionId})`);
      return ws.terminate();
    }
    ws.isAlive = false;
    ws.ping();
    
    if (ws.sessionId) {
      try {
        await dbPool.query(
          'UPDATE relay_sessions SET last_seen = NOW() WHERE session_id = ?',
          [ws.sessionId]
        );
      } catch (err) {
        console.error('[Heartbeat] Failed to update last_seen:', err);
      }
    }
  });
}, 30000);

wss.on('close', () => {
  clearInterval(heartbeat);
});

initDatabase().then(() => {
  server.listen(PORT, () => {
    console.log(`[Server] Listening on port ${PORT}`);
    console.log(`[Server] WebSocket URL: ws://localhost:${PORT}`);
  });
}).catch(err => {
  console.error('[Fatal] Failed to initialize:', err);
  process.exit(1);
});

process.on('SIGTERM', () => {
  console.log('[Server] SIGTERM received, closing...');
  wss.close(() => {
    dbPool.end();
    process.exit(0);
  });
});
