#!/bin/bash
cd "$(dirname "$0")"
source .env
exec node server.js >> logs/server.log 2>&1
