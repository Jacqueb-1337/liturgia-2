#!/bin/bash
pkill -f "node.*server.js"
echo "Stopped old process"
sleep 1
nohup node server.js > server.log 2>&1 &
echo "WebSocket server restarted (PID: $!)"
