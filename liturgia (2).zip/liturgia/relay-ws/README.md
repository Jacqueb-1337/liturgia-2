# Liturgia WebSocket Relay Server

WebSocket-based relay server for real-time communication between desktop and mobile apps.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Configure environment:
```bash
cp .env.example .env
nano .env  # Edit with your database credentials
```

3. Start server:
```bash
npm start
```

## Deployment with PM2 (Recommended)

```bash
npm install -g pm2
pm2 start server.js --name liturgia-relay-ws
pm2 save
pm2 startup
```

## Deployment with systemd

Create `/etc/systemd/system/liturgia-relay-ws.service`:

```ini
[Unit]
Description=Liturgia WebSocket Relay Server
After=network.target mysql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/home/jacqueb/public_html/liturgia/relay-ws
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production
EnvironmentFile=/home/jacqueb/public_html/liturgia/relay-ws/.env

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo systemctl daemon-reload
sudo systemctl enable liturgia-relay-ws
sudo systemctl start liturgia-relay-ws
sudo systemctl status liturgia-relay-ws
```

## Manual Management Scripts

For quick manual control without PM2 or systemd:

**Stop the server:**
```bash
./stop.sh
```

**Restart the server:**
```bash
./restart.sh
```

**Check status:**
```bash
./status.sh
```

Make scripts executable first: `chmod +x *.sh`

## Nginx Configuration

The server runs on the apiliturgia.jacqueb.me subdomain:

```nginx
server {
    listen 443 ssl;
    server_name apiliturgia.jacqueb.me;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 86400;
    }
}
```

After updating nginx config:
```bash
sudo nginx -t
sudo systemctl reload nginx
```

## WebSocket Connection URL

Production: `wss://apiliturgia.jacqueb.me?token=TOKEN&session_id=SESSION&client_type=TYPE`

Where:
- `token` = authentication token
- `session_id` = relay session ID
- `client_type` = `desktop` or `mobile`

## Message Protocol

### Client → Server

**Command Message** (mobile → desktop):
```json
{
  "type": "command",
  "command": "SELECT_VERSE",
  "data": {...}
}
```

**State Update** (desktop → mobile):
```json
{
  "type": "state",
  "state": {
    "currentVerse": {...},
    "allSongs": [...]
  }
}
```

**Ping**:
```json
{
  "type": "ping"
}
```

### Server → Client

**Connection Established**:
```json
{
  "type": "connected",
  "clientType": "desktop"
}
```

**Pong Response**:
```json
{
  "type": "pong"
}
```

**Relayed Command/State**: Original message forwarded from other client

## Fallback Behavior

- If target client is offline, messages are stored in database
- Existing PHP polling system remains functional as fallback
- Desktop app tries WebSocket first, falls back to PHP polling if unavailable

## Monitoring

Check logs:
```bash
pm2 logs liturgia-relay-ws
# or
journalctl -u liturgia-relay-ws -f
```

Check status:
```bash
pm2 status
# or
systemctl status liturgia-relay-ws
```

## Port Requirements

- Default port: 3001 (configurable via PORT env var)
- Must be accessible from nginx reverse proxy
- No need to expose directly to internet (nginx handles external traffic)
