class RelayWebSocketClient {
  constructor(config) {
    this.wsUrl = config.wsUrl || 'ws://apiliturgia.jacqueb.me:3001';
    this.phpBaseUrl = config.phpBaseUrl || 'https://jacqueb.me/liturgia/relay';
    this.token = config.token;
    this.sessionId = config.sessionId;
    this.clientType = config.clientType || 'mobile';
    this.onMessage = config.onMessage || (() => {});
    this.onStateChange = config.onStateChange || (() => {});
    
    this.ws = null;
    this.reconnectTimer = null;
    this.reconnectDelay = 1000;
    this.maxReconnectDelay = 30000;
    this.useWebSocket = true;
    this.phpPollTimer = null;
    this.lastMessageId = 0;
  }

  connect() {
    if (this.useWebSocket) {
      this.connectWebSocket();
    } else {
      this.startPhpPolling();
    }
  }

  connectWebSocket() {
    if (this.ws) return;

    const wsUrl = `${this.wsUrl}?token=${encodeURIComponent(this.token)}&session_id=${encodeURIComponent(this.sessionId)}&client_type=${this.clientType}`;
    
    console.log('[RelayWS] Connecting to WebSocket...');
    
    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[RelayWS] Connected');
        this.reconnectDelay = 1000;
        this.onStateChange('connected-websocket');
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('[RelayWS] Received:', message.type);
          
          if (message.type === 'command') {
            this.onMessage(message);
          } else if (message.type === 'state') {
            this.onMessage(message);
          } else if (message.type === 'connected') {
            console.log('[RelayWS] Server confirmed connection:', message.clientType);
          }
        } catch (err) {
          console.error('[RelayWS] Parse error:', err);
        }
      };

      this.ws.onclose = (event) => {
        console.log(`[RelayWS] Disconnected: ${event.code} ${event.reason}`);
        this.ws = null;
        this.onStateChange('disconnected');
        
        if (event.code === 1008) {
          console.log('[RelayWS] Auth failed, falling back to PHP');
          this.fallbackToPhp();
        } else {
          this.scheduleReconnect();
        }
      };

      this.ws.onerror = (err) => {
        console.error('[RelayWS] Error:', err);
        console.log('[RelayWS] Connection failed, falling back to PHP');
        this.fallbackToPhp();
      };
    } catch (err) {
      console.error('[RelayWS] Connection failed:', err);
      this.fallbackToPhp();
    }
  }

  scheduleReconnect() {
    if (this.reconnectTimer) return;
    
    console.log(`[RelayWS] Reconnecting in ${this.reconnectDelay}ms`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxReconnectDelay);
      this.connectWebSocket();
    }, this.reconnectDelay);
  }

  fallbackToPhp() {
    console.log('[RelayWS] Switching to PHP polling fallback');
    this.useWebSocket = false;
    this.ws = null;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.startPhpPolling();
  }

  startPhpPolling() {
    if (this.phpPollTimer) return;
    
    console.log('[RelayWS] Starting PHP polling');
    this.onStateChange('php-polling');
    
    const poll = () => {
      const direction = this.clientType === 'desktop' ? 'to_desktop' : 'to_mobile';
      
      fetch(`${this.phpBaseUrl}/poll.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Auth-Token': this.token
        },
        body: JSON.stringify({
          session_id: this.sessionId,
          direction: direction,
          last_id: this.lastMessageId
        }),
        signal: AbortSignal.timeout(5000)
      })
      .then(res => res.json())
      .then(result => {
        if (result.messages && result.messages.length > 0) {
          result.messages.forEach(msg => {
            this.lastMessageId = Math.max(this.lastMessageId, msg.id);
            this.onMessage(JSON.parse(msg.message));
          });
        }
        this.phpPollTimer = setTimeout(poll, 500);
      })
      .catch(err => {
        console.error('[RelayWS] PHP poll error:', err.message);
        this.phpPollTimer = setTimeout(poll, 2000);
      });
    };

    poll();
  }

  sendCommand(command, data) {
    const message = {
      type: 'command',
      command: command,
      data: data
    };

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      console.log('[RelayWS] Sending command via WebSocket:', command);
      this.ws.send(JSON.stringify(message));
      return Promise.resolve();
    } else {
      console.log('[RelayWS] Sending command via PHP:', command);
      return this.sendViaPhp('to_desktop', message);
    }
  }

  sendState(state) {
    const message = {
      type: 'state',
      state: state
    };

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      this.sendViaPhp('to_mobile', message);
    }
  }

  sendViaPhp(direction, message) {
    return fetch(`${this.phpBaseUrl}/send.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': this.token
      },
      body: JSON.stringify({
        session_id: this.sessionId,
        direction: direction,
        message: message
      }),
      signal: AbortSignal.timeout(5000)
    })
    .then(res => res.json())
    .then(result => {
      if (!result.ok) {
        throw new Error(result.error || 'Unknown error');
      }
      return result;
    });
  }

  disconnect() {
    console.log('[RelayWS] Disconnecting');
    
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    
    if (this.phpPollTimer) {
      clearTimeout(this.phpPollTimer);
      this.phpPollTimer = null;
    }
    
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
