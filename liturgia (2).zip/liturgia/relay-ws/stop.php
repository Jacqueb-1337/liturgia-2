<?php
header('Content-Type: text/plain');

$pidFile = __DIR__ . '/server.pid';
$logFile = __DIR__ . '/server.log';

if (file_exists($pidFile)) {
    $pid = trim(file_get_contents($pidFile));
    
    if ($pid) {
        exec("kill $pid 2>&1", $output, $returnCode);
        
        if ($returnCode === 0) {
            echo "Stopped WebSocket server (PID: $pid)\n";
            unlink($pidFile);
        } else {
            echo "Failed to stop process $pid\n";
            echo "Output: " . implode("\n", $output) . "\n";
        }
    } else {
        echo "PID file is empty\n";
        unlink($pidFile);
    }
} else {
    echo "Server is not running (no PID file)\n";
}

echo "\nVisit status.php to check status\n";
?>
