#!/bin/bash
pkill -f "node.*server.js"
echo "WebSocket server stopped"
