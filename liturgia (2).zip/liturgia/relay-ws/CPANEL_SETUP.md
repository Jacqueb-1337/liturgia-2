# Quick cPanel Setup Guide

## What to Do in cPanel

### 1. Upload Files
- Go to **File Manager**
- Navigate to `public_html/liturgia/`
- Create new folder: `relay-ws`
- Upload all files from local `liturgia/relay-ws/` directory

### 2. Setup Node.js App
- Go to **Setup Node.js App** (in Software section)
- Click **Create Application**
- Settings:
  - **Node.js version**: Select latest (14.x, 16.x, 18.x, or 20.x)
  - **Application mode**: Production
  - **Application root**: `liturgia/relay-ws`
  - **Application URL**: (leave blank)
  - **Application startup file**: `server.js`
- Click **Create**

### 3. Configure Environment
- In the Node.js app panel, click **Edit** on your app
- Scroll to **Environment Variables**
- Add these variables:
  - `PORT` = `3001`
  - `DB_HOST` = `localhost`
  - `DB_USER` = `jacqueb_lturgia` (or your actual DB user)
  - `DB_PASS` = (your database password - find in db.php)
  - `DB_NAME` = `jacqueb_liturgia`
- Click **Save**

### 4. Install Dependencies
- In Node.js app panel, click the **Run NPM Install** button
- Or copy the command shown ("Enter to the virtual environment") and run:
  ```bash
  source /home/jacqueb/nodevenv/liturgia/relay-ws/14/bin/activate && cd /home/jacqueb/public_html/liturgia/relay-ws
  npm install
  ```

### 5. Start Application
- Click **Start Application** button in Node.js app panel
- Status should change to **Running**
- Note the port it's running on (should be 3001)

### 6. Configure Subdomain
- The subdomain **apiliturgia.jacqueb.me** should already be created in cPanel
- It should point to the Node.js application
- cPanel will automatically proxy WebSocket connections to port 3001
- No .htaccess configuration needed for subdomains

### 7. Test Connection
- Go to **Terminal** in cPanel
- Run:
  ```bash
  curl http://127.0.0.1:3001
  ```
- Should see: `Liturgia WebSocket Relay Server`

- Test through domain:
  ```bash
  curl https://apiliturgia.jacqueb.me
  ```
- Should see same response

### 8. Monitor
- In Node.js app panel, click **Open logs**
- You should see:
  ```
  [DB] Pool created
  [Server] Listening on port 3001
  ```
- Any errors will appear here

## If Something Goes Wrong

### App won't start
1. Check environment variables are set correctly
2. Verify database password matches your actual password
3. Check logs for specific error
4. Make sure port 3001 isn't already in use

### Can't connect from outside
1. Verify app is running in Node.js panel
2. Check subdomain apiliturgia.jacqueb.me is configured
3. Test direct: `curl http://127.0.0.1:3001`
4. Check Apache error logs: **Errors** section in cPanel

### Need to restart
- Node.js app panel → Click **Restart** button
- Or in Terminal:
  ```bash
  cd ~/public_html/liturgia/relay-ws
  touch restart.txt
  ```

## Database Password Location

Your database password is in one of these files:
- `/public_html/liturgia/db.php`
- `/public_html/liturgia/relay/auth.php`

Look for line like:
```php
$password = 'YOUR_PASSWORD_HERE';
```

## Success Checklist

- [ ] Files uploaded to `public_html/liturgia/relay-ws/`
- [ ] Node.js app created and shows "Running"
- [ ] Environment variables configured
- [ ] `npm install` completed successfully
- [ ] `curl http://127.0.0.1:3001` returns server message
- [ ] Subdomain apiliturgia.jacqueb.me points to application
- [ ] `curl https://apiliturgia.jacqueb.me` returns server message
- [ ] Logs show no errors

Once all checked, your WebSocket server is live! 🚀
