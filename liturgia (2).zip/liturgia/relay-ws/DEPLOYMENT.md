# WebSocket Deployment Checklist

## Prerequisites
- Node.js installed on your cPanel/server (version 14+)
- Access to terminal (SSH or cPanel Terminal)
- Existing database with relay_sessions and relay_messages tables
- nginx or Apache with reverse proxy capability

## Step 1: Upload Files

Upload the entire `relay-ws/` directory to your server at:
```
~/public_html/liturgia/relay-ws/
```

Files to upload:
- server.js
- package.json
- .env.example
- start.sh
- README.md
- .gitignore
- relay-ws-client-browser.js

## Step 2: Install Dependencies

SSH into your server or use cPanel Terminal:

```bash
cd ~/public_html/liturgia/relay-ws
npm install
```

This will install:
- `ws` (WebSocket library)
- `mysql2` (MySQL database driver)

## Step 3: Configure Environment

Create .env file with your database credentials:

```bash
cp .env.example .env
nano .env
```

Edit with your actual credentials:
```
PORT=3001
DB_HOST=localhost
DB_USER=jacqueb_lturgia
DB_PASS=YOUR_ACTUAL_PASSWORD_HERE
DB_NAME=jacqueb_liturgia
```

**IMPORTANT**: Get your actual database password from your existing PHP files (check `db.php` or `liturgia/db.php`)

## Step 4: Test Connection

Before setting up as a service, test manually:

```bash
node server.js
```

You should see:
```
[DB] Pool created
[Server] Listening on port 3001
[Server] WebSocket URL: ws://localhost:3001
```

Press Ctrl+C to stop.

If you see errors:
- Check database credentials in .env
- Verify port 3001 is not already in use: `netstat -tuln | grep 3001`
- Check database tables exist: `mysql -u USER -p DATABASE -e "SHOW TABLES LIKE 'relay_%'"`

## Step 5: Setup as Persistent Service

### Option A: Using PM2 (Recommended)

Install PM2 globally:
```bash
npm install -g pm2
```

Start the server:
```bash
cd ~/public_html/liturgia/relay-ws
pm2 start server.js --name liturgia-relay-ws
pm2 save
```

Make it start on reboot:
```bash
pm2 startup
```

Follow the instructions PM2 prints (may need sudo).

Useful PM2 commands:
```bash
pm2 status                    # Check status
pm2 logs liturgia-relay-ws    # View logs
pm2 restart liturgia-relay-ws # Restart server
pm2 stop liturgia-relay-ws    # Stop server
pm2 delete liturgia-relay-ws  # Remove from PM2
```

### Option B: Using cPanel Node.js App

1. Go to cPanel → "Setup Node.js App"
2. Click "Create Application"
3. Fill in:
   - Node.js version: 14.x or higher
   - Application mode: Production
   - Application root: `/home/jacqueb/public_html/liturgia/relay-ws`
   - Application URL: Leave blank or use subdomain
   - Application startup file: `server.js`
4. Click "Create"
5. Copy the command shown and run it to enter virtual environment
6. Run `npm install` in that environment
7. Click "Start Application"

### Option C: Using systemd (VPS only)

Create service file:
```bash
sudo nano /etc/systemd/system/liturgia-relay-ws.service
```

Paste:
```ini
[Unit]
Description=Liturgia WebSocket Relay Server
After=network.target mysql.service

[Service]
Type=simple
User=jacqueb
WorkingDirectory=/home/jacqueb/public_html/liturgia/relay-ws
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production
EnvironmentFile=/home/jacqueb/public_html/liturgia/relay-ws/.env

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable liturgia-relay-ws
sudo systemctl start liturgia-relay-ws
sudo systemctl status liturgia-relay-ws
```

## Step 6: Configure Reverse Proxy

### For nginx:

Edit your site config (usually in `/etc/nginx/sites-available/` or cPanel nginx config):

```nginx
location /relay-ws {
    proxy_pass http://localhost:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 86400;
}
```

Test and reload:
```bash
sudo nginx -t
sudo systemctl reload nginx
```

### For Apache (cPanel):

Create or edit `.htaccess` in `/public_html/`:

```apache
<IfModule mod_proxy.c>
    <IfModule mod_proxy_wstunnel.c>
        ProxyPass /relay-ws ws://localhost:3001
        ProxyPassReverse /relay-ws ws://localhost:3001
    </IfModule>
</IfModule>
```

Or in Apache config:
```apache
<Location /relay-ws>
    ProxyPass ws://localhost:3001
    ProxyPassReverse ws://localhost:3001
</Location>
```

Restart Apache:
```bash
sudo systemctl restart httpd
# or for cPanel
/scripts/restartsrv_httpd
```

## Step 7: Test WebSocket Connection

Use a WebSocket test tool or curl:

```bash
# Test HTTP health endpoint
curl http://localhost:3001
# Should return: Liturgia WebSocket Relay Server

# Test through nginx/apache
curl https://apiliturgia.jacqueb.me
# Should return: Liturgia WebSocket Relay Server
```

For full WebSocket test, use browser console:
```javascript
const ws = new WebSocket('wss://apiliturgia.jacqueb.me?token=YOUR_TOKEN&session_id=test&client_type=mobile');
ws.onopen = () => console.log('Connected!');
ws.onmessage = (e) => console.log('Message:', e.data);
ws.onerror = (e) => console.error('Error:', e);
```

## Step 8: Update Desktop App

The desktop app will automatically try WebSocket first and fall back to PHP polling if unavailable. No code changes needed immediately - the `relay-ws-client.js` will handle this.

To integrate later, replace current `relay-client.js` usage with:
```javascript
const RelayWebSocketClient = require('./relay-ws-client.js');

const relayClient = new RelayWebSocketClient({
  wsUrl: 'wss://apiliturgia.jacqueb.me',
  phpBaseUrl: 'https://jacqueb.me/liturgia/relay',
  token: userToken,
  sessionId: sessionId,
  clientType: 'desktop',
  onMessage: (message) => {
    // Handle incoming commands
  },
  onStateChange: (state) => {
    console.log('Relay state:', state);
  }
});

relayClient.connect();
```

## Step 9: Update Mobile App

Similar integration for mobile app using `relay-ws-client-browser.js`.

## Troubleshooting

### Server won't start
- Check database credentials in .env
- Verify port 3001 is available: `netstat -tuln | grep 3001`
- Check Node.js version: `node --version` (must be 14+)
- View logs: `pm2 logs` or check service logs

### Can't connect through nginx/Apache
- Verify reverse proxy modules are enabled
- Check firewall isn't blocking port 3001 internally
- Test direct connection first: `curl http://localhost:3001`
- Check nginx/Apache error logs

### Connection closes immediately
- Check authentication token is valid
- Verify session_id exists in database
- Check server logs for authentication errors

### PHP fallback activates
- This is normal if WebSocket server is down
- Commands will still work, just with 500ms polling delay
- Fix WebSocket server to restore instant communication

## Monitoring

Check server status:
```bash
pm2 status
# or
systemctl status liturgia-relay-ws
```

View logs:
```bash
pm2 logs liturgia-relay-ws --lines 50
# or
journalctl -u liturgia-relay-ws -n 50 -f
```

Check active connections:
```bash
netstat -an | grep 3001 | grep ESTABLISHED | wc -l
```

## Rollback to PHP Only

If you need to disable WebSocket and use PHP only:

```bash
pm2 stop liturgia-relay-ws
# or
sudo systemctl stop liturgia-relay-ws
```

The desktop and mobile apps will automatically fall back to PHP polling. No data loss - all messages are still stored in database as fallback.

## Success Indicators

✅ Server starts without errors
✅ PM2/systemd shows "online" or "active (running)"
✅ Can curl http://localhost:3001 and get response
✅ Can curl https://apiliturgia.jacqueb.me and get response
✅ No authentication errors in logs
✅ Desktop app logs show "[RelayWS] Connected"
✅ Mobile commands execute instantly (no 500ms delay)

## Next Steps

Once working:
- Monitor logs for first 24 hours
- Check PM2/systemd status daily for first week
- Set up log rotation if needed
- Consider monitoring alerts for downtime
- Update todo: WebSocket support ✅ Complete!
