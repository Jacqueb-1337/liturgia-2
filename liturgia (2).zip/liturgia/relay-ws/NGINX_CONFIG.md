# Nginx Configuration for WebSocket Proxy

The WebSocket server requires specific Nginx configuration to proxy WebSocket connections properly.

## Required Configuration

Add this to your Nginx config for apiliturgia.jacqueb.me:

```nginx
server {
    listen 443 ssl http2;
    server_name apiliturgia.jacqueb.me;
    
    ssl_certificate /path/to/your/cert.pem;
    ssl_certificate_key /path/to/your/key.pem;
    
    location / {
        proxy_pass http://127.0.0.1:3001;
        
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        
        proxy_buffering off;
    }
}
```

## Test Commands

**Test if server is running locally:**
```bash
curl http://127.0.0.1:3001/health
```

Should return JSON:
```json
{"status":"ok","uptime":123,"timestamp":"...","activeSessions":0}
```

**Test if Nginx is proxying:**
```bash
curl https://apiliturgia.jacqueb.me/health
```

Should return same JSON.

**Test WebSocket upgrade:**
```bash
wscat -c wss://apiliturgia.jacqueb.me
```

If this fails with "Unexpected server response: 200", Nginx isn't configured for WebSocket.

## Troubleshooting

### Getting HTTP 200 instead of WebSocket upgrade

This means Nginx doesn't have the `Upgrade` and `Connection` headers configured.

**Check current Nginx config:**
```bash
grep -A 20 "apiliturgia.jacqueb.me" /etc/nginx/sites-enabled/*
```

**Look for missing lines:**
- `proxy_http_version 1.1;`
- `proxy_set_header Upgrade $http_upgrade;`
- `proxy_set_header Connection "upgrade";`

### Server not responding at all

Check if Node.js server is running:
```bash
./status.sh
# or
ps aux | grep "node.*server.js"
netstat -tlnp | grep 3001
```

Start if necessary:
```bash
nohup node server.js > server.log 2>&1 &
```

### SSL/Certificate errors

Make sure SSL certificates are valid and not expired:
```bash
openssl s_client -connect apiliturgia.jacqueb.me:443 -servername apiliturgia.jacqueb.me
```

## After Changes

Always reload Nginx after config changes:
```bash
sudo nginx -t          # Test config
sudo systemctl reload nginx    # Apply if test passes
```
