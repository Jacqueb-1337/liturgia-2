<?php
header('Content-Type: text/plain');

$pidFile = __DIR__ . '/server.pid';
$logFile = __DIR__ . '/server.log';
$nodeCommand = '/usr/bin/node';

if (!file_exists('.env')) {
    die("ERROR: .env file not found\nCreate .env file first with database credentials\n");
}

if (file_exists($pidFile)) {
    $pid = trim(file_get_contents($pidFile));
    if ($pid) {
        exec("ps -p $pid", $output, $returnCode);
        if ($returnCode === 0 && count($output) > 1) {
            die("ERROR: Server is already running (PID: $pid)\nVisit stop.php first to stop it\n");
        }
    }
    unlink($pidFile);
}

$cmd = "nohup $nodeCommand server.js > $logFile 2>&1 & echo $!";
$pid = shell_exec($cmd);
$pid = trim($pid);

if ($pid && is_numeric($pid)) {
    file_put_contents($pidFile, $pid);
    
    sleep(1);
    
    exec("ps -p $pid", $output, $returnCode);
    if ($returnCode === 0 && count($output) > 1) {
        echo "WebSocket server started successfully!\n";
        echo "PID: $pid\n";
        echo "\nVisit status.php to check status\n";
        echo "Visit /health for health check\n";
        echo "Visit /diag for diagnostics\n";
    } else {
        echo "WARNING: Server started but process not found\n";
        echo "PID: $pid\n";
        echo "\nCheck $logFile for errors\n";
    }
} else {
    echo "ERROR: Failed to start server\n";
    echo "Command output: $pid\n";
    
    if (file_exists($logFile)) {
        echo "\nLast 10 lines of log:\n";
        $lines = file($logFile);
        $lastLines = array_slice($lines, -10);
        echo implode('', $lastLines);
    }
}
?>
