<?php
header('Content-Type: text/plain');

echo "Restarting WebSocket server...\n\n";

include 'stop.php';

echo "\n\nWaiting 2 seconds...\n\n";
sleep(2);

include 'start.php';
?>
