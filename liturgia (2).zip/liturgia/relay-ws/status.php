<?php
header('Content-Type: text/plain');

$pidFile = __DIR__ . '/server.pid';
$logFile = __DIR__ . '/server.log';

if (file_exists($pidFile)) {
    $pid = trim(file_get_contents($pidFile));
    
    if ($pid) {
        exec("ps -p $pid", $output, $returnCode);
        
        if ($returnCode === 0 && count($output) > 1) {
            echo "WebSocket Server is RUNNING\n";
            echo "PID: $pid\n\n";
            
            exec("ps -p $pid -o etime=", $uptimeOutput);
            if (!empty($uptimeOutput)) {
                echo "Uptime: " . trim($uptimeOutput[0]) . "\n";
            }
            
            if (file_exists($logFile)) {
                echo "\nLast 20 lines of log:\n";
                echo "====================\n";
                $lines = file($logFile);
                $lastLines = array_slice($lines, -20);
                echo implode('', $lastLines);
            }
        } else {
            echo "WebSocket Server is NOT RUNNING\n";
            echo "(PID file exists but process $pid not found)\n";
            unlink($pidFile);
        }
    } else {
        echo "WebSocket Server is NOT RUNNING\n";
        echo "(Empty PID file)\n";
    }
} else {
    echo "WebSocket Server is NOT RUNNING\n";
    echo "(No PID file found)\n";
}

echo "\n\nTo start: visit start.php\n";
echo "To stop: visit stop.php\n";
echo "To restart: visit restart.php\n";
echo "To check diagnostics: visit /diag\n";
?>
