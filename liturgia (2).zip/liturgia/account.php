<?php
// Moved from index.php to account.php to keep the account management interface accessible.

// Check for auth_token cookie (set by verify.php after magic link validation)
// This cookie comes from the magic link redirect flow
$authTokenFromCookie = null;
if (!empty($_COOKIE['auth_token'])) {
    $authTokenFromCookie = $_COOKIE['auth_token'];
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Liturgia • Worship Account</title>
<link rel="stylesheet" href="/liturgia/style.css">
<link rel="stylesheet" href="/liturgia/style-small.css">
<!-- Font Awesome for consistent eye icons (offline choice accepted for site) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">
<link rel="icon" href="/liturgia/logo.png" type="image/png">
</head>
<body class="dark">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia Worship" class="brand-logo"/>
        <span class="product">Liturgia <span class="product-sub">• Worship</span></span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      <nav class="nav">
        <a href="/liturgia/index.php">Home</a>
        <a href="/liturgia/pricing.php">Pricing</a>
        <span class="nav-current">Account</span>
        <a href="/liturgia/download.php">Download</a>
        <a href="/liturgia/apps.php">Apps</a>
      </nav>
    </div>
  </header>

  <main class="container hero" style="max-width:720px;">
    <div id="flash-message" class="flash" style="display:none" aria-live="polite"></div>
    <div id="send-card" class="card" style="padding:20px; margin-top:18px">
      <h3>Send magic link</h3>
      <div class="form-row">
        <input id="email" type="email" class="input" placeholder="you@example.com" />
        <button id="send" type="button" class="btn primary">Send Magic Link</button>
        <button id="enter-token-btn" type="button" class="btn">Enter Token</button>
        <button id="subscribe" type="button" class="btn" title="Subscribe / Purchase">Subscribe</button>
      </div>
      <!-- Plan chooser is presented in a modal for clarity (desktop client parity) -->
      <p id="status" style="color:var(--muted); margin-top:8px"></p>
      <p style="margin-top:10px;color:var(--muted);font-weight:600">First 50 users receive a free <strong>Founding</strong> license and a one-year subscription — eligible users are updated automatically at signup.</p>
    </div>



    <div id="account" class="card" style="margin-top:18px; display:none; padding:18px">
      <div class="acct-header" style="margin-bottom:12px;text-align:center">
        <h3 style="margin:0">Your Account</h3>
        <div class="founder-subtext" style="display:none;margin-top:6px;color:var(--muted);font-size:13px">You are a founding church — thank you for your support in shaping Liturgia.</div>
      </div>
      <div id="acct-info"></div>


    </div>
  </main>

<script>
// Default server base: use local relative paths when hosted, but if running from file:// or localhost fall back to the production license server
// This prevents the account UI from showing the token-only fallback when a local PHP backend is not running.
const serverBase = (location && (location.protocol === 'file:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) ? 'https://jacqueb.me/liturgia' : './'; // relative in this simple installer
console.log('account.php script loaded');
const emailEl = document.getElementById('email');
const statusEl = document.getElementById('status');
const sendBtn = document.getElementById('send');
let currentAccountEmail = null; // populated on sign-in (decoded from token or status)

// If auth_token cookie was set by verify.php magic link flow, use it immediately
const authTokenFromCookie = <?php echo $authTokenFromCookie ? json_encode($authTokenFromCookie) : 'null'; ?>;
if (authTokenFromCookie) {
  console.log('account.php: found auth_token cookie from magic link flow');
  // Don't validate yet; let autoSignIn below detect the saved token
}

// In-memory cache for revealed tokens so users can re-copy without server calls
const revealedTokenCache = {}; // id -> token


async function sendMagicLink() {
  const email = emailEl.value.trim();
  if (!email) return alert('Enter email');
  // Client-side validation and logging
  console.log('sendMagicLink: sending magic link for', email);
  const blocked = ['you@example.com','test@example.com','example@example.com','no-reply@example.com'];
  if (blocked.includes(email.toLowerCase())) { statusEl.textContent = 'Enter a real email address.'; return; }
  statusEl.textContent = 'Sending magic link...';
  sendBtn.disabled = true;
  try {
    const res = await fetch(serverBase + 'auth/magic-link.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `email=${encodeURIComponent(email)}&source=web`});
    const j = await res.json();
    console.log('sendMagicLink: server response', j);
    if (j.ok) statusEl.textContent = 'Magic link sent — check your email (and spam/junk folder) and paste the token via "Enter Token".';
    else statusEl.textContent = 'Failed to send: ' + (j.error||'');
  } catch (e) { console.error('sendMagicLink error', e); statusEl.textContent = 'Error sending magic link'; }
  sendBtn.disabled = false;
}

async function validateTokenAndActivate(token) {
  // Browser-first: try query-param token first to avoid Authorization header being stripped
  const server = (serverBase||'').replace(/\/$/, '');
  if (!server) return { ok: false, reason: 'no-server' };
  try {
    // Try query param (less likely to be stripped by proxies)
    let res = await fetch(server + '/license-status.php?token=' + encodeURIComponent(token));
    if (res.status !== 200) {
      // Fallback: try Authorization header
      try { res = await fetch(server + '/license-status.php', { headers: { 'Authorization': 'Bearer ' + token } }); } catch (e) {}
    }
    if (res && res.status === 200) {
      const json = await res.json();
      try { console.info('validateTokenAndActivate: license-status response', json); } catch(e) {}
      return { ok: true, active: !!json.active, status: json };
    }

    // If license-status rejects (401), try the sessions listing as a fallback to accept device tokens
    if (res && res.status === 401) {
      try {
        // Prefer Authorization header to avoid proxy/WAF query-string blocking
        let li = await fetch(server + '/auth/list-tokens.php', { headers: { 'Authorization': 'Bearer ' + token } });
        // If the Authorization header was rejected, try POSTing the token
        if (li && li.status === 401) {
          try { li = await fetch(server + '/auth/list-tokens.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: 'token=' + encodeURIComponent(token) }); } catch(e) {}
        }
        if (li && li.ok) {
          const lj = await li.json().catch(()=>null);
          if (lj && Array.isArray(lj.tokens) && lj.tokens.length > 0) {
            // derive email from returned session entries
            const email = lj.tokens[0].email || '';
            // Attempt to fetch richer account summary (plan & expiry) for this email
            try {
              const as = await fetch(server + '/license-status.php?token=' + encodeURIComponent(token));
              if (as && as.ok) {
                const aj = await as.json().catch(()=>null);
                try { console.info('validateTokenAndActivate: license-status (sessions fallback) response', aj); } catch(e) {}
                if (aj && aj.ok && aj.status) {
                  const status = Object.assign({}, aj.status, { sessions: lj.tokens });
                  return { ok: true, active: !!aj.status.active, status };
                }
              }
            } catch(e) { /* ignore */ }
            const status = { email, active: true, plan: 'token', sessions: lj.tokens };
            return { ok: true, active: true, status };
          }
        }
      } catch(e) { /* ignore fallback errors */ }
    }

    let text = res ? await res.text().catch(()=>'') : '';
    try { const p = JSON.parse(text); text = p.error || text; } catch(e){}
    return { ok:false, reason: 'http-'+(res?res.status:'no-response'), message: text };
  } catch (e) { return { ok:false, reason: 'error', message: e.message } }
}



try { sendBtn.addEventListener('click', sendMagicLink); console.log('send listener attached'); } catch(e){ console.error('send listener attach failed', e); }
try { document.getElementById('enter-token-btn').addEventListener('click', openTokenModal); console.log('enter-token listener attached'); } catch(e) { console.error('enter-token attach failed', e); }

// Checkout/subscribe handlers
async function createCheckout(email, triggerBtn, plan) { console.log('createCheckout called for', email, 'plan', plan); if (triggerBtn && triggerBtn.disabled) { console.log('trigger btn disabled already'); }
  if (!email) { statusEl.textContent = 'Enter an email'; return; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { statusEl.textContent = 'Enter a valid email'; return; }
  const btn = triggerBtn || document.querySelector('#subscribe, #subscribe-account');
  if (btn) btn.disabled = true;
  statusEl.textContent = 'Creating checkout...';
  try {
    console.log('createCheckout: starting for', email);
    // Use absolute path to avoid relative resolution issues
    const url = new URL('/liturgia/create-checkout-session.php', location.origin).href; // absolute to site root
    console.log('createCheckout: using url', url);
    // include selected plan
    let body = `email=${encodeURIComponent(email)}&plan=${encodeURIComponent(plan||'monthly')}`;
    let res = await fetch(url, { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body });
    let j = null; let textBody = null;
    try { j = await res.json(); } catch (err) { textBody = await res.text().catch(()=>null); }
    // Retry with JSON if server rejects form content-type
    if (textBody && /content type/i.test(textBody)) {
      console.log('createCheckout: retrying with JSON body');
      res = await fetch(url, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({email:email, plan:plan||'monthly'}) });
      try { j = await res.json(); } catch (err) { textBody = await res.text().catch(()=>null); }
    }
    console.log('createCheckout: response', { resStatus: res && res.status, j, textBody });
    if (j && j.url) {
      try { localStorage.setItem('lastPurchasedPlan', plan || 'monthly'); } catch(e) {}
      window.open(j.url, '_blank'); statusEl.textContent = 'Checkout opened in browser.'; }
    else {
      const msg = `Failed to create checkout: HTTP ${res?res.status:'no-response'} ${j && j.error ? j.error : (textBody||'')}`;
      statusEl.textContent = msg;
      console.warn('createCheckout:', msg);
    }
  } catch (e) { console.error(e); statusEl.textContent = 'Error creating checkout'; }
  if (btn) btn.disabled = false;
}

try { document.getElementById('subscribe').addEventListener('click', function(e) { console.log('subscribe clicked - opening plan modal'); openPlanModal(emailEl.value.trim(), e.currentTarget); }); console.log('subscribe listener attached'); } catch(e) { console.error('subscribe attach failed', e); }




// Allow Enter key in inputs
emailEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMagicLink(); });

// Flash message helper
function showFlash(msg, type='info', ttl=7000) {
  try {
    const fm = document.getElementById('flash-message');
    if (!fm) return;
    fm.textContent = msg;
    fm.className = 'flash ' + (type === 'success' ? 'success' : '');
    fm.style.display = 'block';
    // trigger transition
    setTimeout(() => fm.classList.add('show'), 20);
    // auto-hide after ttl ms
    setTimeout(() => { fm.classList.remove('show'); setTimeout(()=> fm.style.display = 'none', 360); }, ttl);
  } catch(e) { console.warn('showFlash failed', e); }
}

// If a token was previously saved in this browser session or app, try it now
(async function trySavedTokenOnLoad(){
  try {
    let saved = null;
    // If running inside the desktop app, try secure storage first
    try {
      if (window && window.ipc && typeof window.ipc.invoke === 'function') {
        const t = await window.ipc.invoke('secure-get-token');
        if (t) saved = t;
      }
    } catch(e) { /* ignore secure errors */ }
    // Fallback to localStorage for the web site
    if (!saved) saved = localStorage.getItem('liturgia.token');

    if (saved) {
      statusEl.textContent = 'Checking saved token...';
      const res = await validateTokenAndActivate(saved);
      if (res.ok) {
        handleSignIn(saved, res.status);
        statusEl.textContent = 'Signed in via saved token.';
      } else {
        // If running in the desktop app and refresh/validate failed, try clearing secure token so user can sign in again
        try {
          if (window && window.ipc && typeof window.ipc.invoke === 'function') {
            try { await window.ipc.invoke('secure-delete-token'); } catch(e) { /* ignore */ }
            try { await window.ipc.invoke('update-settings', { auth: null }); } catch(e) {}
          }
        } catch(e){ }
        statusEl.textContent = '';
      }
    }
  } catch(e) { /* ignore */ }
})();

// When redirected from purchase success, prefer localStorage lastPurchasedPlan to display immediately
(function readLastPurchasedPlan(){ try { const p = localStorage.getItem('lastPurchasedPlan'); if (p) { const el = document.getElementById('acct-info'); if (el && el.innerHTML.trim()!== '') { // only set plan if account is visible
      // try to update existing plan display
      const cur = el.innerHTML; if (/Plan:/i.test(cur)) { el.innerHTML = cur.replace(/Plan:\s*[^<]*/i, 'Plan: ' + p); } else { el.innerHTML += `<p>Plan: ${p}</p>`; }
    }
  }} catch(e){} })();

// Check for purchase redirect params and show a thank-you flash
(function checkPurchaseParam(){
  try {
    const q = new URLSearchParams(location.search);
    if (q.get('purchase') === '1' || q.get('success') === '1') {
      const plan = localStorage.getItem('lastPurchasedPlan');
      const msg = plan ? `Thank you for your purchase — ${plan === 'monthly' ? '$12/mo' : '$100/yr'} selected. Your subscription will be active shortly.` : 'Thank you for your purchase — your subscription will be active shortly.';
      showFlash(msg, 'success', 9000);
      // If we have a plan in storage, show it immediately in the account area (even if not signed in)
      try {
        const p = localStorage.getItem('lastPurchasedPlan');
        if (p) {
          const acct = document.getElementById('acct-info');
          if (acct) {
            // insert or replace a pending-plan note
            let note = document.getElementById('pending-plan');
            if (!note) { note = document.createElement('p'); note.id = 'pending-plan'; acct.appendChild(note); }
            note.textContent = 'Selected plan: ' + (p === 'monthly' ? '$12/month' : '$100/year') + ' (processing)';
          }
        }
      } catch(e){}
      // Remove query params so refresh doesn't show it again
      const u = new URL(location.href);
      u.searchParams.delete('purchase'); u.searchParams.delete('success');
      history.replaceState(null, '', u.pathname + u.search + u.hash);
    }
  } catch(e) { /* ignore */ }
})();

// If ?plan=monthly|yearly is present, preselect and open the plan modal
(function checkPlanParam(){
  try {
    const q = new URLSearchParams(location.search);
    const plan = q.get('plan');
    if (plan && (plan === 'monthly' || plan === 'yearly')) {
      try { localStorage.setItem('lastPurchasedPlan', plan); } catch(e){}
      const email = emailEl.value.trim();
      // Open the plan modal after a short delay so UI is ready
      setTimeout(() => { openPlanModal(email, document.querySelector('#subscribe')); }, 300);
      const u = new URL(location.href); u.searchParams.delete('plan'); history.replaceState(null,'', u.pathname + u.search + u.hash);
    }
  } catch(e) { /* ignore */ }
})();

// If ?auth=success is present, reload account info (magic link from email was just clicked)
(function checkAuthSuccess(){
  try {
    const q = new URLSearchParams(location.search);
    if (q.get('auth') === 'success') {
      // Magic link from email was just clicked and verified
      // Token should now be available from authTokenFromCookie (set by verify.php and passed from PHP)
      const u = new URL(location.href);
      u.searchParams.delete('auth');
      history.replaceState(null, '', u.pathname + u.search + u.hash);
      
      // Use the token from the cookie (passed by PHP at page load)
      setTimeout(async () => {
        let saved = authTokenFromCookie; // Use the token from PHP, not document.cookie
        
        if (!saved) {
          try {
            if (window && window.ipc && typeof window.ipc.invoke === 'function') {
              const t = await window.ipc.invoke('secure-get-token');
              if (t) saved = t;
            }
          } catch(e) { }
        }
        if (!saved) saved = localStorage.getItem('liturgia.token');
        
        if (saved) {
          statusEl.textContent = 'Validating magic link token...';
          const res = await validateTokenAndActivate(saved);
          if (res.ok) {
            // Save the token to localStorage so it persists across page reloads
            localStorage.setItem('liturgia.token', saved);
            handleSignIn(saved, res.status);
            statusEl.textContent = 'Signed in via magic link!';
            showFlash('Successfully signed in!', 'success', 4000);
          } else {
            statusEl.textContent = 'Invalid or expired magic link.';
            console.error('Magic link validation failed:', res);
          }
        } else {
          console.warn('checkAuthSuccess: no saved token found after magic link redirect');
        }
      }, 100);
    }
  } catch(e) { console.warn('checkAuthSuccess failed', e); }
})();

// Client-style token modal (same UI/flow as desktop app)
function openTokenModal() {
  if (document.getElementById('token-entry-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'token-entry-modal';
  modal.style = 'position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;z-index:11000;';
  modal.innerHTML = `
    <div style="width:420px;padding:18px;background:var(--panel);border-radius:8px;box-shadow:0 10px 40px rgba(0,0,0,.6);">
      <h3>Enter Sign-in Token</h3>
      <p>Paste the token from the magic link page or generated token below.</p>
      <textarea id="token-input" style="width:100%;height:80px;font-size:12px;margin-top:8px;"></textarea>
      <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end;">
        <button id="token-cancel" class="btn">Cancel</button>
        <button id="token-save" class="btn primary">Validate & Save</button>
      </div>
      <div id="token-status" style="margin-top:8px;color:var(--muted);font-size:12px;"></div>
    </div>
  `;
  document.body.appendChild(modal);
  document.getElementById('token-cancel').onclick = () => { modal.remove(); };
  document.getElementById('token-save').onclick = async () => {
    const token = document.getElementById('token-input').value.trim();
    const status = document.getElementById('token-status');
    if (!token) { status.textContent = 'Enter a token.'; return; }
    status.textContent = 'Validating...';
    const result = await validateTokenAndActivate(token);
    if (result.ok) {
      const j = result.status;
      status.textContent = 'Token validated and saved.';
      // store token locally (so browser session can use it). We do not persist server-side here.
      try { localStorage.setItem('liturgia.token', token); } catch (e) {}
      // If running in the desktop app, store the token securely and mirror into settings (atomic save)
      try {
        if (window && window.ipc && typeof window.ipc.invoke === 'function') {
          try { await window.ipc.invoke('secure-set-token', token); } catch(e) { console.warn('secure-set-token failed', e); }
          try { await window.ipc.invoke('update-settings', { auth: { token } }); } catch(e) { /* ignore */ }
        }
      } catch(e) { /* ignore */ }
      handleSignIn(token, j);
      // Close the token modal after a short delay so the user sees the success message
      setTimeout(() => { modal.remove(); }, 400);
    } else {
      status.textContent = 'Validation failed. Use the magic link or generate a token.';
    }
  };
}

// Plan chooser modal (desktop client parity)
function openPlanModal(email, triggerBtn) {
  if (document.getElementById('plan-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'plan-modal';
  modal.style = 'position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;z-index:11010;';
  const last = localStorage.getItem('lastPurchasedPlan') || 'monthly';
  modal.innerHTML = `
    <div style="width:420px;padding:18px;background:var(--panel);border-radius:8px;box-shadow:0 10px 40px rgba(0,0,0,.6);">
      <h3>Choose a plan</h3>
      <div style="margin-top:12px;display:flex;flex-direction:column;gap:8px;">
        <label style="display:flex;align-items:center;gap:8px"><input type="radio" name="plan-modal" value="monthly" ${last==='monthly'?'checked':''}/> <strong>$12 / month</strong> — billed monthly</label>
        <label style="display:flex;align-items:center;gap:8px"><input type="radio" name="plan-modal" value="yearly" ${last==='yearly'?'checked':''}/> <strong>$100 / year</strong> — billed yearly</label>
      </div>
      <div style="margin-top:16px;display:flex;gap:8px;justify-content:flex-end;">
        <button id="plan-cancel" class="btn">Cancel</button>
        <button id="plan-confirm" class="btn primary">Subscribe</button>
      </div>
      <div id="plan-status" style="margin-top:8px;color:var(--muted);font-size:12px;"></div>
    </div>
  `;
  document.body.appendChild(modal);
  document.getElementById('plan-cancel').onclick = () => { modal.remove(); };
  document.getElementById('plan-confirm').onclick = async () => {
    const sel = document.querySelector('input[name="plan-modal"]:checked');
    const plan = sel ? sel.value : 'monthly';
    document.getElementById('plan-status').textContent = 'Creating checkout...';
    try { localStorage.setItem('lastPurchasedPlan', plan); } catch(e){}
    await createCheckout(email, triggerBtn, plan);
    modal.remove();
  };
}

// Helper: decode JWT payload without verifying signature (for UI only)
function decodeJwtPayload(token) {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    let b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    const json = atob(b64);
    return JSON.parse(json);
  } catch (e) { return null; }
}

function handleSignIn(token, statusObj) {
  try {
    const payload = decodeJwtPayload(token) || {};
    const email = payload.email || (statusObj && statusObj.email) || '';
    const active = statusObj && statusObj.active;
    const plan = statusObj && statusObj.plan ? statusObj.plan : (localStorage.getItem('lastPurchasedPlan') || 'n/a');
    // robust expiry formatting: support seconds or milliseconds
    const rawExp = statusObj && statusObj.expires_at ? statusObj.expires_at : null;
    let expires = 'n/a';

    // Debug: record token summary & cache it so copy operations have a canonical source
    try { console.debug('handleSignIn: token summary', { tokenPreview: (token && token.length>30 ? token.slice(0,24)+'…('+token.length+')' : token), tokenStartsWithDot: (token && token.startsWith('.')), email, plan }); } catch(e) {}
    try { if (token) revealedTokenCache['__current'] = token; } catch(e) {}
    if (rawExp) {
      let expMs = parseInt(rawExp, 10);
      if (expMs > 1e12) { /* already ms */ } else { expMs = expMs * 1000; }
      try { expires = new Date(expMs).toLocaleString(); } catch(e){ expires = String(rawExp); }
    } else {
      // if localStorage has a plan but no server expiry, indicate pending activation
      if (plan && plan !== 'n/a') expires = '(processing)';
    }

    // populate account info
    const acct = document.getElementById('acct-info');
    let planLabel = (plan === 'monthly') ? '$12/month' : (plan === 'yearly' ? '$100/year' : (plan || 'n/a'));
    // device token special-case: present nicer labels and expiration text
    if (plan === 'token') {
      planLabel = 'Device token (persistent)';
    }
    // decide how to display plan info depending on active status
    const planName = (plan === 'monthly') ? 'Monthly' : (plan === 'yearly') ? 'Yearly' : (plan === 'token') ? 'Device token' : (plan || 'n/a');
    const planPrice = (plan === 'monthly') ? '$12 / month' : (plan === 'yearly') ? '$100 / year' : '';
    const displayPlanName = active ? planName : 'No active plan';
    const displayPlanPrice = (active && planPrice) ? planPrice : '';

    acct.innerHTML = `
      <div class="acct-grid">
        <div class="acct-left">

          <div class="card" style="margin-bottom:10px;padding:12px;">
            <div class="acct-email"><strong>${email}</strong></div>
            <div class="acct-meta" style="margin-top:8px">
              <div class="meta-row"><span class="meta-label">Active</span><span class="meta-value">${active}</span></div>
              <div class="meta-row"><span class="meta-label">Plan</span><span class="meta-value">${planLabel}</span></div>
              <div class="meta-row"><span class="meta-label">Expires</span><span class="meta-value">${plan === 'token' ? 'never (persistent)' : expires}</span></div>
              ${statusObj && statusObj.sessions ? `<div class="meta-row"><span class="meta-label">Sessions</span><span class="meta-value">${(Array.isArray(statusObj.sessions) ? statusObj.sessions.length : 'n/a')}</span></div>` : ''}
            </div>
          </div>

          <div class="card" style="margin-bottom:10px;padding:12px;">
            <div style="display:flex;gap:8px;align-items:center;">
              <input id="token-field" class="input" type="password" readonly value="${token}" style="flex:1" />
              <button id="token-copy" class="btn" title="Copy token">Copy</button>
            </div>
            <div style="margin-top:8px;color:var(--muted);font-size:12px">Tokens are persistent and can be revoked individually. Generated tokens are shown only once; copy and store them safely.</div>
          </div>

          <div class="card" style="margin-bottom:10px;padding:12px;">
            <div style="display:flex;gap:8px;align-items:center;">
              <a id="download" class="btn primary" href="/liturgia/download.php">Download Client</a>
              <button id="signout" class="btn">Sign out</button>
            </div>
          </div>

        </div>

        <div class="acct-right">
          <div class="plan-card">
            <div class="plan-body">
              <div class="plan-title" style="font-size:14px;font-weight:700;margin-bottom:8px">Your plan</div>
              <div class="plan-header">
                <div class="plan-name">${displayPlanName}</div>
                <div class="plan-price">${displayPlanPrice}</div>
              </div>

              <div class="plan-meta" style="margin-top:10px">
                <div class="meta-row"><span class="meta-label">Status</span> <span class="meta-value">${active ? 'Active' : 'No active plan'}</span></div>
                <div class="meta-row"><span class="meta-label">Next billing</span> <span class="meta-value">${plan === 'token' ? 'n/a' : (expires || 'n/a')}</span></div>
              </div>

              <ul class="plan-features" style="margin-top:10px">
                <li>Desktop app access</li>
                <li>Automatic updates</li>
                <li>Priority support</li>
                <li>Offline access</li>
                <li>Access to beta features</li>
                <li>Cloud sync of preferences (where available)</li>
              </ul>
            </div>

            <div class="plan-footer">
              <div class="plan-actions" style="width:100%;display:block">
                ${!active ? `<a href="/liturgia/pricing.php" class="btn primary" style="width:100%;display:block;text-align:center;margin-bottom:8px">Purchase</a>` : ''}
                <button id="manage" class="btn" style="width:100%">Manage</button>
              </div>

              <div class="plan-support" style="font-size:12px;color:var(--muted);text-align:right;width:100%">Need help? <a href="mailto:support@jacqueb.me">support</a></div>

              <div class="acct-badge" style="margin-top:6px"></div>
            </div>
          </div>

        </div>
      </div>`;

    // Insert sessions card as its own standalone card (keeps subscription/plan separate)
    try {
      if (!document.getElementById('sessions-card')) {
        const sessionsHtml = `
          <div id="sessions-card" class="card" style="margin-top:12px;padding:12px;">
            <h4>Sessions & Devices <small id="session-count" style="color:var(--muted);font-weight:400;margin-left:8px"></small></h4>
            <div id="sessions-list" style="margin-top:8px"></div>
            <div style="margin-top:10px;display:flex;gap:8px;align-items:center">
              <input id="new-token-label" class="input" placeholder="Label (e.g., Home laptop)" style="flex:1;min-width:140px" />
              <button id="create-token" class="btn">Create Token</button>
            </div>
            <p style="margin-top:8px;color:var(--muted);font-size:12px">Tokens are persistent and can be revoked individually. Generated tokens are shown only once; copy and store them safely.</p>
          </div>`;
        const acctEl = document.getElementById('acct-info');
        if (acctEl) {
          // ensure sessions card is appended at the end of the left column so spacing works
          const parent = acctEl.parentNode;
          if (parent) parent.insertAdjacentHTML('beforeend', sessionsHtml);
        }
      }
    } catch (e) { console.warn('insert sessions card failed', e); }

    // Show Founder badge if present (check multiple possible fields and log for debugging)
    try {
      console.debug('handleSignIn: statusObj=', statusObj, 'payload=', payload);
      const isFounder = Boolean(
        (statusObj && (statusObj.founder || statusObj.is_founder || (Array.isArray(statusObj.roles) && statusObj.roles.includes('founder')))) ||
        (payload && (payload.founder || (Array.isArray(payload.roles) && payload.roles.includes('founder'))))
      );
      // Log clearly so the page console shows the authoritative founder status coming from the endpoint
      try { console.info('handleSignIn: founder=', isFounder); } catch(e) {}
      const header = document.querySelector('#account .acct-header');
      const accountEl = document.getElementById('account');
      const badgeHolder = document.querySelector('.acct-badge');
      if (isFounder) {
        if (header) {
          const sub = header.querySelector('.founder-subtext');
          if (sub) {
            sub.style.display = 'block';
            sub.textContent = 'You are a founding church. Thank you for your support in shaping Liturgia.';
          }
        }
        if (accountEl) accountEl.classList.add('founder-active');
        if (badgeHolder) badgeHolder.innerHTML = '<span class="founder-badge">Founder</span>';
      } else {
        if (header) {
          const sub = header.querySelector('.founder-subtext'); if (sub) sub.style.display = 'none';
        }
        if (accountEl) accountEl.classList.remove('founder-active');
        if (badgeHolder) badgeHolder.innerHTML = '';
      }
    } catch(e) { console.warn('failed to render founder badge', e); }

    // store canonical email for other actions
    currentAccountEmail = email || null;
    if (email) acct.dataset.email = email; else delete acct.dataset.email;

    // fill token field and attach manage handler
    const tf = document.getElementById('token-field');
    tf.value = token;
    try { tf.type = 'password'; } catch(e) { /* ignore */ }
    // store canonical token in dataset for diagnostics and robust copying
    try { tf.dataset.rawToken = token || ''; if (token) revealedTokenCache['__current'] = token; } catch(e) {}

    // Ensure the eye button uses the inline SVGs and the robust toggle logic
    const tokenEyeBtn = document.getElementById('token-eye');
    if (tokenEyeBtn) {
      tokenEyeBtn.setAttribute('aria-pressed','false');
      tokenEyeBtn.setAttribute('title','Show token');
      const openIcon = tokenEyeBtn.querySelector('.icon-eye-open');
      const closedIcon = tokenEyeBtn.querySelector('.icon-eye-closed');
      if (openIcon) openIcon.style.display = '';
      if (closedIcon) closedIcon.style.display = 'none';
    }

    // Copy button: read the current token field at click time so it survives input replacement
    const copyBtn = document.getElementById('token-copy');
    if (copyBtn) {
      copyBtn.onclick = async function(){
        try {
          const field = document.getElementById('token-field');
          let toCopy = field && field.value ? field.value : '';
          // Heuristic: if value starts with a dot or looks suspiciously short, prefer stored token (secure storage/localStorage or in-memory cache)
          if (toCopy && toCopy.startsWith('.')) {
            try { if (window && window.ipc && typeof window.ipc.invoke === 'function') { const st = await window.ipc.invoke('secure-get-token'); if (st) { toCopy = st; } } } catch(e) {}
            try { if (!toCopy) toCopy = localStorage.getItem('liturgia.token'); } catch(e) {}
            try { if (!toCopy && revealedTokenCache && revealedTokenCache['__current']) toCopy = revealedTokenCache['__current']; } catch(e) {}
          }
          // Additional debug log to help reproduce issues where token loses its leading id
          try { console.debug('copy top token: fieldVal=', field && (field.value||'') , 'finalCopy=', toCopy ? (toCopy.length>64 ? toCopy.slice(0,32)+'…('+toCopy.length+')' : toCopy) : '<empty>'); } catch(e) {}
          await navigator.clipboard.writeText(toCopy || '');
          const btn = this; const old = btn.textContent; btn.textContent = 'Copied'; setTimeout(()=>btn.textContent = old, 1000);
        } catch(e){ alert('Copy failed'); }
      };
    };

    // Sign out handler
    try {
      const signoutBtn = document.getElementById('signout');
      if (signoutBtn) {
        signoutBtn.onclick = async function(){
          try {
            try { if (window && window.ipc && typeof window.ipc.invoke === 'function') { await window.ipc.invoke('secure-delete-token'); await window.ipc.invoke('update-settings', { auth: null }); } } catch(e) {}
            try { localStorage.removeItem('liturgia.token'); } catch(e) {}
            // remove sessions card
            try { const sc = document.getElementById('sessions-card'); if (sc) sc.remove(); } catch(e) {}
            document.getElementById('account').style.display = 'none';
            const sendCard = document.getElementById('send-card'); if (sendCard) sendCard.style.display = '';
            const acctInfo = document.getElementById('acct-info'); if (acctInfo) acctInfo.innerHTML = '';
            statusEl.textContent = '';
            showFlash('Signed out', 'success', 3000);
          } catch(e) { console.warn('signout failed', e); showFlash('Sign out failed', 'info'); }
        };
      }
    } catch(e){ console.warn('signout attach failed', e); }

    // Attach subscribe handler (only present when user doesn't have an active plan)
    const subscribeBtn = document.getElementById('subscribe-account');
    if (subscribeBtn) {
      subscribeBtn.addEventListener('click', function(e){
        const acctElem = document.getElementById('acct-info');
        const emailFromAcct = currentAccountEmail || (acctElem ? acctElem.dataset.email : null) || null;
        const email = emailFromAcct || emailEl.value.trim();
        if (!email) { statusEl.textContent = 'No email found — enter an email above or sign in first.'; emailEl.focus(); console.warn('subscribe-account: no email available'); return; }
        openPlanModal(email, e.currentTarget);
      });
    }

    // Sessions management: fetch and render session tokens
    async function fetchSessions() {
      try {
        const s = document.getElementById('sessions-list'); if (!s) return;
        // prefer Authorization header; fall back to token query param
        const settings = (typeof window !== 'undefined' && window.location) ? null : null;
        let token = null;
        try { if (window && window.ipc && typeof window.ipc.invoke === 'function') token = await window.ipc.invoke('secure-get-token'); } catch(e) {}
        if (!token) token = localStorage.getItem('liturgia.token');
        console.log('fetchSessions: token present=', !!token);
        let res = null;
        // Prefer POST body token (works around some proxies/WAFs); fall back to header then query
        if (token) {
          try { res = await fetch((serverBase||'') + 'auth/list-tokens.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: 'token=' + encodeURIComponent(token) }); } catch(e) { /* ignore */ }
        }
        if ((!res || res.status === 401) && token) {
          // Try Authorization header
          try { res = await fetch((serverBase||'') + 'auth/list-tokens.php', { headers: { 'Authorization': 'Bearer ' + token } }); } catch(e) { /* ignore */ }
        }
        if ((!res || res.status === 401) && token) {
          // Last resort: query param
          try { res = await fetch((serverBase||'') + 'auth/list-tokens.php?token=' + encodeURIComponent(token)); } catch(e) { /* ignore */ }
        }
        if (!res.ok) {
          // If unauthorized, try to decode JWT locally as a fallback (magic-link session)
          if (res.status === 401 && token) {
            try {
              const payload = decodeJwtPayload(token);
              if (payload && payload.email) {
                const ts = new Date().toISOString();
                renderSessions([{ id: 'magiclink-' + (token.slice(0,12)), label: 'Magic link', device: 'email', email: payload.email, created_at: ts, last_seen: ts }]);
                return;
              }
            } catch(e) { /* ignore */ }
          }
          s.innerHTML = `<p style="color:var(--muted);">Failed to load sessions (${res.status}).</p>`; return;
        }
        const j = await res.json();
        renderSessions(j.tokens || []);
      } catch (e) { console.warn('fetchSessions failed', e); }
    }

    function renderSessions(tokens) {
      const s = document.getElementById('sessions-list'); if (!s) return;
      const countEl = document.getElementById('session-count'); if (countEl) countEl.textContent = `(${tokens.length})`;
      if (!tokens.length) { s.innerHTML = '<p style="color:var(--muted)">No active sessions</p>'; return; }
      s.innerHTML = '';
      // If server returned raw tokens (e.g., immediately after creation), cache them for instant copy
      tokens.forEach(t => { if (t && t.id && t.token) { try { revealedTokenCache[t.id] = t.token; } catch(e) {} }
        const div = document.createElement('div'); div.className = 'meta-row'; div.style.display = 'flex'; div.style.justifyContent = 'space-between'; div.style.alignItems = 'center';
        const left = document.createElement('div'); left.innerHTML = `<div style="font-weight:700">${t.label || (t.device || 'Unnamed')}</div><div style="color:var(--muted);font-size:12px">Created: ${t.created_at || 'n/a'}${t.last_seen ? ' • Last: ' + t.last_seen : ''}</div>`;
        const right = document.createElement('div');
        const copyBtn = document.createElement('button'); copyBtn.className = 'btn'; copyBtn.textContent = 'Copy'; copyBtn.onclick = async () => {
          try {

            // If we have it in cache, copy immediately without a server round-trip
            if (revealedTokenCache && revealedTokenCache[t.id]) {
              try { await navigator.clipboard.writeText(revealedTokenCache[t.id]); showFlash('Token copied (cached)', 'success', 2000); return; } catch(e){ /* continue to fetch if clipboard fails */ }
            }

            // request secret token value from server
            let authToken = null;
            try { if (window && window.ipc && typeof window.ipc.invoke === 'function') authToken = await window.ipc.invoke('secure-get-token'); } catch(e) {}
            if (!authToken) authToken = localStorage.getItem('liturgia.token');
            const hdr = authToken ? { 'Authorization': 'Bearer ' + authToken } : {};
            try {
              let url = (serverBase||'') + 'auth/show-token.php?id=' + encodeURIComponent(t.id);
              let tkRes = await fetch(url, { headers: hdr });
              // If server rejects (401), try POSTing token in body as a fallback (avoids some proxy/WAF GET blocking)
              if (tkRes.status === 401 && authToken) {
                try { tkRes = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'token=' + encodeURIComponent(authToken) }); } catch(e) {}
              }
              if (tkRes.ok) {
                const tj = await tkRes.json();
                if (tj && tj.token) {
                  // cache it so future copies don't require a request
                  try { revealedTokenCache[t.id] = tj.token; } catch(e) {}
                  await navigator.clipboard.writeText(tj.token);
                  showFlash('Token copied to clipboard', 'success', 2000);
                } else {
                  showFlash('Failed to retrieve token', 'info');
                }
              } else if (tkRes.status === 403) {
                const body = await tkRes.json().catch(()=>null);
                if (body && body.error === 'token_not_retrievable') {
                  showFlash('Token already revealed — generate a new token to replace it.', 'info', 5000);
                } else {
                  showFlash('Failed to retrieve token (forbidden)', 'info');
                }
                showFlash((body && body.message) ? body.message : 'Token values are shown only once (create a new token).', 'info', 6000);
              } else {
                showFlash('Failed to retrieve token', 'info');
              }
            } catch(e) { console.warn('copy token failed', e); showFlash('Failed to copy token', 'info'); }
          } catch (e) { console.warn(e); }
        };
        const revokeBtn = document.createElement('button'); revokeBtn.className = 'btn'; revokeBtn.textContent = 'Revoke'; revokeBtn.onclick = async () => {
          if (!confirm('Revoke this token? It will immediately sign out that device.')) return;
          try {
            let authToken = null;
            try { if (window && window.ipc && typeof window.ipc.invoke === 'function') authToken = await window.ipc.invoke('secure-get-token'); } catch(e) {}
            if (!authToken) authToken = localStorage.getItem('liturgia.token');
            const headers = {'Content-Type':'application/x-www-form-urlencoded'};
            if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
            const body = `id=${encodeURIComponent(t.id)}` + (authToken ? `&token=${encodeURIComponent(authToken)}` : '');
            let res = await fetch((serverBase||'') + 'auth/revoke-token.php', { method: 'POST', headers, body });
            if (res.status === 401 && authToken) {
              try { res = await fetch((serverBase||'') + 'auth/revoke-token.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `id=${encodeURIComponent(t.id)}&token=${encodeURIComponent(authToken)}` }); } catch(e) {}
            }
            if (res.ok) { try { delete revealedTokenCache[t.id]; } catch(e) {} showFlash('Token revoked', 'success', 3000); fetchSessions(); } else { showFlash('Failed to revoke token', 'info'); }
          } catch(e) { console.warn('revoke failed', e); showFlash('Failed to revoke token', 'info'); }
        };

        // Regenerate: create a fresh token with same label/device and copy it immediately
        const regenBtn = document.createElement('button'); regenBtn.className = 'btn'; regenBtn.textContent = 'Regenerate'; regenBtn.onclick = async () => {
          if (!confirm('Generate a replacement token for this device? The old token will remain valid until revoked.')) return;
          try {
            let authToken = null;
            try { if (window && window.ipc && typeof window.ipc.invoke === 'function') authToken = await window.ipc.invoke('secure-get-token'); } catch(e) {}
            if (!authToken) authToken = localStorage.getItem('liturgia.token');
            const headers = {'Content-Type':'application/x-www-form-urlencoded'}; if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
            const body = `label=${encodeURIComponent(t.label || '')}&device=${encodeURIComponent(t.device || '')}` + (authToken ? `&token=${encodeURIComponent(authToken)}` : '');
            let res = await fetch((serverBase||'') + 'auth/generate-token.php', { method: 'POST', headers, body });
            if (res.status === 401 && authToken) {
              try { res = await fetch((serverBase||'') + 'auth/generate-token.php?token=' + encodeURIComponent(authToken), { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `label=${encodeURIComponent(t.label || '')}&device=${encodeURIComponent(t.device || '')}` }); } catch(e) {}
            }
            if (res && res.ok) {
              const j = await res.json().catch(()=>null);
              if (j && j.token) {
                try { revealedTokenCache[j.id] = j.token; await navigator.clipboard.writeText(j.token); showFlash('New token created and copied', 'success', 4000); } catch(e) { showFlash('New token created (copy failed)', 'success', 4000); }
                fetchSessions();
              } else { showFlash('Failed to create replacement token', 'info'); }
            } else {
              showFlash('Failed to create replacement token', 'info');
            }
          } catch(e) { console.warn('regenerate failed', e); showFlash('Failed to create replacement token', 'info'); }
        };

        right.appendChild(copyBtn); right.appendChild(revokeBtn); right.appendChild(regenBtn);
        div.appendChild(left); div.appendChild(right); s.appendChild(div);
      });
    }

    // Create new token
    try { document.getElementById('create-token').addEventListener('click', async function(){
      const lbl = (document.getElementById('new-token-label') || {}).value || ''; const device = navigator.userAgent || 'browser';
      try {
        let authToken = null;
        try { if (window && window.ipc && typeof window.ipc.invoke === 'function') authToken = await window.ipc.invoke('secure-get-token'); } catch(e) {}
        if (!authToken) authToken = localStorage.getItem('liturgia.token');
        const headers = {'Content-Type':'application/x-www-form-urlencoded'}; if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
        const bodyParams = `label=${encodeURIComponent(lbl)}&device=${encodeURIComponent(device)}` + (authToken ? `&token=${encodeURIComponent(authToken)}` : '');
        let res = await fetch((serverBase||'') + 'auth/generate-token.php', { method: 'POST', headers, body: bodyParams });
        if (res.status === 401 && authToken) {
          try { res = await fetch((serverBase||'') + 'auth/generate-token.php?token=' + encodeURIComponent(authToken), { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `label=${encodeURIComponent(lbl)}&device=${encodeURIComponent(device)}` }); } catch(e) {}
        }
        if (res && res.ok) {
          const j = await res.json().catch(()=>null);
          if (j && j.token) {
            try { revealedTokenCache[j.id] = j.token; await navigator.clipboard.writeText(j.token); showFlash('Token created and copied (shown once)', 'success', 6000); } catch(e) { showFlash('Token created (copy failed)', 'success', 4000); }
            fetchSessions();
          } else {
            showFlash('Token created (copy failed)', 'success', 4000);
          }
        } else {
          showFlash('Failed to create token', 'info');
        }
      } catch(e) { console.warn('create token failed', e); showFlash('Failed to create token', 'info'); }
    }, false); } catch(e) {}

    // initial fetch of sessions
    try { fetchSessions(); } catch(e) {}


    document.getElementById('manage').onclick = async () => {
      try {
        // Prefer Authorization header, but fallback to form body if server rejects it (returns 401)
        let r = await fetch(serverBase + 'create-portal-session.php', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token } });
        if (r.status === 401) {
          console.warn('create-portal-session: Authorization header rejected (401); trying fallback POST');
          r = await fetch(serverBase + 'create-portal-session.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: `token=${encodeURIComponent(token)}` });
        }
        if (!r || (r.status && r.status !== 200 && r.status !== 302)) {
          showFlash('Failed to open portal (authorization failed)', 'info', 5000);
          return;
        }
        const j2 = await r.json().catch(()=>null);
        if (j2 && j2.url) window.open(j2.url, '_blank'); else showFlash('Failed to open portal', 'info', 5000);
      } catch (e) { console.warn('manage handler failed', e); showFlash('Failed to open portal', 'info', 5000); }
    };

    // hide the send-card and show account
    const sendCard = document.getElementById('send-card'); if (sendCard) sendCard.style.display = 'none';
    document.getElementById('account').style.display = '';
    statusEl.textContent = 'Verified.';
  } catch (e) { console.warn('handleSignIn error', e); }
}

</script>
<script>
// responsive nav popover
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>
</body>
</html> 
