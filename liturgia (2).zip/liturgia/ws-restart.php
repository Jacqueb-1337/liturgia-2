<?php
header('Content-Type: text/plain');

$wsUrl = 'http://apiliturgia.jacqueb.me:3001/restart';

echo "Sending restart command to WebSocket server...\n\n";

$ch = curl_init($wsUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    echo "Response: $response\n";
    echo "\n";
    echo "Server should restart automatically if you have:\n";
    echo "  - PM2 configured\n";
    echo "  - systemd service configured\n";
    echo "  - cPanel Node.js app (restart happens automatically)\n";
    echo "\n";
    echo "Wait 5 seconds, then check status:\n";
    echo "https://jacqueb.me/liturgia/ws-status.php\n";
} else {
    echo "ERROR: Failed to send restart command\n";
    echo "HTTP Code: $httpCode\n";
    echo "Response: $response\n";
    echo "\n";
    echo "The server may be:\n";
    echo "  - Not running\n";
    echo "  - Not accessible from this server\n";
    echo "  - Firewall blocking the connection\n";
    echo "\n";
    echo "You may need to restart manually via cPanel:\n";
    echo "cPanel → Setup Node.js App → apiliturgia.jacqueb.me → Restart\n";
}
?>
