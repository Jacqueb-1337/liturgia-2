<?php
header('Content-Type: application/json; charset=utf-8');
try {
    $info = [];
    $info['ok'] = true;
    $info['php_version'] = phpversion();
    $info['php_sapi'] = php_sapi_name();
    $info['error_log'] = ini_get('error_log');
    $info['display_errors'] = ini_get('display_errors');
    $info['log_errors'] = ini_get('log_errors');
    $info['cwd'] = getcwd();
    echo json_encode($info);
} catch (Throwable $t) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>$t->getMessage()]);
}
