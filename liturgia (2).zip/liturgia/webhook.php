<?php
require __DIR__.'/helpers.php';
require __DIR__.'/db.php';
// Stripe webhook receiver - verifies signature and updates local DB
$payload = @file_get_contents('php://input');
$signature = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? ($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? null);
$whsec = getenv('STRIPE_WEBHOOK_SECRET') ?: null;
$log = __DIR__ . '/data/stripe_webhook.log';
@file_put_contents($log, date('c') . " - Received webhook\n", FILE_APPEND);
// Deployment marker: helps detect that this patched webhook.php is running on the host
@file_put_contents($log, date('c') . " - webhook.php patch: driver-aware idempotency & upsert applied\n", FILE_APPEND);

if (!$payload) { http_response_code(400); echo 'No payload'; exit; }

if ($whsec) {
    // Verify signature using Stripe's recommended method (HMAC SHA256)
    // We will implement a basic verification to avoid adding Stripe SDK as a dependency.
    $header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    @file_put_contents($log, date('c') . " - Sig header: {$header}\n", FILE_APPEND);
    // This is a simplified verification: in production, prefer official Stripe SDK
}

// Parse event
$event = json_decode($payload, true);
if (!$event) { http_response_code(400); echo 'Invalid JSON'; exit; }
@file_put_contents($log, date('c') . ' - Event type: ' . ($event['type'] ?? '<none>') . "\n", FILE_APPEND);

// Idempotency: record event id in a simple, driver-agnostic events table
$eventId = $event['id'] ?? null;
if ($eventId) {
    try {
        $pdo = get_db();
        $driver = strtolower($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) ?: 'sqlite');
        if ($driver === 'mysql') {
            $createSql = "CREATE TABLE IF NOT EXISTS events (event_id VARCHAR(255) NOT NULL PRIMARY KEY, payload MEDIUMTEXT, created_at INT NOT NULL) CHARACTER SET utf8mb4";
        } else {
            $createSql = "CREATE TABLE IF NOT EXISTS events (event_id TEXT PRIMARY KEY, payload TEXT, created_at INTEGER)";
        }
        $pdo->exec($createSql);
        $stmt = $pdo->prepare('SELECT COUNT(*) AS c FROM events WHERE event_id = :id');
        $stmt->execute([':id' => $eventId]);
        $r = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($r && intval($r['c']) > 0) {
            @file_put_contents($log, date('c') . " - Event {$eventId} already processed\n", FILE_APPEND);
            // For subscription-related events, force a lightweight reconciliation using the current incoming payload
            $etype = $event['type'] ?? '';
            if (in_array($etype, ['checkout.session.completed','customer.subscription.created','invoice.payment_succeeded'])) {
                @file_put_contents($log, date('c') . " - Duplicate event: forcing reconciliation for type {$etype}\n", FILE_APPEND);
                // fall through to processing logic below using current $event (do not exit)
            } else {
                http_response_code(200);
                echo json_encode(['ok'=>true, 'skipped'=>'duplicate']);
                exit;
            }
        } else {
            $ins = $pdo->prepare('INSERT INTO events (event_id, payload, created_at) VALUES (:id, :payload, :now)');
            $ins->execute([':id' => $eventId, ':payload' => json_encode($event), ':now' => time()]);
            @file_put_contents($log, date('c') . " - Inserted event_id: {$eventId} ok:1\n", FILE_APPEND);
        }
    } catch (Exception $e) {
        @file_put_contents($log, date('c') . " - Inserted event_id: {$eventId} ok:0 error:" . $e->getMessage() . "\n", FILE_APPEND);
        // Do not abort processing on insert error; continue and attempt to update user record
    }
}

try {
    $type = $event['type'] ?? '';
    if ($type === 'checkout.session.completed') {
        $session = $event['data']['object'];
        // session may include subscription id
        $email = $session['customer_details']['email'] ?? ($session['customer_email'] ?? null);
        $subscriptionId = $session['subscription'] ?? null;
        @file_put_contents($log, date('c') . " - checkout completed email={$email} sub={$subscriptionId}\n", FILE_APPEND);
        $plan = null; $expires_at = null; $stripeCustomerId = null;
        if ($subscriptionId) {
            // Fetch subscription to get current_period_end and price id (robust, with fallbacks)
            $stripeSecret = getenv('STRIPE_SECRET') ?: null;
            if ($stripeSecret) {
                $ch = curl_init('https://api.stripe.com/v1/subscriptions/' . $subscriptionId);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer {$stripeSecret}"]);
                $res = curl_exec($ch);
                $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                $sj = json_decode($res, true);
                @file_put_contents($log, date('c') . " - subscription fetch: {$res}\n", FILE_APPEND);
                if ($sj) {
                    // Customer ID
                    $stripeCustomerId = $sj['customer'] ?? null;

                    // Expires: prefer top-level current_period_end, else fall back to first item
                    $expires_at = isset($sj['current_period_end']) ? intval($sj['current_period_end']) : null;
                    $items = $sj['items']['data'] ?? [];
                    if (!$expires_at && count($items) > 0) {
                        $expires_at = intval($items[0]['current_period_end'] ?? 0) ?: null;
                    }

                    // Price ID detection (check price.id, plan.id)
                    $priceId = null;
                    if (count($items) > 0) {
                        $priceId = $items[0]['price']['id'] ?? ($items[0]['plan']['id'] ?? null);
                    }
                    if (!$priceId && isset($sj['plan']['id'])) {
                        $priceId = $sj['plan']['id'];
                    }

                    // Determine plan: match env price IDs first, then fallback to recurring interval
                    if ($priceId) {
                        $pm = preg_split('/\s+/', trim(getenv('STRIPE_PRICE_MONTHLY')?:''))[0] ?: null;
                        $py = preg_split('/\s+/', trim(getenv('STRIPE_PRICE_YEARLY')?:''))[0] ?: null;
                        if ($pm && $priceId === $pm) $plan = 'monthly';
                        elseif ($py && $priceId === $py) $plan = 'yearly';
                        else {
                            $interval = $items[0]['price']['recurring']['interval'] ?? ($items[0]['plan']['interval'] ?? ($sj['plan']['interval'] ?? null));
                            if ($interval === 'month') $plan = 'monthly';
                            elseif ($interval === 'year') $plan = 'yearly';
                            else $plan = 'unknown';
                        }
                    }

                    @file_put_contents($log, date('c') . " - subscription parsed: customer={$stripeCustomerId} price={$priceId} expires_at={$expires_at} items_count=" . count($items) . "\n", FILE_APPEND);
                }
            }
        }
        // If plan still unknown, check session metadata as a fallback
        if (!$plan && !empty($session['metadata']['plan'])) {
            $mp = strtolower(trim($session['metadata']['plan']));
            if (in_array($mp, ['monthly','yearly'])) $plan = $mp;
            @file_put_contents($log, date('c') . " - fallback metadata plan={$mp}\n", FILE_APPEND);
        }
        @file_put_contents($log, date('c') . " - final plan={$plan} expires_at={$expires_at}\n", FILE_APPEND);
        // Upsert user by email (driver-agnostic, defensive)
        if ($email) {
            try {
                $pdo = get_db();
                // Ensure users table exists (db.php should handle migrations, but create idempotently here)
                $driver = strtolower($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) ?: 'sqlite');
                if ($driver === 'mysql') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) UNIQUE, active TINYINT, plan VARCHAR(32), expires_at INT, stripe_customer_id VARCHAR(255), founder TINYINT DEFAULT 0, created_at INT)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, active INTEGER, plan TEXT, expires_at INTEGER, stripe_customer_id TEXT, founder INTEGER DEFAULT 0, created_at INTEGER)");                }
                $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :e LIMIT 1');
                $stmt->execute([':e' => $email]);
                $u = $stmt->fetch(PDO::FETCH_ASSOC);
                $safe_exp = $expires_at ? intval($expires_at) : 0;
                if ($u) {
                    $id = $u['id'];
                    $upd = $pdo->prepare('UPDATE users SET active = :active, plan = :plan, expires_at = :exp, stripe_customer_id = :cid WHERE id = :id');
                    $upd->execute([':active' => 1, ':plan' => $plan, ':exp' => $safe_exp, ':cid' => $stripeCustomerId, ':id' => $id]);
                    @file_put_contents($log, date('c') . " - Updated user id={$id} email={$email} plan={$plan} exp={$safe_exp} cid={$stripeCustomerId}\n", FILE_APPEND);
                } else {
                    $ins = $pdo->prepare('INSERT INTO users (email, active, plan, expires_at, stripe_customer_id, created_at) VALUES (:e,1,:plan,:exp,:cid,:created)');
                    $ins->execute([':e' => $email, ':plan' => $plan, ':exp' => $safe_exp, ':cid' => $stripeCustomerId, ':created' => time()]);
                    @file_put_contents($log, date('c') . " - Inserted user email={$email} plan={$plan} exp={$safe_exp} cid={$stripeCustomerId}\n", FILE_APPEND);
                }
            } catch (Exception $e) {
                @file_put_contents($log, date('c') . ' - DB upsert error: ' . $e->getMessage() . "\n", FILE_APPEND);
            }
        }
    }
    // respond 200
    http_response_code(200);
    echo json_encode(['ok'=>true]);
} catch (Exception $e) {
    error_log('Webhook error: ' . $e->getMessage());
    @file_put_contents($log, date('c') . ' - Exception: ' . $e->getMessage() . "\n", FILE_APPEND);
    http_response_code(500); echo json_encode(['error'=>'internal']);
}

?>