#!/bin/sh
# Small helper to lint webhook.php, check for vendor, and run a HEAD request
set -e
echo "PHP lint webhook.php:"
php -l webhook.php || exit 1
echo
if [ -f vendor/autoload.php ]; then
  echo "vendor/autoload.php exists"
else
  echo "vendor/autoload.php MISSING"
fi
echo
URL=${1:-https://jacqueb.me/liturgia/webhook.php}
echo "HEAD $URL"
curl -v -I "$URL"
