<?php
// Pricing page
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Pricing — Liturgia Worship Church Presentation Software</title>
  <meta name="description" content="Simple per-device licensing for Liturgia Worship. One license covers multiple devices. First 50 users receive a free Founding license and a one-year subscription.">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://jacqueb.me/liturgia/pricing.php">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Liturgia">
  <meta property="og:url" content="https://jacqueb.me/liturgia/pricing.php">
  <meta property="og:title" content="Pricing — Liturgia Worship">
  <meta property="og:description" content="Simple per-device licensing for Liturgia Worship. One license covers multiple devices. First 50 users receive a free Founding license and a one-year subscription.">
  <meta property="og:image" content="https://jacqueb.me/liturgia/logo.png">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Pricing — Liturgia Worship">
  <meta name="twitter:description" content="Simple per-device licensing for Liturgia Worship. One license covers multiple devices. First 50 users receive a free Founding license and a one-year subscription.">
  <link rel="stylesheet" href="/liturgia/style.css">
  <link rel="stylesheet" href="/liturgia/style-small.css">
  <link rel="icon" href="/liturgia/logo.png" type="image/png">
</head>
<body class="dark pricing-page">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia Worship" class="brand-logo"/>
        <span class="product">Liturgia <span class="product-sub">• Worship</span></span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      <nav class="nav">
        <a href="/liturgia/index.php">Home</a>
        <span class="nav-current">Pricing</span>
        <a href="/liturgia/account.php">Account</a>
        <a href="/liturgia/download.php">Download</a>
        <a href="/liturgia/apps.php">Apps</a>
      </nav>
    </div>
  </header>

  <main class="hero">
    <div class="container center">
      <h1>Simple pricing that fits teams</h1>
      <p class="lede">One license covers multiple devices — present from a laptop, desktop or tablet without extra fuss. First 50 users receive a free Founding license and a one-year subscription — join early.</p>
      <div class="actions">
        <a class="btn primary" href="/liturgia/account.php">Subscribe / Manage Account</a>
      </div>
    </div>
  </main>

  <section class="features">
    <div class="container">
      <h2>Plans</h2>
      <div style="display:flex;gap:18px;flex-wrap:wrap;margin-top:12px;">
        <div style="flex:1;min-width:220px;background:var(--panel);padding:18px;border-radius:8px;">
          <h3>Monthly</h3>
          <p style="font-size:20px;margin:6px 0;"><strong>$12</strong> / month</p>
          <p style="color:var(--muted);">Billed monthly. Cancel anytime.</p>
          <ul style="margin-top:12px;color:var(--muted);">
            <li>Automatic updates and cloud sync</li>
            <li>EasyWorship import</li>
          </ul>
          <div style="margin-top:12px;"><button class="btn" onclick="openPricingModal('monthly')">Choose Monthly</button></div>
        </div>
        <div style="flex:1;min-width:220px;background:var(--panel);padding:18px;border-radius:8px;">
          <h3>Yearly</h3>
          <p style="font-size:20px;margin:6px 0;"><strong>$100</strong> / year</p>
          <p style="color:var(--muted);">Billed yearly — best value.</p>
          <ul style="margin-top:12px;color:var(--muted);">
            <li>Save compared to monthly</li>
            <li>Priority support</li>
            <li>EasyWorship import</li>
          </ul>
          <div style="margin-top:12px;"><button class="btn primary" onclick="openPricingModal('yearly')">Choose Yearly</button></div>
        </div>
      </div>

    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <small>© Liturgia • <strong>Worship without distraction</strong></small>
    </div>
  </footer>

<script>
// Pricing page: inline checkout flow (asks for email, then creates a Stripe Checkout session)
function openPricingModal(plan) {
  if (document.getElementById('pricing-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'pricing-modal';
  modal.style = 'position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,0.6);display:flex;align-items:center;justify-content:center;z-index:11020;';
  const storedEmail = localStorage.getItem('liturgia.lastEmail') || '';
  modal.innerHTML = `
    <div style="width:420px;padding:18px;background:var(--panel);border-radius:8px;box-shadow:0 10px 40px rgba(0,0,0,.6);">
      <h3>Start Checkout — ${plan === 'yearly' ? 'Yearly' : 'Monthly'}</h3>
      <p>Enter the email to use for this purchase.</p>
      <input id="pricing-email" class="input" style="width:100%;margin-top:8px;" value="${storedEmail}" placeholder="you@example.com" />
      <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end;">
        <button id="pricing-cancel" class="btn">Cancel</button>
        <button id="pricing-confirm" class="btn primary">Continue to Checkout</button>
      </div>
      <div id="pricing-status" style="margin-top:8px;color:var(--muted);font-size:12px;"></div>
    </div>
  `;
  document.body.appendChild(modal);
  document.getElementById('pricing-cancel').onclick = () => { modal.remove(); };
  document.getElementById('pricing-confirm').onclick = async () => {
    const email = document.getElementById('pricing-email').value.trim();
    const status = document.getElementById('pricing-status');
    console.log('pricing: checkout for', email, plan);
    const blocked = ['you@example.com','test@example.com','example@example.com','no-reply@example.com'];
    if (blocked.includes(email.toLowerCase())) { status.textContent = 'Enter a real email address.'; return; }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { status.textContent = 'Enter a valid email.'; return; }
    status.textContent = 'Creating checkout...';
    try {
      localStorage.setItem('liturgia.lastEmail', email);
      localStorage.setItem('lastPurchasedPlan', plan);
      const body = `email=${encodeURIComponent(email)}&plan=${encodeURIComponent(plan)}`;
      let res = await fetch('/liturgia/create-checkout-session.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body });
      let j = null; try { j = await res.json(); } catch (e) { status.textContent = 'Server error creating checkout'; return; }
      if (j && j.url) { window.open(j.url, '_blank'); status.textContent = 'Checkout opened in browser.'; modal.remove(); }
      else { status.textContent = 'Failed to create checkout: ' + (j && j.error ? j.error : ('HTTP '+(res?res.status:'?'))); }
    } catch (e) { status.textContent = 'Error creating checkout'; }
  };
}
</script>

<script>
// responsive nav popover
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>

</body>
</html>