<?php
// reconcile-subscription.php
// Usage (web): https://your-site/liturgia/reconcile-subscription.php?sub=sub_...&secret=INIT_SECRET
// Usage (cli): php reconcile-subscription.php sub_... <secret>
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
$secret = getenv('INIT_SECRET') ?: null;
$provided = $_GET['secret'] ?? ($argv[2] ?? null);
if (!$provided || !$secret || $provided !== $secret) {
    http_response_code(403);
    echo json_encode(['error'=>'forbidden']);
    exit;
}
$subId = $_GET['sub'] ?? ($argv[1] ?? null);
if (!$subId) {
    http_response_code(400);
    echo json_encode(['error'=>'missing sub id']);
    exit;
}
$log = __DIR__ . '/data/stripe_webhook.log';
@file_put_contents($log, date('c') . " - reconcile: sub={$subId}\n", FILE_APPEND);
$stripeSecret = getenv('STRIPE_SECRET') ?: null;
if (!$stripeSecret) { @file_put_contents($log, date('c') . " - reconcile: missing STRIPE_SECRET\n", FILE_APPEND); http_response_code(500); echo json_encode(['error'=>'no stripe secret']); exit; }
// Fetch subscription
$ch = curl_init('https://api.stripe.com/v1/subscriptions/' . $subId);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer {$stripeSecret}"]);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$sj = json_decode($res, true);
@file_put_contents($log, date('c') . " - reconcile: subscription fetch: " . substr($res,0,2000) . "\n", FILE_APPEND);
if (!$sj || $code < 200 || $code >= 300) { http_response_code(502); echo json_encode(['error'=>'stripe fetch failed','detail'=>$sj]); exit; }
// Parse useful fields
$customer = $sj['customer'] ?? null;
$expires = isset($sj['current_period_end']) ? intval($sj['current_period_end']) : null;
$items = $sj['items']['data'] ?? [];
$priceId = null; $interval = null;
if (count($items) > 0) {
    $priceId = $items[0]['price']['id'] ?? ($items[0]['plan']['id'] ?? null);
    $interval = $items[0]['price']['recurring']['interval'] ?? ($items[0]['plan']['interval'] ?? null);
    if (!$expires) $expires = intval($items[0]['current_period_end'] ?? 0) ?: $expires;
}
// Determine plan
$pm = preg_split('/\s+/', trim(getenv('STRIPE_PRICE_MONTHLY')?:''))[0] ?: null;
$py = preg_split('/\s+/', trim(getenv('STRIPE_PRICE_YEARLY')?:''))[0] ?: null;
$plan = null;
if ($priceId) {
    if ($pm && $priceId === $pm) $plan = 'monthly';
    elseif ($py && $priceId === $py) $plan = 'yearly';
}
if (!$plan && $interval) { $plan = ($interval === 'month') ? 'monthly' : (($interval === 'year') ? 'yearly' : 'unknown'); }
// Fetch customer email if possible
$email = null;
if ($customer && is_string($customer)) {
    $ch = curl_init('https://api.stripe.com/v1/customers/' . $customer);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer {$stripeSecret}"]);
    $cres = curl_exec($ch);
    $code2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $cj = json_decode($cres, true);
    @file_put_contents($log, date('c') . " - reconcile: customer fetch: " . substr($cres,0,2000) . "\n", FILE_APPEND);
    $email = $cj['email'] ?? null;
}
// If still no email, try subscription->default source or metadata
if (!$email) $email = $sj['metadata']['email'] ?? null;
// Upsert into DB
try {
    $pdo = get_db();
    $driver = strtolower($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) ?: 'sqlite');
    if ($driver === 'mysql') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) UNIQUE, active TINYINT, plan VARCHAR(32), expires_at INT, stripe_customer_id VARCHAR(255), founder TINYINT DEFAULT 0, created_at INT)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, active INTEGER, plan TEXT, expires_at INTEGER, stripe_customer_id TEXT, founder INTEGER DEFAULT 0, created_at INTEGER)");
    }
    if ($email) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :e LIMIT 1');
        $stmt->execute([':e'=>$email]);
        $u = $stmt->fetch(PDO::FETCH_ASSOC);
        $safe_exp = $expires ? intval($expires) : 0;
        if ($u) {
            $upd = $pdo->prepare('UPDATE users SET active=1, plan=:plan, expires_at=:exp, stripe_customer_id=:cid WHERE id=:id');
            $upd->execute([':plan'=>$plan, ':exp'=>$safe_exp, ':cid'=>$customer, ':id'=>$u['id']]);
            @file_put_contents($log, date('c') . " - reconcile: Updated user id={$u['id']} email={$email} plan={$plan} exp={$safe_exp} cid={$customer}\n", FILE_APPEND);
            echo json_encode(['ok'=>true,'updated'=>$u['id']]);
            exit;
        } else {
            $ins = $pdo->prepare('INSERT INTO users (email, active, plan, expires_at, stripe_customer_id, created_at) VALUES (:e,1,:plan,:exp,:cid,:created)');
            $ins->execute([':e'=>$email, ':plan'=>$plan, ':exp'=>$safe_exp, ':cid'=>$customer, ':created'=>time()]);
            $id = $pdo->lastInsertId();
            @file_put_contents($log, date('c') . " - reconcile: Inserted user id={$id} email={$email} plan={$plan} exp={$safe_exp} cid={$customer}\n", FILE_APPEND);
            echo json_encode(['ok'=>true,'inserted'=>$id]);
            exit;
        }
    } else {
        @file_put_contents($log, date('c') . " - reconcile: no email for subscription {$subId}\n", FILE_APPEND);
        http_response_code(400);
        echo json_encode(['error'=>'no email available from subscription or customer']);
        exit;
    }
} catch (Exception $e) {
    @file_put_contents($log, date('c') . " - reconcile: DB error: " . $e->getMessage() . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error'=>'db error','detail'=>$e->getMessage()]);
    exit;
}
?>