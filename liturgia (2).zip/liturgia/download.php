<?php

$RELEASE_TAG = 'latest';
$REPO = 'Jacqueb-1337/liturgia-2';

$map = [
  'linux-appimage' => 'liturgia.AppImage',
  'linux-deb' => 'liturgia.deb',
  'mac' => 'liturgia.dmg',
  'windows' => 'liturgia.exe',
  'android' => 'liturgia-remote.apk'
];

$repo_override = [
  'android' => 'Jacqueb-1337/liturgia-remote'
];

$platform = isset($_GET['platform']) ? $_GET['platform'] : '';
if (!array_key_exists($platform, $map)) {
  // If invalid or missing, show a small selection page and links (fallback)
  $available = $map;
  header('Content-Type: text/html; charset=utf-8');
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Download Liturgia • Worship — Choose your platform</title>
    <link rel="stylesheet" href="/liturgia/style.css">
  </head>
  <body class="dark">
    <header class="site-header">
      <div class="container">
        <div class="brand">
          <img src="/liturgia/logo.png" alt="Liturgia Worship" class="brand-logo"/>
          <span class="product">Liturgia <span class="product-sub">• Worship</span></span>
        </div>
        <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
        <nav class="nav">
          <a href="/liturgia/index.php">Home</a>
          <a href="/liturgia/pricing.php">Pricing</a>
          <a href="/liturgia/account.php">Account</a>
          <span class="nav-current">Download</span>
          <a href="/liturgia/apps.php">Apps</a>
        </nav>
      </div>
    </header>

    <main class="hero">
      <div class="container center" style="padding-top:48px;">
        <h1>Download Liturgia • Worship</h1>
        <p class="muted">Choose your platform to download the latest release:</p>
        <div style="margin-top:18px;display:flex;gap:12px;flex-wrap:wrap;justify-content:center;" class="download-grid">
          <?php foreach ($available as $key=>$file): 
            $label = '';
            $svg = '';
            switch ($key) {
              case 'linux-appimage':
                $label = 'Linux (AppImage)';
                $svg = '<img class="download-logo" src="https://cdn.simpleicons.org/linux/ffffff" alt="Linux logo" />';
                break;
              case 'linux-deb':
                $label = 'Linux (.deb)';
                $svg = '<img class="download-logo" src="https://cdn.simpleicons.org/debian/ffffff" alt="Debian logo" />';
                break;
              case 'mac':
                $label = 'macOS';
                $svg = '<img class="download-logo" src="https://cdn.simpleicons.org/apple/ffffff" alt="Apple logo" />';
                break;
              case 'windows':
                $label = 'Windows';
                // Inline Windows logo SVG to avoid CDN 404s and ensure consistent rendering
                $svg = '<svg class="download-logo" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="img"><path d="M3 3h8v8H3zM13 3h8v8h-8zM3 13h8v8H3zM13 13h8v8h-8z" fill="currentColor"/></svg>';
                break;
              case 'android':
                $label = 'Android';
                $svg = '<img class="download-logo" src="https://cdn.simpleicons.org/android/ffffff" alt="Android logo" />';
                break;
            }
          ?>
            <a class="btn download-btn" href="/liturgia/download.php?platform=<?php echo urlencode($key) ?>" aria-label="Download <?php echo htmlspecialchars($label) ?>">
              <span class="download-icon" aria-hidden="true"><?php echo $svg; ?></span>
              <span class="download-label"><?php echo htmlspecialchars($label); ?></span>
            </a>
          <?php endforeach; ?>
        </div>
        <p class="muted" style="margin-top:18px;">Or view the <a href="https://github.com/<?php echo $REPO ?>/releases/latest" target="_blank">release page</a>.</p>
      </div>
    </main>

    <footer class="site-footer">
      <div class="container">
        <small>© Liturgia • Worship</small>
      </div>
    </footer>

<script>
// responsive nav popover
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>

  </body>
  </html>
  <?php
  exit;
}

$file = $map[$platform];
$repo = isset($repo_override[$platform]) ? $repo_override[$platform] : $REPO;
$remote = sprintf('https://github.com/%s/releases/latest/download/%s', $repo, rawurlencode($file));

// Redirect the user to the GitHub Releases download link
header('Location: ' . $remote);
exit;
