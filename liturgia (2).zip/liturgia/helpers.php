<?php
// Lightweight helpers - avoid requiring composer/vendor so the repo can be deployed

function load_env($path) {
    if (!file_exists($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line,'=') === false) continue;
        [$k,$v] = explode('=', $line, 2);
        $v = trim($v);
        // Remove inline comments (e.g. "VALUE  # comment") unless value is quoted
        if (isset($v[0]) && ($v[0] === '"' || $v[0] === "'")) {
            // Strip surrounding quotes
            $v = trim($v, "'\"");
        } else {
            // Remove any inline comment starting with # (preceded by whitespace)
            $v = preg_replace('/\s+#.*$/', '', $v);
            $v = trim($v);
        }
        putenv(trim($k).'='.$v);
    }
}

if (file_exists(__DIR__.'/.env')) load_env(__DIR__.'/.env');
if (file_exists(__DIR__.'/../.env')) load_env(__DIR__.'/../.env');

// Minimal JWT HS256 implementation (only enough for our needs)
function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
function base64url_decode($data) {
    $remainder = strlen($data) % 4;
    if ($remainder) $data .= str_repeat('=', 4 - $remainder);
    return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_encode($payload) {
    $secret = getenv('JWT_SECRET') ?: 'change_this';
    $header = ['alg'=>'HS256','typ'=>'JWT'];
    $segments = [];
    $segments[] = base64url_encode(json_encode($header));
    $segments[] = base64url_encode(json_encode($payload));
    $signing_input = implode('.', $segments);
    $signature = hash_hmac('sha256', $signing_input, $secret, true);
    $segments[] = base64url_encode($signature);
    return implode('.', $segments);
}

function jwt_decode_token($token, $ignore_exp = false) {
    $secret = getenv('JWT_SECRET') ?: 'change_this';
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$h64,$p64,$s64] = $parts;
    $header = json_decode(base64url_decode($h64), true);
    $payload = json_decode(base64url_decode($p64), true);
    $sig = base64url_decode($s64);
    if (!is_array($payload) || !is_array($header)) return null;
    if (($header['alg'] ?? '') !== 'HS256') return null;
    $expected = hash_hmac('sha256', "$h64.$p64", $secret, true);
    if (!hash_equals($expected, $sig)) return null;
    // skip exp when caller only needs identity (e.g. license-status)
    if (!$ignore_exp && isset($payload['exp']) && time() > intval($payload['exp'])) return null;
    return $payload;
}

// Simple Stripe webhook signature verification and event parsing (no stripe-php required)
function stripe_construct_event($payload, $sig_header, $endpoint_secret, $tolerance = 300) {
    if (!$endpoint_secret) throw new Exception('Missing webhook secret');
    if (!$sig_header) throw new Exception('Missing Stripe-Signature header');
    $parts = array_map('trim', explode(',', $sig_header));
    $timestamp = null;
    $signatures = [];
    foreach ($parts as $p) {
        if (strpos($p, 't=') === 0) $timestamp = (int)substr($p, 2);
        if (strpos($p, 'v1=') === 0) $signatures[] = substr($p, 3);
    }
    if (!$timestamp || empty($signatures)) throw new Exception('Invalid signature header');
    if (abs(time() - $timestamp) > $tolerance) throw new Exception('Timestamp outside the tolerance zone');
    $signed_payload = $timestamp . '.' . $payload;
    $expected = hash_hmac('sha256', $signed_payload, $endpoint_secret);
    $valid = false;
    foreach ($signatures as $s) {
        if (hash_equals($expected, $s)) { $valid = true; break; }
    }
    if (!$valid) throw new Exception('No matching signature found');
    $event = json_decode($payload);
    if (!$event) throw new Exception('Invalid payload');
    return $event;
}

// Small helper to call Stripe REST API without stripe-php
function stripe_api_request($method, $path, $data = []) {
    $secret = getenv('STRIPE_SECRET');
    if (!$secret) throw new Exception('Missing STRIPE_SECRET');
    $url = 'https://api.stripe.com' . $path;
    $ch = curl_init();
    $headers = [ 'Authorization: Bearer ' . $secret ];
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        // If data is an array, convert to application/x-www-form-urlencoded
        if (is_array($data)) {
            $postfields = http_build_query($data);
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
        } else {
            // Assume caller passed a raw string already (e.g., urlencoded)
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        // Ensure headers include Content-Type if not already set
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }

    $resp = curl_exec($ch);
    if ($resp === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new Exception('Stripe API request failed: '.$err);
    }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $decoded = json_decode($resp, true);
    if ($code >= 400) {
        $msg = $decoded['error']['message'] ?? $resp;
        throw new Exception('Stripe API error: '.$msg);
    }
    return $decoded;
}

function send_magic_link_email($to, $link) {
    // Simple mail() fallback. Recommend configuring SMTP and PHPMailer.
    $subject = "Your Liturgia sign-in link";
    $message = "Click to sign in: $link\n\nThis link expires shortly.";
    $headers = 'From: ' . (getenv('FROM_EMAIL') ?: 'no-reply@localhost') . "\r\n";
    return mail($to, $subject, $message, $headers);
}
?>
