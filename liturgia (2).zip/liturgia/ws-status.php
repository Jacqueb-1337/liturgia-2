<?php
header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

$wsUrl = 'http://apiliturgia.jacqueb.me:3001';

echo "=== WebSocket Server Status ===\n\n";

$ch = curl_init("$wsUrl/health");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);
    if ($data) {
        echo "Status: RUNNING ✓\n";
        echo "Uptime: " . round($data['uptime']) . " seconds\n";
        echo "Active Sessions: " . $data['activeSessions'] . "\n";
        echo "Timestamp: " . $data['timestamp'] . "\n";
    } else {
        echo "Status: RUNNING (but invalid response)\n";
    }
} else {
    echo "Status: NOT RUNNING or UNREACHABLE ✗\n";
    echo "HTTP Code: $httpCode\n";
}

echo "\n=== Diagnostics ===\n\n";

$ch = curl_init("$wsUrl/diag");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);
    if ($data && isset($data['checks'])) {
        echo "Database Pool: " . ($data['checks']['db_pool'] ?? 'unknown') . "\n";
        echo "Database Connection: " . ($data['checks']['db_connection'] ?? 'unknown') . "\n";
        echo "Auth Tokens Table: " . ($data['checks']['auth_tokens_table'] ?? 'unknown') . "\n";
        echo "Relay Sessions Table: " . ($data['checks']['relay_sessions_table'] ?? 'unknown') . "\n";
        echo "Auth Tokens Count: " . ($data['checks']['auth_tokens_count'] ?? 'unknown') . "\n";
        
        if (isset($data['checks']['env'])) {
            echo "\nEnvironment:\n";
            echo "  DB_HOST: " . ($data['checks']['env']['DB_HOST'] ?? 'not set') . "\n";
            echo "  DB_USER: " . ($data['checks']['env']['DB_USER'] ?? 'not set') . "\n";
            echo "  DB_NAME: " . ($data['checks']['env']['DB_NAME'] ?? 'not set') . "\n";
            echo "  DB_PASS: " . ($data['checks']['env']['DB_PASS'] ?? 'not set') . "\n";
        }
    } else {
        echo "Diagnostics endpoint not available (old server version?)\n";
        echo "Raw response: $response\n";
    }
} else {
    echo "Could not fetch diagnostics\n";
    echo "HTTP Code: $httpCode\n";
}

echo "\n\nManagement:\n";
echo "  Restart: https://jacqueb.me/liturgia/ws-restart.php\n";
echo "  Stop: https://jacqueb.me/liturgia/ws-stop.php\n";
?>
