<?php
require __DIR__.'/helpers.php';
require_once __DIR__.'/db.php';
// Support device tokens (non-JWT) by using auth helpers to resolve token -> email
require_once __DIR__ . '/auth/db.php';

// Extract token from Authorization header, GET param, POST form, or JSON body
$headers = getallheaders();
// Also check common server vars that may contain auth when proxies strip Authorization header
$auth = $headers['Authorization'] ?? $headers['authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
$jwt = null;

if ($auth && stripos($auth, 'Bearer ') === 0) {
    $jwt = substr($auth, 7);
}

// Fallback: ?token=...
if (!$jwt && isset($_GET['token'])) {
    $jwt = $_GET['token'];
    $source = 'query';
}

// Fallback: POST form body 'token'
if (!$jwt && isset($_POST['token'])) {
    $jwt = $_POST['token'];
    $source = 'post';
}

// Fallback: JSON body { token: '...' }
if (!$jwt) {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    if (is_array($body) && isset($body['token'])) { $jwt = $body['token']; $source = 'json'; }
}

// If still no JWT, log what we saw and return 401
if (!$jwt) {
    // Log via error_log so it shows in server logs even if data dir unwritable
    error_log('[create-portal] missing token; headers=' . json_encode(array_keys($headers)) . ' HTTP_AUTHORIZATION=' . ($_SERVER['HTTP_AUTHORIZATION'] ?? 'null') . ' REDIRECT_HTTP_AUTHORIZATION=' . ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? 'null'));
    // Also write a small snippet of raw body to portal_requests.log for debugging
    $raw_body = file_get_contents('php://input');
    if (!is_dir(__DIR__.'/data')) @mkdir(__DIR__.'/data', 0755, true);
    @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " missing_token raw_body_len=" . strlen($raw_body) . " body_snippet=" . substr($raw_body,0,200) . "\n", FILE_APPEND);
    http_response_code(401); echo json_encode(['error'=>'Missing token']); exit;
}
// Identify source for logging
$source = 'header';
if (isset($_GET['token'])) $source = 'query';
if (isset($_POST['token'])) $source = 'post';
$raw_body = file_get_contents('php://input');
$body_json = json_decode($raw_body, true);
if (is_array($body_json) && isset($body_json['token'])) $source = 'json';

// Log request reception (do NOT log full token); ensure data dir exists
if (!is_dir(__DIR__.'/data')) @mkdir(__DIR__.'/data', 0755, true);
@file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " received create-portal request source={$source}\n", FILE_APPEND);

$decoded = jwt_decode_token($jwt);
$email = null;
$uid = null;
if (!$decoded) {
    @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " create-portal invalid token (failed decode); attempting device-token lookup\n", FILE_APPEND);
    // Try resolving device token -> email using auth/db helpers
    try {
        $row = token_row_from_raw($jwt);
        if ($row && !empty($row['email'])) {
            $email = $row['email'];
            @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " create-portal device-token matched email={$email}\n", FILE_APPEND);
        } else {
            @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " create-portal device-token lookup failed\n", FILE_APPEND);
            http_response_code(401); echo json_encode(['error'=>'Invalid token']); exit;
        }
    } catch (Exception $e) {
        @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " create-portal token_row_from_raw error: " . $e->getMessage() . "\n", FILE_APPEND);
        http_response_code(401); echo json_encode(['error'=>'Invalid token']); exit;
    }
} else {
    // JWT path
    $sub = $decoded['sub'] ?? null;
    $email = $decoded['email'] ?? null;
    $exp = $decoded['exp'] ?? null;
    @file_put_contents(__DIR__.'/data/portal_requests.log', date('c') . " token_payload sub={$sub} email={$email} exp={$exp}\n", FILE_APPEND);
    $uid = $sub;
}

$pdo = get_db();
// If we have email (device-token case), look up user by email to get stripe_customer_id; otherwise use uid (JWT case)
if ($email && !$uid) {
    $stmt = $pdo->prepare('SELECT id, stripe_customer_id FROM users WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare('SELECT stripe_customer_id FROM users WHERE id = :id LIMIT 1');
    $stmt->execute([':id'=>$uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
if (!$user || !$user['stripe_customer_id']) { http_response_code(400); echo json_encode(['error'=>'No customer id']); exit; }

try {
  $resp = stripe_api_request('POST', '/v1/billing_portal/sessions', ['customer' => $user['stripe_customer_id'], 'return_url' => (getenv('SITE_URL')?:'').'/']);
  echo json_encode(['url'=>$resp['url']]);
} catch (Exception $e) {
  http_response_code(500); echo json_encode(['error'=>$e->getMessage()]);
}
?>