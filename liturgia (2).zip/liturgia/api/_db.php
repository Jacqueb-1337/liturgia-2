<?php
/**
 * Ledger API — SQLite database for ledger data.
 * Separate from the auth DB. Stores events, churches, attendees, rooms, etc.
 * Each user's data is scoped by their user_id (from JWT sub claim).
 */

function ledger_get_db(): PDO {
    $dir  = __DIR__ . '/data';
    $path = $dir . '/ledger.sqlite';
    if (!is_dir($dir)) mkdir($dir, 0750, true);

    $pdo = new PDO('sqlite:' . $path, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA foreign_keys = ON');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT,
            location TEXT,
            start_date TEXT,
            end_date TEXT,
            ticket_price REAL DEFAULT 0,
            room_price REAL DEFAULT 0,
            notes TEXT,
            scope TEXT DEFAULT 'server',
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_events_user ON events(user_id);

        CREATE TABLE IF NOT EXISTS churches (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT,
            city TEXT,
            province TEXT,
            country TEXT,
            notes TEXT,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_churches_user ON churches(user_id);

        CREATE TABLE IF NOT EXISTS attendees (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            event_id TEXT NOT NULL,
            member_id TEXT,
            first_name TEXT,
            last_name TEXT,
            church_id TEXT,
            email TEXT,
            phone TEXT,
            notes TEXT,
            ticket_paid INTEGER DEFAULT 0,
            room_requested INTEGER DEFAULT 0,
            room_paid INTEGER DEFAULT 0,
            checked_in INTEGER DEFAULT 0,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_attendees_user  ON attendees(user_id);
        CREATE INDEX IF NOT EXISTS idx_attendees_event ON attendees(event_id);

        CREATE TABLE IF NOT EXISTS rooms (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            event_id TEXT NOT NULL,
            name TEXT,
            capacity INTEGER,
            type TEXT,
            price REAL DEFAULT 0,
            notes TEXT,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_rooms_user  ON rooms(user_id);
        CREATE INDEX IF NOT EXISTS idx_rooms_event ON rooms(event_id);

        CREATE TABLE IF NOT EXISTS room_occupants (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            room_id TEXT NOT NULL,
            attendee_id TEXT NOT NULL,
            event_id TEXT,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_occupants_user ON room_occupants(user_id);
        CREATE INDEX IF NOT EXISTS idx_occupants_room ON room_occupants(room_id);

        CREATE TABLE IF NOT EXISTS purchases (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            event_id TEXT NOT NULL,
            attendee_id TEXT,
            item TEXT,
            amount REAL DEFAULT 0,
            quantity INTEGER DEFAULT 1,
            paid INTEGER DEFAULT 0,
            date TEXT,
            notes TEXT,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_purchases_user  ON purchases(user_id);
        CREATE INDEX IF NOT EXISTS idx_purchases_event ON purchases(event_id);

        CREATE TABLE IF NOT EXISTS prefab_items (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            event_id TEXT NOT NULL,
            room_id TEXT,
            name TEXT,
            price REAL DEFAULT 0,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_prefab_user  ON prefab_items(user_id);
        CREATE INDEX IF NOT EXISTS idx_prefab_event ON prefab_items(event_id);

        CREATE TABLE IF NOT EXISTS members (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            church_id TEXT,
            first_name TEXT,
            last_name TEXT,
            email TEXT,
            phone TEXT,
            created_at TEXT,
            updated_at TEXT,
            deleted_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_members_user   ON members(user_id);
        CREATE INDEX IF NOT EXISTS idx_members_church ON members(church_id);
    ");

    ledger_migrate_db($pdo);
    return $pdo;
}

/**
 * Run safe schema migrations for existing databases.
 * ALTER TABLE ADD COLUMN is idempotent — we catch exceptions for columns that already exist.
 */
function ledger_migrate_db(PDO $pdo): void {
    // Add new columns to tables that were created before this version
    $alterations = [
        "ALTER TABLE events ADD COLUMN ticket_price REAL DEFAULT 0",
        "ALTER TABLE events ADD COLUMN room_price REAL DEFAULT 0",
        "ALTER TABLE events ADD COLUMN scope TEXT DEFAULT 'server'",
        "ALTER TABLE attendees ADD COLUMN member_id TEXT",
        "ALTER TABLE rooms ADD COLUMN price REAL DEFAULT 0",
        "ALTER TABLE purchases ADD COLUMN item TEXT",
        "ALTER TABLE purchases ADD COLUMN quantity INTEGER DEFAULT 1",
        "ALTER TABLE purchases ADD COLUMN date TEXT",
        "ALTER TABLE prefab_items ADD COLUMN room_id TEXT",
        "ALTER TABLE prefab_items ADD COLUMN name TEXT",
        "ALTER TABLE prefab_items ADD COLUMN price REAL DEFAULT 0",
        "ALTER TABLE members ADD COLUMN member_number INTEGER",
        "ALTER TABLE attendees ADD COLUMN member_number INTEGER",
        "ALTER TABLE attendees ADD COLUMN is_placeholder INTEGER DEFAULT 0",
    ];
    foreach ($alterations as $sql) {
        try { $pdo->exec($sql); } catch (\Exception $e) { /* column already exists, skip */ }
    }
    // Migrate data for renamed columns: label → item/name, amount → price
    $dataMigrations = [
        "UPDATE purchases SET item = label WHERE item IS NULL AND label IS NOT NULL",
        "UPDATE prefab_items SET name = label WHERE name IS NULL AND label IS NOT NULL",
        "UPDATE prefab_items SET price = amount WHERE (price IS NULL OR price = 0) AND amount IS NOT NULL AND amount != 0",
    ];
    foreach ($dataMigrations as $sql) {
        try { $pdo->exec($sql); } catch (\Exception $e) { /* column may not exist in this deployment */ }
    }
}
