<?php
/**
 * Liturgia Ledger — REST API
 * Routes:
 *   GET    /api/{store}              list all records for authenticated user
 *   GET    /api/{store}/{id}         get single record
 *   PUT    /api/{store}/{id}         upsert record (used by sync engine)
 *   DELETE /api/{store}/{id}         soft-delete record
 *
 * All requests require: Authorization: Bearer <jwt>
 * Responses are JSON.
 */

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_db.php';

header('Content-Type: application/json; charset=utf-8');

// ── CORS ──────────────────────────────────────────────────────────────────────
// Ledger is an Electron app — no origin restriction needed, but keep the header
// so future web clients work.
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Auth ──────────────────────────────────────────────────────────────────────
$payload = ledger_require_auth();
$userId  = (string)($payload['sub'] ?? $payload['email'] ?? '');
if (!$userId) { http_response_code(401); echo json_encode(['error' => 'no user identity in token']); exit; }

// ── Route parsing ─────────────────────────────────────────────────────────────
// REQUEST_URI:  /liturgia/api/churches/abc123?foo=bar
// After stripping script dir prefix → /churches/abc123
$requestUri = strtok($_SERVER['REQUEST_URI'], '?'); // strip query string
// Remove base path up to and including /api
$scriptDir  = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$path       = trim(substr($requestUri, strlen($scriptDir)), '/');
$parts      = $path ? explode('/', $path) : [];
$store      = $parts[0] ?? '';
$itemId     = $parts[1] ?? null;
$method = $_SERVER['REQUEST_METHOD'];

// Allowed stores — map to DB table names and the camelCase→snake_case field maps
const STORES = [
    'events'        => 'events',
    'churches'      => 'churches',
    'attendees'     => 'attendees',
    'rooms'         => 'rooms',
    'room_occupants'=> 'room_occupants',
    'purchases'     => 'purchases',
    'prefab_items'  => 'prefab_items',
    'members'       => 'members',
];

if (!isset(STORES[$store])) {
    http_response_code(404);
    echo json_encode(['error' => "unknown store: $store"]);
    exit;
}

$table = STORES[$store];
$db    = ledger_get_db();

// ── Column maps: camelCase (client) → snake_case (DB) ────────────────────────
const FIELD_MAP = [
    'memberNumber'  => 'member_number',
    'isPlaceholder' => 'is_placeholder',
    'eventId'       => 'event_id',
    'churchId'      => 'church_id',
    'roomId'        => 'room_id',
    'roomId'        => 'room_id',
    'attendeeId'    => 'attendee_id',
    'memberId'      => 'member_id',
    'firstName'     => 'first_name',
    'lastName'      => 'last_name',
    'startDate'     => 'start_date',
    'endDate'       => 'end_date',
    'ticketPrice'   => 'ticket_price',
    'roomPrice'     => 'room_price',
    'ticketPaid'    => 'ticket_paid',
    'roomRequested' => 'room_requested',
    'roomPaid'      => 'room_paid',
    'checkedIn'     => 'checked_in',
    'deletedAt'     => 'deleted_at',
    'createdAt'     => 'created_at',
    'updatedAt'     => 'updated_at',
    'syncStatus'    => 'sync_status',
];

// Client-only IDB fields that must never be written to the DB
const STRIP_FIELDS = ['sync_status', 'timestamp'];

function to_db(array $data): array {
    $out = [];
    foreach ($data as $k => $v) {
        $col = FIELD_MAP[$k] ?? $k;
        if (!in_array($col, STRIP_FIELDS, true)) {
            $out[$col] = $v;
        }
    }
    return $out;
}

// Reverse: snake_case → camelCase for responses
function to_client(array $row): array {
    static $rev = null;
    if ($rev === null) {
        $rev = array_flip(FIELD_MAP);
    }
    $out = [];
    foreach ($row as $k => $v) {
        $out[$rev[$k] ?? $k] = $v;
    }
    return $out;
}

function json_ok($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}
function json_err(int $code, string $msg): void {
    http_response_code($code);
    echo json_encode(['error' => $msg]);
    exit;
}

// ── GET list ──────────────────────────────────────────────────────────────────
if ($method === 'GET' && !$itemId) {
    $where  = ["user_id = :uid", "(deleted_at IS NULL OR deleted_at = '')"];
    $params = [':uid' => $userId];

    // ?eventId=X  — filter child records by event
    if (!empty($_GET['eventId'])) {
        $where[]           = 'event_id = :eid';
        $params[':eid']    = $_GET['eventId'];
    }
    // ?since=<iso>  — only records updated after timestamp (for polling)
    if (!empty($_GET['since'])) {
        $where[]           = 'updated_at > :since';
        $params[':since']  = $_GET['since'];
    }
    // ?scope=server  — only events with scope='server' (for listing server events)
    if (!empty($_GET['scope']) && $table === 'events') {
        $where[]           = 'scope = :scope';
        $params[':scope']  = $_GET['scope'];
    }

    $sql  = "SELECT * FROM $table WHERE " . implode(' AND ', $where);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
    json_ok(array_map('to_client', $rows));
}

// ── GET single ────────────────────────────────────────────────────────────────
if ($method === 'GET' && $itemId) {
    $stmt = $db->prepare("SELECT * FROM $table WHERE id = :id AND user_id = :uid LIMIT 1");
    $stmt->execute([':id' => $itemId, ':uid' => $userId]);
    $row = $stmt->fetch();
    if (!$row) json_err(404, 'not found');
    json_ok(to_client($row));
}

// ── PUT upsert ────────────────────────────────────────────────────────────────
if ($method === 'PUT') {
    if (!$itemId) json_err(400, 'id required in URL');
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) json_err(400, 'invalid JSON body');

    // Enforce ownership: strip client-supplied user_id and always use the token's
    unset($body['userId'], $body['user_id']);

    $dbRow = to_db($body);
    $dbRow['id']         = $itemId;
    $dbRow['user_id']    = $userId;
    $dbRow['updated_at'] = $dbRow['updated_at'] ?? date('c');
    if (empty($dbRow['created_at'])) $dbRow['created_at'] = $dbRow['updated_at'];

    // Build a dynamic INSERT OR REPLACE
    $cols        = array_keys($dbRow);
    $placeholders = array_map(fn($c) => ":$c", $cols);
    $sql = "INSERT OR REPLACE INTO $table (" . implode(',', $cols) . ") VALUES (" . implode(',', $placeholders) . ")";
    $stmt = $db->prepare($sql);
    foreach ($dbRow as $col => $val) {
        // SQLite stores booleans as integers
        $stmt->bindValue(":$col", is_bool($val) ? (int)$val : $val);
    }
    $stmt->execute();

    $stmt2 = $db->prepare("SELECT * FROM $table WHERE id = :id AND user_id = :uid LIMIT 1");
    $stmt2->execute([':id' => $itemId, ':uid' => $userId]);
    $row = $stmt2->fetch();
    json_ok($row ? to_client($row) : ['id' => $itemId]);
}

// ── PATCH (field-level merge, last-write-wins per field via updated_at) ───────
// Only updates the fields present in the request body. Ignores update if the
// server's current updated_at is already equal-or-newer (concurrent write guard).
if ($method === 'PATCH') {
    if (!$itemId) json_err(400, 'id required in URL');
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) json_err(400, 'invalid JSON body');

    unset($body['userId'], $body['user_id']);
    $patch = to_db($body);
    $clientTs = $patch['updated_at'] ?? date('c');

    // Read existing row
    $chk = $db->prepare("SELECT * FROM $table WHERE id = :id AND user_id = :uid LIMIT 1");
    $chk->execute([':id' => $itemId, ':uid' => $userId]);
    $existing = $chk->fetch();

    if (!$existing) {
        // Record doesn't exist yet — insert it (same as PUT)
        $patch['id']         = $itemId;
        $patch['user_id']    = $userId;
        $patch['created_at'] = $patch['created_at'] ?? $clientTs;
        $patch['updated_at'] = $clientTs;
        $cols = array_keys($patch);
        $ph   = array_map(fn($c) => ":$c", $cols);
        $ins  = $db->prepare("INSERT INTO $table (" . implode(',', $cols) . ") VALUES (" . implode(',', $ph) . ")");
        foreach ($patch as $col => $val) $ins->bindValue(":$col", is_bool($val) ? (int)$val : $val);
        $ins->execute();
    } else {
        // Only apply patch if client timestamp is newer (per-request guard)
        $serverTs = $existing['updated_at'] ?? '';
        if ($clientTs >= $serverTs) {
            // Build SET clause from only the patched fields (never touch id/user_id)
            $sets = [];
            $params = [':id' => $itemId, ':uid' => $userId];
            foreach ($patch as $col => $val) {
                // skip id, ownership, and updated_at (added below explicitly)
                if (in_array($col, ['id','user_id','updated_at'], true)) continue;
                $ph = ':p_' . preg_replace('/[^a-z0-9_]/i', '_', $col);
                $sets[]         = "$col = $ph";
                $params[$ph]    = is_bool($val) ? (int)$val : $val;
            }
            if ($sets) {
                $sets[] = "updated_at = :updated_at";
                $params[':updated_at'] = $clientTs;
                $upd = $db->prepare("UPDATE $table SET " . implode(', ', $sets) . " WHERE id = :id AND user_id = :uid");
                $upd->execute($params);
            }
        }
        // If client is older, still return 200 (client can re-pull to get fresh data)
    }

    $stmt2 = $db->prepare("SELECT * FROM $table WHERE id = :id AND user_id = :uid LIMIT 1");
    $stmt2->execute([':id' => $itemId, ':uid' => $userId]);
    $row = $stmt2->fetch();
    json_ok($row ? to_client($row) : ['id' => $itemId]);
}

// ── DELETE (soft) ─────────────────────────────────────────────────────────────
if ($method === 'DELETE') {
    if (!$itemId) json_err(400, 'id required in URL');

    // Verify ownership before deleting
    $chk = $db->prepare("SELECT id FROM $table WHERE id = :id AND user_id = :uid LIMIT 1");
    $chk->execute([':id' => $itemId, ':uid' => $userId]);
    if (!$chk->fetch()) json_err(404, 'not found');

    $stmt = $db->prepare("UPDATE $table SET deleted_at = :ts, updated_at = :ts WHERE id = :id AND user_id = :uid");
    $stmt->execute([':ts' => date('c'), ':id' => $itemId, ':uid' => $userId]);
    http_response_code(204);
    exit;
}

json_err(405, 'method not allowed');
