<?php
/**
 * Ledger API — JWT auth guard.
 * Reads Bearer token from Authorization header, validates it using the same
 * jwt_decode_token() in helpers.php, and returns the payload.
 * Calls die() with 401 JSON if the token is missing or invalid.
 */

require_once __DIR__ . '/../helpers.php';

function ledger_require_auth(): array {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$header) {
        // mod_rewrite sometimes passes it here instead
        $header = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    }
    if (!$header && function_exists('getallheaders')) {
        // Last resort: read directly from the parsed request headers
        $all = getallheaders();
        $header = $all['Authorization'] ?? $all['authorization'] ?? '';
    }
    if (!preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'missing or invalid Authorization header']);
        exit;
    }
    $token = $m[1];
    // ignore_exp=true — let license-status.php enforce expiry; here we just need identity
    $payload = jwt_decode_token($token, true);
    if (!$payload) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'token invalid']);
        exit;
    }
    return $payload;
}
