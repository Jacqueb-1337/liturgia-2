<?php
header('Content-Type: application/json; charset=utf-8');
$path = realpath(__DIR__ . '/license-status.php');
if (!$path || !file_exists($path)) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'file not found','path'=>$path]); exit; }
$cmd = escapeshellcmd('php -l ' . escapeshellarg($path));
$out = null; $rc = null;
exec($cmd, $out, $rc);
echo json_encode(['ok'=>true,'cmd'=>$cmd,'rc'=>$rc,'output'=>$out]);
