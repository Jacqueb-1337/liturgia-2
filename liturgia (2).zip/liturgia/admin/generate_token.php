<?php
// admin/generate_token.php - generate a JWT for a given email for testing
// SECURITY: Only allow requests from localhost (127.0.0.1 or ::1) and require INIT_SECRET header or ?secret parameter.
// Use POST with JSON body: { "email": "you@example.com" }
require __DIR__.'/../helpers.php';
require_once __DIR__.'/../db.php';

$secret = getenv('INIT_SECRET') ?: null;
$provided = $_SERVER['HTTP_X_INIT_SECRET'] ?? $_GET['secret'] ?? null;
$remote = $_SERVER['REMOTE_ADDR'] ?? '';

if (!$secret || !$provided || !hash_equals($secret, $provided)) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Forbidden - provide correct INIT_SECRET (header X-Init-Secret or ?secret)']);
    exit;
}

if (!in_array($remote, ['127.0.0.1', '::1'])) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Forbidden - generate_token is allowed only from localhost for safety']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json');
    header('Allow: POST');
    echo json_encode(['error'=>'Use POST with JSON body { "email": "you@example.com" }']);
    exit;
}

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    parse_str($raw, $body);
}
$email = isset($body['email']) ? filter_var($body['email'], FILTER_VALIDATE_EMAIL) : null;
if (!$email) { http_response_code(400); header('Content-Type: application/json'); echo json_encode(['error'=>'Missing or invalid email']); exit; }

try {
    $pdo = get_db();
    // Ensure users table exists and founder column exists (best-effort migration)
    try {
        $driver = strtolower($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) ?: 'sqlite');
        if ($driver === 'mysql') {
            $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, email VARCHAR(255) UNIQUE, active TINYINT, plan VARCHAR(32), expires_at INT, stripe_customer_id VARCHAR(255), founder TINYINT DEFAULT 0, created_at INT)");
            // try to add column if running older schema
            try { $pdo->exec("ALTER TABLE users ADD COLUMN founder TINYINT DEFAULT 0"); } catch (Exception $e) {}
        } else {
            $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE, active INTEGER, plan TEXT, expires_at INTEGER, stripe_customer_id TEXT, founder INTEGER DEFAULT 0, created_at INTEGER)");
            try { $pdo->exec("ALTER TABLE users ADD COLUMN founder INTEGER DEFAULT 0"); } catch (Exception $e) {}
        }
    } catch (Exception $e) { /* ignore */ }

    $stmt = $pdo->prepare('SELECT id, founder FROM users WHERE email=:e LIMIT 1');
    $stmt->execute([':e'=>$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        // Insert user; if we're still in the first 50 signups, award founder + free 1-year
        $now = time();
        try {
            $pdo->beginTransaction();
            $cntStmt = $pdo->query('SELECT COUNT(*) as c FROM users WHERE created_at IS NOT NULL');
            $cnt = intval($cntStmt->fetchColumn() ?: 0);
            $awardFounder = ($cnt < 50);
            if ($awardFounder) {
                $expires = $now + (365 * 24 * 3600);
                $ins = $pdo->prepare('INSERT INTO users (email, active, plan, expires_at, founder, created_at) VALUES (:e, 1, :plan, :exp, 1, :created)');
                $ins->execute([':e'=>$email, ':plan'=>'yearly', ':exp'=>$expires, ':created'=>$now]);
                @file_put_contents(__DIR__ . '/../data/admin_actions.log', date('c') . " - award founder to {$email} expires={$expires}\n", FILE_APPEND);
            } else {
                $ins = $pdo->prepare('INSERT INTO users (email, active, created_at) VALUES (:e, 0, :created)');
                $ins->execute([':e'=>$email, ':created'=>$now]);
            }
            $id = $pdo->lastInsertId();
            $pdo->commit();
        } catch (Exception $e) {
            try { $pdo->rollBack(); } catch (Exception $e2) {}
            throw $e;
        }
    } else $id = $user['id'];

    $payload = ['sub'=>$id, 'email'=>$email, 'iat'=>time(), 'exp'=>time()+3600];
    $jwt = jwt_encode($payload);

    // Log admin action
    $logline = date('c') . " generate_token request: ip={$remote} email={$email} id={$id} token_expires=" . (time()+3600) . "\n";
    @file_put_contents(__DIR__ . '/../data/admin_actions.log', $logline, FILE_APPEND);

    header('Content-Type: application/json');
    echo json_encode(['token'=>$jwt]);
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error'=>$e->getMessage()]);
}
?>