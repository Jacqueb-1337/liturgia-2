<?php
// admin endpoint disabled for security
http_response_code(404);
header('Content-Type: application/json');
echo json_encode(['error'=>'This admin endpoint has been disabled for security reasons.']);
exit;
?>