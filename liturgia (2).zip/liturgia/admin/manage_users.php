<?php
// admin/manage_users.php - list users and allow changing subscription end date and activation
// SECURITY: Only allow requests from localhost (127.0.0.1 or ::1) and require INIT_SECRET header or ?secret parameter.
require __DIR__.'/../helpers.php';
require_once __DIR__.'/../db.php';

$secret = getenv('INIT_SECRET') ?: null;
$provided = $_SERVER['HTTP_X_INIT_SECRET'] ?? $_GET['secret'] ?? null;
$remote = $_SERVER['REMOTE_ADDR'] ?? '';

if (!$secret || !$provided || !hash_equals($secret, $provided)) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Forbidden - provide correct INIT_SECRET (header X-Init-Secret or ?secret)']);
    exit;
}

if (!in_array($remote, ['127.0.0.1', '::1'])) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error'=>'Forbidden - manage_users is allowed only from localhost for safety']);
    exit;
}

$pdo = get_db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Accept application/json or form-encoded
    $raw = file_get_contents('php://input');
    $body = json_decode($raw, true);
    if (!is_array($body)) parse_str($raw, $body);

    $action = $body['action'] ?? $_POST['action'] ?? null;

    if ($action === 'update') {
        $id = isset($body['id']) ? intval($body['id']) : (isset($_POST['id']) ? intval($_POST['id']) : null);
        if (!$id) { http_response_code(400); echo json_encode(['error'=>'Missing id']); exit; }

        $expires_at = null;
        if (!empty($body['expires_at'])) {
            // Accept ISO date or unix timestamp
            $ts = is_numeric($body['expires_at']) ? intval($body['expires_at']) : strtotime($body['expires_at']);
            if ($ts !== false) $expires_at = $ts;
        } elseif (!empty($_POST['expires_at'])) {
            $ts = is_numeric($_POST['expires_at']) ? intval($_POST['expires_at']) : strtotime($_POST['expires_at']);
            if ($ts !== false) $expires_at = $ts;
        }

        $active = isset($body['active']) ? ($body['active'] ? 1 : 0) : (isset($_POST['active']) ? intval($_POST['active']) : null);
        $plan = $body['plan'] ?? $_POST['plan'] ?? null;

        try {
            $updates = [];
            $params = [':id'=>$id];
            if ($expires_at !== null) { $updates[] = 'expires_at = :expires_at'; $params[':expires_at'] = $expires_at; }
            if ($active !== null) { $updates[] = 'active = :active'; $params[':active'] = $active; }
            if ($plan !== null) { $updates[] = 'plan = :plan'; $params[':plan'] = $plan; }

            if (!empty($updates)) {
                $sql = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = :id';
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
            }

            $logline = date('c') . " manage_users update: ip={$remote} id={$id} active={$active} expires_at={$expires_at} plan={$plan}\n";
            @file_put_contents(__DIR__ . '/../data/admin_actions.log', $logline, FILE_APPEND);

            header('Content-Type: application/json');
            echo json_encode(['ok'=>true]);
            exit;
        } catch (Exception $e) {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['error'=>$e->getMessage()]);
            exit;
        }
    }

    http_response_code(400); header('Content-Type: application/json'); echo json_encode(['error'=>'Unknown action']); exit;
}

// GET: show simple management UI
try {
    $stmt = $pdo->query('SELECT id, email, active, plan, expires_at, stripe_customer_id FROM users ORDER BY id DESC');
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    http_response_code(500); header('Content-Type: application/json'); echo json_encode(['error'=>$e->getMessage()]); exit;
}

// Render minimal HTML UI for localhost admin
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Users</title>
<style>body{font-family:Arial,Helvetica,sans-serif;background:#f7f7f7;padding:20px;color:#111}table{border-collapse:collapse;width:100%}th,td{padding:8px;border:1px solid #ddd}th{background:#f1f1f1}form{display:inline}</style>
</head>
<body>
<h2>Manage Users (localhost only)</h2>
<p>Set subscription expiry or activate a user.</p>
<table>
<thead><tr><th>id</th><th>email</th><th>active</th><th>plan</th><th>expires_at</th><th>stripe_customer_id</th><th>actions</th></tr></thead>
<tbody>
<?php foreach ($users as $u): ?>
<tr>
<td><?=htmlspecialchars($u['id'])?></td>
<td><?=htmlspecialchars($u['email'])?></td>
<td><?=htmlspecialchars($u['active'])?></td>
<td><?=htmlspecialchars($u['plan'])?></td>
<td><?=($u['expires_at']?date('Y-m-d H:i:s', $u['expires_at']):'')?></td>
<td><?=htmlspecialchars($u['stripe_customer_id'])?></td>
<td>
  <form method="post" action="manage_users.php" onsubmit="return submitForm(this);">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="id" value="<?=htmlspecialchars($u['id'])?>">
    <label>Expires (ISO or timestamp): <input name="expires_at" value="<?=($u['expires_at']?date('Y-m-d H:i:s', $u['expires_at']):'')?>"></label>
    <label>Active: <input type="checkbox" name="active" value="1" <?=($u['active']?'checked':'')?>></label>
    <label>Plan: <input name="plan" value="<?=htmlspecialchars($u['plan'])?>" placeholder="monthly/yearly"></label>
    <button type="submit">Update</button>
  </form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<script>
async function submitForm(f){
  const data = new FormData(f);
  const obj = {};
  data.forEach((v,k)=>{ if (obj[k]) { if (Array.isArray(obj[k])) obj[k].push(v); else obj[k]=[obj[k],v]; } else obj[k]=v });
  if (!confirm('Apply changes?')) return false;
  try {
    const res = await fetch('manage_users.php', { method: 'POST', headers: { 'X-Init-Secret': '<?=htmlspecialchars($provided)?>' }, body: new URLSearchParams(obj) });
    const j = await res.json();
    if (j.ok) location.reload(); else alert('Failed: '+(j.error||'unknown'));
  } catch (e) { alert('Error: '+e); }
  return false;
}
</script>
</body>
</html>
<?php
?>