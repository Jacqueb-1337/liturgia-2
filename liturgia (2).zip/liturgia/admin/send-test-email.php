<?php
// admin/send-test-email.php - send a test email to verify mail delivery (protected by INIT_SECRET)
require __DIR__ . '/../helpers.php';
$secret = getenv('INIT_SECRET') ?: null;
$provided = $_SERVER['HTTP_X_INIT_SECRET'] ?? $_GET['secret'] ?? null;
if (!$provided || !$secret || !hash_equals($secret, $provided)) {
    http_response_code(403); header('Content-Type: application/json'); echo json_encode(['error'=>'forbidden']); exit;
}
$to = $_GET['to'] ?? null;
if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) { http_response_code(400); header('Content-Type: application/json'); echo json_encode(['error'=>'invalid-to','detail'=>'Provide ?to=you@domain.tld']); exit; }
// Support both FROM_EMAIL and MAIL_FROM env names
$from = getenv('FROM_EMAIL') ?: getenv('MAIL_FROM') ?: null;
if (!$from || !function_exists('mail')) { http_response_code(500); header('Content-Type: application/json'); echo json_encode(['error'=>'mail-unavailable','detail'=>'FROM_EMAIL or MAIL_FROM not set, or mail() not available']); exit; }
$subject = 'Liturgia test email';
$body = "This is a test email from Liturgia on " . date('c') . "\n\nIf you received this, the server mail is working.";
$headers = "From: Liturgia <{$from}>\r\nReply-To: {$from}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=utf-8\r\n";
try { $ok = mail($to, $subject, $body, $headers); } catch (Exception $e) { $ok = false; }
@file_put_contents(__DIR__ . '/../data/magic_links.log', date('c') . " - admin test send to={$to} ok=" . ($ok?1:0) . " from={$from} headers=" . str_replace("\n"," ", $headers) . "\n", FILE_APPEND);
header('Content-Type: application/json'); echo json_encode(['ok'=>$ok,'to'=>$to]);
?>