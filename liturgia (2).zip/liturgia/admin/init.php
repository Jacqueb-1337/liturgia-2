<?php
// admin/init.php - run migrations and create a one-time admin secret
// Protect with an INIT_SECRET in .env; after successful run this script will suggest deletion
// This script will emit detailed errors ONLY when the correct secret is provided to help with debugging.
require __DIR__.'/../helpers.php';
require_once __DIR__.'/../db.php';

// Enable verbose errors for this admin action only
error_reporting(E_ALL);
ini_set('display_errors', '1');

$secret = getenv('INIT_SECRET') ?: null;
$provided = $_GET['secret'] ?? null;
if (!$secret || !$provided || !hash_equals($secret, $provided)) {
    http_response_code(403);
    echo "Forbidden. Provide ?secret=YOUR_INIT_SECRET in URL.\n";
    exit;
}

try {
    // Test DB connection
    try {
        $pdo = get_db();
    } catch (Exception $dbex) {
        http_response_code(500);
        echo "DB connection error: " . $dbex->getMessage() . "\n";
        echo "Check DB credentials in .env and that the DB exists.\n";
        echo "Stack: " . $dbex->getTraceAsString();
        exit;
    }

    // Run migrations
    include __DIR__ . '/../migrate.php';

    // Optionally create mysql user/db if configured via init_db (call init_db.php instead)
    echo "Migrations completed.\n";

    // After a successful init, suggest removing this file
    echo "IMPORTANT: For security, delete admin/init.php from the server after initialisation.\n";

    // Optionally return a small summary
    $stmt = $pdo->query('SELECT COUNT(*) as c FROM users'); $c = $stmt->fetch(PDO::FETCH_ASSOC)['c'];
    echo "Users in DB: $c\n";
} catch (Exception $e) {
    http_response_code(500);
    echo "Initialization error: " . $e->getMessage() . "\n";
    echo "Stack: " . $e->getTraceAsString();
    exit;
}
?>