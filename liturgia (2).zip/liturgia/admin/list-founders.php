<?php
// admin/list-founders.php - list founder users and counts (protected by INIT_SECRET)
require __DIR__ . '/../helpers.php';
require __DIR__ . '/../db.php';
$secret = getenv('INIT_SECRET') ?: null;
$provided = $_SERVER['HTTP_X_INIT_SECRET'] ?? $_GET['secret'] ?? null;
if (!$provided || !$secret || !hash_equals($secret, $provided)) {
    http_response_code(403); header('Content-Type: application/json'); echo json_encode(['error'=>'forbidden']); exit;
}
try {
    $pdo = get_db();
    $stmt = $pdo->query('SELECT COUNT(*) as c FROM users WHERE founder=1');
    $count = intval($stmt->fetchColumn() ?: 0);
    $stmt2 = $pdo->prepare('SELECT id,email,created_at,expires_at FROM users WHERE founder=1 ORDER BY created_at ASC LIMIT 100');
    $stmt2->execute();
    $rows = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode(['ok'=>true,'count'=>$count,'founders'=>$rows]);
} catch (Exception $e) {
    http_response_code(500); header('Content-Type: application/json'); echo json_encode(['error'=>'db','detail'=>$e->getMessage()]);
}
?>