<?php
// admin/console.php - secure admin console for user management
// Authenticated via ADMIN_EMAIL + ADMIN_PASSWORD_HASH in .env (hash from password_hash)
// Features: search users, view/update plan/expiry/active, change email, list/create/revoke tokens, ban/unban

session_name('liturgia_admin');
session_start([
    'cookie_httponly' => true,
    'cookie_secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'cookie_samesite' => 'Lax'
]);

require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../auth/db.php';

$adminEmail = getenv('ADMIN_EMAIL') ?: null;
$adminPasswordHash = getenv('ADMIN_PASSWORD_HASH') ?: null;
$pdoMain = null;
$pdoError = null;
$selectedDriver = getenv('DB_DRIVER') ?: (getenv('DB_HOST') ? 'mysql' : 'sqlite');
try {
  $pdoMain = get_db();
} catch (Exception $e) {
  $pdoError = $e->getMessage();
}

function respond_json($payload, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

function require_db() {
  global $pdoMain, $pdoError;
  if ($pdoMain) return $pdoMain;
  respond_json(['error' => 'db-unavailable', 'details' => $pdoError ?: 'db connection failed'], 500);
}

function require_admin_auth() {
    if (empty($_SESSION['admin_ok'])) {
        respond_json(['error' => 'unauthorized'], 401);
    }
}

function ensure_csrf() {
    $hdr = $_SERVER['HTTP_X_CSRF'] ?? '';
    if (empty($_SESSION['csrf']) || !$hdr || !hash_equals($_SESSION['csrf'], $hdr)) {
        respond_json(['error' => 'csrf-mismatch'], 403);
    }
}

function safe_date_parse($value) {
    if ($value === null || $value === '') return null;
    if (is_numeric($value)) return intval($value);
    $ts = strtotime($value);
    return $ts === false ? null : $ts;
}

function fetch_user_row($identifier, $pdo = null) {
  if (!$pdo) $pdo = require_db();
    $sql = 'SELECT id, email, active, plan, expires_at, stripe_customer_id FROM users WHERE email = :ident OR id = :id LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':ident' => $identifier, ':id' => intval($identifier)]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return null;
    // Normalize expires_at to int or null
    if (!empty($row['expires_at'])) { $row['expires_at'] = intval($row['expires_at']); } else { $row['expires_at'] = null; }
    return $row;
}

function update_user_fields($id, $fields, $pdo = null) {
  if (!$pdo) $pdo = require_db();
    $set = [];
    $params = [':id' => $id];
    foreach ($fields as $k => $v) {
        $set[] = "$k = :$k";
        $params[":$k"] = $v;
    }
    if (empty($set)) return true;
    $sql = 'UPDATE users SET ' . implode(', ', $set) . ' WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

function change_user_email_everywhere($oldEmail, $newEmail) {
  // Update primary users table
  $pdoMain = require_db();
    $stmt = $pdoMain->prepare('UPDATE users SET email = :new WHERE email = :old');
    $stmt->execute([':new' => $newEmail, ':old' => $oldEmail]);

    // Update auth accounts + tokens
    $pdoAuth = get_db_conn();
    if ($pdoAuth) {
        $stmtA = $pdoAuth->prepare('UPDATE accounts SET email = :new WHERE email = :old');
        $stmtA->execute([':new' => $newEmail, ':old' => $oldEmail]);
        $stmtT = $pdoAuth->prepare('UPDATE tokens SET email = :new WHERE email = :old');
        $stmtT->execute([':new' => $newEmail, ':old' => $oldEmail]);
    }
}

function list_tokens_admin($email) {
    $pdo = get_db_conn();
    if (!$pdo) return [];
    $stmt = $pdo->prepare('SELECT id, label, device, created_at, last_seen, persistent, revoked_at FROM tokens WHERE email = :email ORDER BY created_at DESC');
    $stmt->execute([':email' => $email]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows ?: [];
}

function revoke_token_admin($email, $tokenId) {
    $pdo = get_db_conn();
    if (!$pdo) return false;
    $stmt = $pdo->prepare('UPDATE tokens SET revoked_at = :rev WHERE id = :id AND email = :email AND revoked_at IS NULL');
    return $stmt->execute([':rev' => date('c'), ':id' => $tokenId, ':email' => $email]);
}

function log_admin_action($msg) {
    $line = date('c') . ' admin: ' . $msg . "\n";
    @file_put_contents(__DIR__ . '/../data/admin_actions.log', $line, FILE_APPEND);
}

// ---------- Handle JSON API actions ----------
$action = $_POST['action'] ?? $_GET['action'] ?? null;
$isApi = $action !== null;

if ($action === 'login') {
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    if (!$adminEmail || !$adminPasswordHash) {
        respond_json(['error' => 'admin-credentials-not-configured'], 500);
    }
    if (hash_equals($adminEmail, $email) && password_verify($pass, $adminPasswordHash)) {
        session_regenerate_id(true);
        $_SESSION['admin_ok'] = true;
        $_SESSION['admin_email'] = $email;
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
        log_admin_action("login ok for {$email} ip=" . ($_SERVER['REMOTE_ADDR'] ?? '')); 
        respond_json(['ok' => true, 'csrf' => $_SESSION['csrf']]);
    }
    log_admin_action("login failed for {$email} ip=" . ($_SERVER['REMOTE_ADDR'] ?? ''));
    respond_json(['error' => 'invalid-creds'], 401);
}

if ($action === 'logout') {
    session_destroy();
    respond_json(['ok' => true]);
}

if ($isApi) {
    require_admin_auth();
    ensure_csrf();
    switch ($action) {
        case 'lookup':
            $identifier = trim($_POST['identifier'] ?? '');
            if (!$identifier) respond_json(['error' => 'missing-identifier'], 400);
            $user = fetch_user_row($identifier, $pdoMain);
            if (!$user) respond_json(['error' => 'not-found'], 404);
            $tokens = list_tokens_admin($user['email']);
            respond_json(['ok' => true, 'user' => $user, 'tokens' => $tokens]);
            break;
      case 'list-users':
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 50;
        if ($limit < 1) $limit = 1;
        if ($limit > 200) $limit = 200;
        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        if ($offset < 0) $offset = 0;
        $search = trim($_POST['search'] ?? '');

        $pdo = require_db();
        $params = [];
        $where = '';
        if ($search !== '') {
          $where = 'WHERE email LIKE :search';
          $params[':search'] = $search . '%';
        }

        $countSql = 'SELECT COUNT(*) AS c FROM users ' . $where;
        $stmtCount = $pdo->prepare($countSql);
        foreach ($params as $k => $v) { $stmtCount->bindValue($k, $v, PDO::PARAM_STR); }
        $stmtCount->execute();
        $total = (int)($stmtCount->fetch(PDO::FETCH_ASSOC)['c'] ?? 0);

        $sql = 'SELECT id, email, plan, active, expires_at, stripe_customer_id FROM users ' . $where . ' ORDER BY id DESC LIMIT :limit OFFSET :offset';
        $stmt = $pdo->prepare($sql);
        foreach ($params as $k => $v) { $stmt->bindValue($k, $v, PDO::PARAM_STR); }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // Normalize expires_at to int/null
        foreach ($rows as &$r) {
          $r['expires_at'] = !empty($r['expires_at']) ? intval($r['expires_at']) : null;
          $r['active'] = intval($r['active']);
        }
        $hasMore = ($offset + $limit) < $total;
        respond_json(['ok' => true, 'rows' => $rows, 'total' => $total, 'has_more' => $hasMore]);
        break;
        case 'update-user':
            $id = intval($_POST['id'] ?? 0);
            if (!$id) respond_json(['error' => 'missing-id'], 400);
            $fields = [];
            if (isset($_POST['plan'])) $fields['plan'] = $_POST['plan'] === '' ? null : $_POST['plan'];
            if (isset($_POST['active'])) $fields['active'] = $_POST['active'] ? 1 : 0;
            if (array_key_exists('expires_at', $_POST)) {
                $parsed = safe_date_parse($_POST['expires_at']);
                $fields['expires_at'] = $parsed === null ? null : $parsed;
            }
            $ok = update_user_fields($id, $fields, $pdoMain);
            log_admin_action("update-user id={$id} fields=" . json_encode($fields));
            respond_json(['ok' => $ok]);
            break;
        case 'change-email':
            $id = intval($_POST['id'] ?? 0);
            $newEmail = trim($_POST['new_email'] ?? '');
            if (!$id || !$newEmail) respond_json(['error' => 'missing-fields'], 400);
            $user = fetch_user_row($id, $pdoMain);
            if (!$user) respond_json(['error' => 'not-found'], 404);
            change_user_email_everywhere($user['email'], $newEmail);
            log_admin_action("change-email id={$id} {$user['email']} -> {$newEmail}");
            respond_json(['ok' => true]);
            break;
        case 'revoke-token':
            $email = trim($_POST['email'] ?? '');
            $tokenId = trim($_POST['token_id'] ?? '');
            if (!$email || !$tokenId) respond_json(['error' => 'missing-fields'], 400);
            $ok = revoke_token_admin($email, $tokenId);
            log_admin_action("revoke-token email={$email} token={$tokenId} ok=" . ($ok ? '1' : '0'));
            respond_json(['ok' => $ok]);
            break;
        case 'create-token':
            $email = trim($_POST['email'] ?? '');
            $label = trim($_POST['label'] ?? 'Admin issued');
            $device = trim($_POST['device'] ?? 'admin');
            if (!$email) respond_json(['error' => 'missing-email'], 400);
            $token = create_token_for($email, $label, $device);
            log_admin_action("create-token email={$email} id={$token['id']}");
            respond_json(['ok' => true, 'token' => $token]);
            break;
        default:
            respond_json(['error' => 'unknown-action'], 400);
    }
}

// ---------- Render HTML ----------
$csrf = $_SESSION['csrf'] ?? bin2hex(random_bytes(16));
$_SESSION['csrf'] = $csrf;
$isAuthed = !empty($_SESSION['admin_ok']);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Liturgia Admin Console</title>
  <link rel="stylesheet" href="/liturgia/style.css">
  <link rel="stylesheet" href="/liturgia/style-small.css">
</head>
<body class="dark">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia" class="brand-logo"/>
        <span class="product">Liturgia Admin</span>
      </div>
      <nav class="nav">
        <?php if ($isAuthed): ?>
          <button class="btn" id="logout-btn" type="button">Logout</button>
        <?php endif; ?>
      </nav>
    </div>
  </header>

  <main class="container" style="padding-top:40px; padding-bottom:40px;">
    <div class="admin-card admin-notice <?php echo $pdoMain ? 'ok' : 'error'; ?>">
      <div><strong>Database:</strong> driver <?php echo htmlspecialchars($selectedDriver); ?><?php if (getenv('DB_HOST')) { echo ' @ ' . htmlspecialchars(getenv('DB_HOST')); } ?></div>
      <?php if ($pdoMain): ?>
        <div class="muted">Connected</div>
      <?php else: ?>
        <div class="muted">Connection failed: <?php echo htmlspecialchars($pdoError ?: 'unknown'); ?></div>
      <?php endif; ?>
    </div>
    <?php if (!$isAuthed): ?>
      <div class="admin-card" style="max-width:480px;margin:0 auto;">
        <h2 style="margin-top:0">Admin Login</h2>
        <p class="muted">Use the configured admin email and password.</p>
        <div class="form-row" style="margin-bottom:12px; flex-wrap:wrap; gap:12px;">
          <input id="admin-email" class="input" type="email" placeholder="Admin email" style="min-width:220px;">
          <input id="admin-pass" class="input" type="password" placeholder="Password" style="min-width:220px;">
          <button id="login-btn" class="btn primary" type="button">Login</button>
        </div>
        <div id="login-msg" class="muted admin-msg" style="margin-top:6px;"></div>
      </div>
    <?php else: ?>
      <div class="admin-grid">
        <div class="admin-card">
          <h3 style="margin-top:0;">Users</h3>
          <div class="form-row" style="gap:8px; flex-wrap:wrap;">
            <input id="list-search" class="input" type="search" placeholder="Filter by email prefix" style="min-width:200px;">
            <button id="list-refresh" class="btn" type="button">Search</button>
          </div>
          <div id="list-meta" class="muted admin-msg" style="margin-top:8px;"></div>
          <div id="users-list" class="admin-user-list" style="margin-top:12px;"></div>
          <div class="form-row" style="gap:8px; flex-wrap:wrap; margin-top:12px;">
            <button id="list-prev" class="btn" type="button">Prev</button>
            <button id="list-next" class="btn" type="button">Next</button>
          </div>
        </div>
        <div class="admin-card">
          <h3 style="margin-top:0;">Lookup User</h3>
          <div class="form-row" style="gap:8px; flex-wrap:wrap;">
            <input id="lookup-input" class="input" type="search" placeholder="Email or user id" style="min-width:200px;">
            <button id="lookup-btn" class="btn primary" type="button">Find</button>
          </div>
          <p class="muted" style="margin-top:8px;">Search by email or numeric id.</p>
          <div id="user-summary" class="muted admin-msg" style="margin-top:12px;"></div>
        </div>
        <div class="admin-card" id="user-card" style="display:none;">
          <h3 style="margin-top:0;">User Details</h3>
          <div id="user-fields" class="muted"></div>
          <div class="admin-actions" style="margin-top:12px; display:flex; flex-direction:column; gap:10px;">
            <div>
              <label class="muted">Plan</label>
              <input id="field-plan" class="input" placeholder="monthly/yearly/founding" />
            </div>
            <div>
              <label class="muted">Expires At (ISO or timestamp)</label>
              <input id="field-expires" class="input" placeholder="2026-12-31" />
            </div>
            <div>
              <label class="muted">Active</label>
              <select id="field-active" class="input">
                <option value="1">Active</option>
                <option value="0">Inactive / Banned</option>
              </select>
            </div>
            <button id="save-user" class="btn primary" type="button">Save User</button>
          </div>
          <div class="admin-actions" style="margin-top:14px;">
            <label class="muted">Change Email</label>
            <div class="form-row" style="gap:8px; flex-wrap:wrap;">
              <input id="new-email" class="input" type="email" placeholder="new-email@example.com" style="min-width:220px;">
              <button id="change-email" class="btn" type="button">Change Email</button>
            </div>
          </div>
        </div>
        <div class="admin-card" id="tokens-card" style="display:none;">
          <h3 style="margin-top:0;">Tokens</h3>
          <div id="tokens-table" class="admin-table muted"></div>
          <div class="admin-actions" style="margin-top:10px;">
            <label class="muted">Issue New Token</label>
            <div class="form-row" style="gap:8px; flex-wrap:wrap;">
              <input id="token-label" class="input" placeholder="Label (optional)" style="min-width:180px;">
              <input id="token-device" class="input" placeholder="Device (optional)" style="min-width:160px;">
              <button id="create-token" class="btn" type="button">Create Token</button>
            </div>
            <div id="new-token-display" class="muted" style="margin-top:8px;"></div>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </main>

<script>
(function(){
  const csrf = <?php echo json_encode($csrf); ?>;
  const isAuthed = <?php echo $isAuthed ? 'true' : 'false'; ?>;

  function setMsg(el, msg, isError=false) {
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('error');
    if (isError) el.classList.add('error');
  }

  async function post(action, body) {
    const form = new URLSearchParams();
    form.append('action', action);
    Object.entries(body || {}).forEach(([k,v]) => form.append(k, v === undefined || v === null ? '' : v));
    const res = await fetch('console.php', { method:'POST', headers:{'X-CSRF':csrf}, body: form });
    const j = await res.json();
    if (!res.ok || j.error) throw new Error(j.error || ('http-'+res.status));
    return j;
  }

  if (!isAuthed) {
    const loginBtn = document.getElementById('login-btn');
    loginBtn?.addEventListener('click', async () => {
      const email = document.getElementById('admin-email').value.trim();
      const pass = document.getElementById('admin-pass').value;
      const msg = document.getElementById('login-msg');
      setMsg(msg, 'Logging in...');
      try {
        const res = await fetch('console.php', { method:'POST', body: new URLSearchParams({ action:'login', email, password: pass }) });
        const j = await res.json();
        if (j.ok) { location.reload(); return; }
        setMsg(msg, j.error || 'Login failed', true);
      } catch(e) { setMsg(msg, e.message, true); }
    });
    return;
  }

  // Authed UI handlers
  const lookupBtn = document.getElementById('lookup-btn');
  const lookupInput = document.getElementById('lookup-input');
  const summary = document.getElementById('user-summary');
  const userCard = document.getElementById('user-card');
  const tokensCard = document.getElementById('tokens-card');
  const usersList = document.getElementById('users-list');
  const listMeta = document.getElementById('list-meta');
  const listSearch = document.getElementById('list-search');
  const listPrev = document.getElementById('list-prev');
  const listNext = document.getElementById('list-next');
  const listRefresh = document.getElementById('list-refresh');
  let page = 0;
  const pageSize = 50;
  let currentUser = null;

  function formatDate(ts) {
    if (!ts) return '—';
    return new Date(ts * 1000).toISOString().slice(0, 19);
  }

  async function refreshList() {
    const searchVal = (listSearch?.value || '').trim();
    try {
      setMsg(listMeta, 'Loading...');
      const res = await post('list-users', { search: searchVal, offset: page * pageSize, limit: pageSize });
      renderList(res.rows || [], res.total || 0, res.has_more);
    } catch (e) {
      setMsg(listMeta, e.message || 'Failed to load users', true);
    }
  }

  function renderList(rows, total, hasMore) {
    setMsg(listMeta, `Showing ${rows.length} of ${total}${total ? ` (page ${page+1})` : ''}`);
    if (!rows.length) { usersList.innerHTML = '<p class="muted">No users found.</p>'; return; }
    const cards = rows.map(u => {
      const plan = u.plan || '—';
      const expires = formatDate(u.expires_at);
      const active = u.active ? 'Active' : 'Inactive';
      return `<div class="user-card" data-email="${u.email}">
        <div class="user-main">
          <div class="user-email">${u.email}</div>
          <div class="user-plan">${plan}</div>
        </div>
        <div class="user-meta">ID ${u.id} • ${active} • Expires ${expires}</div>
        <div class="user-meta">Stripe: ${u.stripe_customer_id || '—'}</div>
        <div class="user-actions">
          <button class="btn" type="button" data-open="${u.email}">Open</button>
        </div>
      </div>`;
    }).join('');
    usersList.innerHTML = cards;
    usersList.querySelectorAll('button[data-open]').forEach(btn => {
      btn.addEventListener('click', () => {
        lookupInput.value = btn.getAttribute('data-open');
        lookupUser();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
    listPrev.disabled = page === 0;
    listNext.disabled = !hasMore;
  }

  async function lookupUser() {
    const ident = lookupInput.value.trim();
    if (!ident) { setMsg(summary, 'Enter an email or id.', true); return; }
    setMsg(summary, 'Loading...');
    try {
      const res = await post('lookup', { identifier: ident });
      currentUser = res.user;
      setMsg(summary, 'User loaded.');
      renderUser(res.user);
      renderTokens(res.tokens || []);
      userCard.style.display = 'block';
      tokensCard.style.display = 'block';
    } catch (e) {
      currentUser = null;
      userCard.style.display = 'none';
      tokensCard.style.display = 'none';
      setMsg(summary, e.message || 'Lookup failed', true);
    }
  }

  function renderUser(u) {
    const fields = document.getElementById('user-fields');
    fields.innerHTML = '';
    const expiresStr = u.expires_at ? new Date(u.expires_at * 1000).toISOString() : '—';
    fields.innerHTML = `
      <div><strong>Email:</strong> ${u.email}</div>
      <div><strong>ID:</strong> ${u.id}</div>
      <div><strong>Active:</strong> ${u.active ? 'Yes' : 'No'}</div>
      <div><strong>Plan:</strong> ${u.plan || '—'}</div>
      <div><strong>Expires:</strong> ${expiresStr}</div>
      <div><strong>Stripe Customer:</strong> ${u.stripe_customer_id || '—'}</div>
    `;
    document.getElementById('field-plan').value = u.plan || '';
    document.getElementById('field-expires').value = u.expires_at ? expiresStr.slice(0, 19) : '';
    document.getElementById('field-active').value = u.active ? '1' : '0';
    document.getElementById('new-email').value = '';
    document.getElementById('new-token-display').textContent = '';
  }

  function renderTokens(tokens) {
    const wrap = document.getElementById('tokens-table');
    if (!tokens || !tokens.length) { wrap.innerHTML = '<p>No tokens.</p>'; return; }
    const rows = tokens.map(t => {
      const created = t.created_at ? new Date(t.created_at).toISOString().slice(0,19) : '';
      const last = t.last_seen ? new Date(t.last_seen).toISOString().slice(0,19) : '';
      const revoked = t.revoked_at ? `<span class="muted">revoked</span>` : '';
      return `<tr>
        <td>${t.id}</td>
        <td>${t.label || ''}</td>
        <td>${t.device || ''}</td>
        <td>${created}</td>
        <td>${last}</td>
        <td>${t.persistent ? 'yes' : 'no'} ${revoked}</td>
        <td><button class="btn" data-token="${t.id}" ${t.revoked_at ? 'disabled' : ''}>Revoke</button></td>
      </tr>`;
    }).join('');
    wrap.innerHTML = `<table class="admin-table-table">
      <thead><tr><th>ID</th><th>Label</th><th>Device</th><th>Created</th><th>Last Seen</th><th>Persistent</th><th>Actions</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
    wrap.querySelectorAll('button[data-token]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const tokenId = btn.getAttribute('data-token');
        if (!confirm('Revoke token ' + tokenId + '?')) return;
        try {
          await post('revoke-token', { email: currentUser.email, token_id: tokenId });
          lookupUser();
        } catch (e) { alert(e.message || 'Failed'); }
      });
    });
  }

  lookupBtn?.addEventListener('click', lookupUser);
  lookupInput?.addEventListener('keydown', (e)=>{ if (e.key === 'Enter') lookupUser(); });

  listRefresh?.addEventListener('click', () => { page = 0; refreshList(); });
  listSearch?.addEventListener('keydown', (e)=>{ if (e.key === 'Enter') { page = 0; refreshList(); } });
  listPrev?.addEventListener('click', () => { if (page > 0) { page -= 1; refreshList(); } });
  listNext?.addEventListener('click', () => { page += 1; refreshList(); });

  document.getElementById('save-user')?.addEventListener('click', async () => {
    if (!currentUser) return;
    const plan = document.getElementById('field-plan').value.trim();
    const expires = document.getElementById('field-expires').value.trim();
    const active = document.getElementById('field-active').value === '1' ? 1 : 0;
    try {
      await post('update-user', { id: currentUser.id, plan, expires_at: expires, active });
      lookupUser();
    } catch (e) { alert(e.message || 'Update failed'); }
  });

  document.getElementById('change-email')?.addEventListener('click', async () => {
    if (!currentUser) return;
    const newEmail = document.getElementById('new-email').value.trim();
    if (!newEmail) { alert('Enter new email'); return; }
    if (!confirm('Change email to ' + newEmail + '?')) return;
    try {
      await post('change-email', { id: currentUser.id, new_email: newEmail });
      lookupInput.value = newEmail;
      lookupUser();
    } catch (e) { alert(e.message || 'Change failed'); }
  });

  document.getElementById('create-token')?.addEventListener('click', async () => {
    if (!currentUser) return;
    const label = document.getElementById('token-label').value.trim();
    const device = document.getElementById('token-device').value.trim();
    try {
      const res = await post('create-token', { email: currentUser.email, label, device });
      const disp = document.getElementById('new-token-display');
      disp.textContent = res.token && res.token.token ? res.token.token : 'Token created';
      lookupUser();
    } catch (e) { alert(e.message || 'Create failed'); }
  });

  document.getElementById('logout-btn')?.addEventListener('click', async () => {
    await fetch('console.php', { method:'POST', body: new URLSearchParams({ action:'logout' }) });
    location.reload();
  });
})();
</script>
</body>
</html>
