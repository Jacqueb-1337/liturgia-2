<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');
try {
    require_once __DIR__ . '/auth/_helpers.php';
    $res = [];
    $res['get_raw_token_exists'] = function_exists('get_raw_token');
    $res['decode_jwt_payload_exists'] = function_exists('decode_jwt_payload');
    $res['query_fn_exists'] = function_exists('query_licenses_user_by_email');
    if ($res['query_fn_exists']) {
        try {
            $r = query_licenses_user_by_email('you@example.com');
            $res['db_query_result'] = $r ?: null;
        } catch (Throwable $t) {
            $res['db_query_error'] = $t->getMessage();
        }
    }
    echo json_encode(['ok'=>true,'res'=>$res]);
} catch (Throwable $th) {
    error_log('test_helpers top error: ' . $th->getMessage());
    http_response_code(500);
    echo json_encode(['ok'=>false, 'error' => $th->getMessage()]);
}
