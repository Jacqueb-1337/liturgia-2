<?php
// Simple health check for Liturgia
header('Content-Type: application/json');
$result = [
    'php_version' => phpversion(),
    'file' => __FILE__,
    'vendor_autoload' => file_exists(__DIR__.'/vendor/autoload.php')
];
try {
    require_once __DIR__.'/helpers.php';
    $result['helpers_loaded'] = true;
} catch (Throwable $e) {
    $result['helpers_loaded'] = false;
    $result['helpers_error'] = $e->getMessage();
}
$result['env_webhook_secret'] = getenv('STRIPE_WEBHOOK_SECRET') ? 'set' : 'missing';
$result['env_stripe_secret'] = getenv('STRIPE_SECRET') ? 'set' : 'missing';
echo json_encode($result, JSON_PRETTY_PRINT);
?>