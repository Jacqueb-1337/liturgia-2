<?php
// init_db.php - try to create DB (if possible) and run migrations
require __DIR__ . '/helpers.php';

$driver = getenv('DB_DRIVER') ?: 'sqlite';
if ($driver !== 'mysql') {
    echo "Using non-MySQL driver, run migrate.php to create SQLite DB tables.\n";
    include __DIR__.'/migrate.php';
    exit;
}

$host = getenv('DB_HOST') ?: '127.0.0.1';
$port = getenv('DB_PORT') ?: 3306;
dbname = getenv('DB_NAME') ?: 'liturgia';
$dbuser = getenv('DB_USER') ?: 'jacqueb';
dbpass = getenv('DB_PASS') ?: '';
$root = getenv('DB_ROOT_USER') ?: null;
$rootpass = getenv('DB_ROOT_PASS') ?: null;

// If root creds present, attempt to create database and grant user
if ($root) {
    try {
        $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $root, $rootpass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        // Create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "Database $dbname ensured.\n";
        // Create user and grant
        if ($dbuser && $dbpass) {
            $pdo->exec("CREATE USER IF NOT EXISTS '$dbuser'@'localhost' IDENTIFIED BY '$dbpass'");
            $pdo->exec("GRANT ALL PRIVILEGES ON `$dbname`.* TO '$dbuser'@'localhost'");
            $pdo->exec("FLUSH PRIVILEGES");
            echo "User $dbuser ensured with grants on $dbname.\n";
        }
    } catch (Exception $e) {
        echo "Root create DB failed: " . $e->getMessage() . "\n";
    }
}

// Now try connecting as the configured user and running migrations
try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    echo "Connected to $dbname as $dbuser. Running migrations...\n";
    include __DIR__ . '/migrate.php';
    echo "Migrations complete.\n";
} catch (Exception $e) {
    echo "Failed to connect as $dbuser: " . $e->getMessage() . "\n";
    echo "If your host doesn't allow database creation via script, create database '$dbname' and user '$dbuser' with your host control panel, then run this script again.\n";
}
?>