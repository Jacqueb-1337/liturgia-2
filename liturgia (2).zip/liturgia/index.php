<?php
// Landing page for Liturgia site
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Liturgia Worship — Church Presentation Software for Bible Verses and Songs</title>
  <meta name="description" content="Liturgia Worship is a distraction-free presentation app for church teams. Display Bible verses and worship songs, surface matching verses with live speech recognition, and control slides from a mobile remote.">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="https://jacqueb.me/liturgia/">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Liturgia">
  <meta property="og:url" content="https://jacqueb.me/liturgia/">
  <meta property="og:title" content="Liturgia Worship — Church Presentation Software for Bible Verses and Songs">
  <meta property="og:description" content="Liturgia Worship is a distraction-free presentation app for church teams. Display Bible verses and worship songs, surface matching verses with live speech recognition, and control slides from a mobile remote.">
  <meta property="og:image" content="https://jacqueb.me/liturgia/logo.png">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Liturgia Worship — Church Presentation Software for Bible Verses and Songs">
  <meta name="twitter:description" content="Liturgia Worship is a distraction-free presentation app for church teams. Display Bible verses and worship songs, surface matching verses with live speech recognition, and control slides from a mobile remote.">
  <script type="application/ld+json">{"@context":"https://schema.org","@type":"SoftwareApplication","name":"Liturgia Worship","applicationCategory":"MultimediaApplication","operatingSystem":"Windows, macOS, Linux","description":"A distraction-free presentation app for church worship teams. Display Bible verses and songs, surface matching verses with live speech recognition, and control slides via a mobile remote.","url":"https://jacqueb.me/liturgia/","downloadUrl":"https://jacqueb.me/liturgia/download.php"}</script>
  <link rel="stylesheet" href="/liturgia/style.css">
  <link rel="stylesheet" href="/liturgia/style-small.css">
  <link rel="icon" href="/liturgia/logo.png" type="image/png">
</head>
<body class="dark">
  <header class="site-header">
    <div class="container">
      <div class="brand">
        <img src="/liturgia/logo.png" alt="Liturgia Worship" class="brand-logo"/>
        <span class="product">Liturgia <span class="product-sub">• Worship</span></span>
      </div>
      <button class="nav-toggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
      <nav class="nav">
        <span class="nav-current">Home</span>
        <a href="/liturgia/pricing.php">Pricing</a>
        <a href="/liturgia/account.php">Account</a>
        <a href="/liturgia/download.php">Download</a>
        <a href="/liturgia/apps.php">Apps</a>
      </nav>
    </div>
  </header>

  <main class="hero">
    <div class="container center">
      <h1>Worship without distraction</h1>
      <div class="definition">
        <p><strong>Lit·ur·gy</strong> <span class="pronunciation">/ˈlidərjē/</span> • <span class="part-of-speech">noun</span></p>
        <p>a form or formulary according to which public religious worship, especially Christian worship, is conducted.</p>
      </div>
      <p class="lede">Liturgia isn't designed to replace every presentation or media tool; it's the calm, reliable option when distractions matter the most.</p>
      <div class="actions">
        <a class="btn primary" href="/liturgia/download.php">Download the App</a>
        <a class="btn" href="/liturgia/account.php">Manage Account</a>
      </div>
      <p style="margin-top:12px;color:var(--muted);font-weight:600">First 50 users receive a free Founding license and a one-year subscription — join early.</p>
    </div>
  </main>

  <section class="feature-showcase">
    <div class="container">
      <h2>Everything your service needs</h2>
      <p class="section-lede">Built for worship leaders who want their technology to disappear.</p>
      <div class="feature-grid">

        <div class="feature-card feature-card--highlight">
          <span class="feature-tag">Standout feature</span>
          <h3>Simple by design</h3>
          <p>No steep learning curve. Import your existing EasyWorship or VideoPsalm songs and you are ready in minutes. One license, multiple devices, fully offline.</p>
        </div>

        <div class="feature-card">
          <h3>Verse suggestions while you preach</h3>
          <p>Speak naturally. Liturgia listens and surfaces matching Bible verses as you mention them. One click sends the verse to the screen; entirely offline, nothing uploaded.</p>
        </div>

        <div class="feature-card">
          <h3>Bible &amp; Songs</h3>
          <p>Browse any downloaded translation, search by keyword with closest-match ranking, and manage your song library with per-section navigation. Go live with a double-click.</p>
        </div>

        <div class="feature-card">
          <h3>Beautiful live output</h3>
          <p>Project on a second screen or TV. Text auto-sizes perfectly, transitions are smooth, and you can set image, video, or animated GIF backgrounds per content type.</p>
        </div>

        <div class="feature-card">
          <h3>Service schedule</h3>
          <p>Build your service order before you start. Drag in songs, verses, and media. Navigate through it during the service without hunting for the next item.</p>
        </div>

        <div class="feature-card">
          <h3>Mobile remote</h3>
          <p>Control the presentation from your phone. Navigate verses, move through the schedule, and see what is live from anywhere in the room, or even outside your network.</p>
        </div>

      </div>
    </div>
  </section>

  <footer class="site-footer">
    <div class="container">
      <small>© Liturgia • Worship</small>
    </div>
  </footer>

  <script>
    // If Stripe redirects back with ?success=1, send the user to the account page
    (function(){
      try {
        const q = new URLSearchParams(location.search);
        if (q.get('success') === '1') {
          // redirect to the account page and show a purchase success message
          location.href = '/liturgia/account.php?purchase=1';
        }
      } catch(e) { /* ignore */ }
    })();
  </script>
<script>
// responsive nav popover
(function(){
  try {
    const btn = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.nav');
    const mq = window.matchMedia('(min-width:601px)');
    function showNav(){ nav.classList.add('open'); if (btn) btn.setAttribute('aria-expanded','true'); }
    function hideNav(){ nav.classList.remove('open'); if (btn) btn.setAttribute('aria-expanded','false'); }
    function update(){ if (mq.matches){ nav.classList.remove('open'); if (nav) nav.style.display = 'flex'; if (btn) btn.style.display='none'; if (btn) btn.setAttribute('aria-expanded','false'); } else { if (nav) nav.style.display = ''; if (btn) btn.style.display='inline-flex'; } }
    update(); mq.addEventListener('change', update);
    if (btn) btn.addEventListener('click', function(e){ e.stopPropagation(); if (nav.classList.contains('open')) hideNav(); else showNav(); });
    document.addEventListener('click', function(e){ if (nav.classList.contains('open') && !nav.contains(e.target) && e.target !== btn) hideNav(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') hideNav(); });
  } catch(e){}
})();
</script>



</body>
</html> 