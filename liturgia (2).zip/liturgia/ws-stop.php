<?php
header('Content-Type: text/plain');

$wsUrl = 'http://apiliturgia.jacqueb.me:3001/restart';

echo "Sending stop command to WebSocket server...\n\n";

$ch = curl_init($wsUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    echo "Response: $response\n";
    echo "\n";
    echo "Server stopped. It will NOT restart automatically.\n";
    echo "\n";
    echo "To start again:\n";
    echo "  1. Go to cPanel → Setup Node.js App\n";
    echo "  2. Find apiliturgia.jacqueb.me\n";
    echo "  3. Click 'Start'\n";
    echo "\n";
    echo "Or visit: https://jacqueb.me/liturgia/ws-restart.php\n";
} else {
    echo "ERROR: Failed to send stop command\n";
    echo "HTTP Code: $httpCode\n";
    echo "Response: $response\n";
    echo "\n";
    echo "You may need to stop manually via cPanel:\n";
    echo "cPanel → Setup Node.js App → apiliturgia.jacqueb.me → Stop\n";
}
?>
