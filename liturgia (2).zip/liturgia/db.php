<?php
// db.php - supports MySQL (preferred) and falls back to SQLite
if (!function_exists('get_db')) {
function get_db() {
    // Load env if present
    if (file_exists(__DIR__.'/.env')) {
        $lines = file(__DIR__.'/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) if (strpos(trim($line),'=')!==false) { [$k,$v]=explode('=', $line,2); putenv(trim($k).'='.trim($v)); }
    }

    $driver = getenv('DB_DRIVER') ?: (getenv('DB_HOST') ? 'mysql' : 'sqlite');
    if ($driver === 'mysql') {
        $host = getenv('DB_HOST') ?: '127.0.0.1';
        $port = getenv('DB_PORT') ?: 3306;
        $db = getenv('DB_NAME') ?: 'liturgia';
        $user = getenv('DB_USER') ?: 'jacqueb';
        $pass = getenv('DB_PASS') ?: '';
        $dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_PERSISTENT=>false]);
        return $pdo;
    } else {
        $dbPath = getenv('DB_PATH') ?: (__DIR__ . '/data/licenses.sqlite');
        if (!file_exists(dirname($dbPath))) {
            mkdir(dirname($dbPath), 0755, true);
        }
        $pdo = new PDO('sqlite:' . $dbPath, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_PERSISTENT=>false]);
        // safe defaults to avoid stale snapshots and locking issues
        try { $pdo->exec('PRAGMA busy_timeout = 5000'); } catch (Exception $e) {}
        return $pdo;
    }
}
} 
?>