/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.12-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: jacquebm_liturgia
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `event_id` varchar(255) NOT NULL,
  `payload` mediumtext DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES
('evt_1SsUkXDtVSgFr1B0LXxBSaWR','{\"id\":\"evt_1SsUkXDtVSgFr1B0LXxBSaWR\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1769114705,\"data\":{\"object\":{\"id\":\"cs_live_a1QcuIRVqzgokR7B99Zc58hRq1t4udcMgLbEdjLgpnhLf9pmfRV7P1buER\",\"object\":\"checkout.session\",\"adaptive_pricing\":{\"enabled\":false},\"after_expiration\":null,\"allow_promotion_codes\":null,\"amount_subtotal\":1200,\"amount_total\":1200,\"automatic_tax\":{\"enabled\":false,\"liability\":null,\"provider\":null,\"status\":null},\"billing_address_collection\":null,\"branding_settings\":{\"background_color\":\"#ffffff\",\"border_style\":\"rounded\",\"button_color\":\"#0074d4\",\"display_name\":\"Liturgia\",\"font_family\":\"default\",\"icon\":null,\"logo\":null},\"cancel_url\":\"https:\\/\\/jacqueb.me\\/liturgia\\/?cancel=1\",\"client_reference_id\":null,\"client_secret\":null,\"collected_information\":{\"business_name\":null,\"individual_name\":null,\"shipping_details\":null},\"consent\":null,\"consent_collection\":null,\"created\":1769114693,\"currency\":\"usd\",\"currency_conversion\":null,\"custom_fields\":[],\"custom_text\":{\"after_submit\":null,\"shipping_address\":null,\"submit\":null,\"terms_of_service_acceptance\":null},\"customer\":\"cus_TqB6PvqiU5hjoU\",\"customer_account\":null,\"customer_creation\":\"always\",\"customer_details\":{\"address\":{\"city\":\"Cave City\",\"country\":\"US\",\"line1\":\"599 Arkansas 58\",\"line2\":null,\"postal_code\":\"72521\",\"state\":\"AR\"},\"business_name\":null,\"email\":\"jacqueb1337@gmail.com\",\"individual_name\":null,\"name\":\"Jacob Briley\",\"phone\":null,\"tax_exempt\":\"none\",\"tax_ids\":[]},\"customer_email\":null,\"discounts\":[],\"expires_at\":1769201093,\"invoice\":\"in_1SsUkSDtVSgFr1B0Ts9tCe5K\",\"invoice_creation\":null,\"livemode\":true,\"locale\":null,\"metadata\":[],\"mode\":\"subscription\",\"origin_context\":null,\"payment_intent\":null,\"payment_link\":null,\"payment_method_collection\":\"always\",\"payment_method_configuration_details\":null,\"payment_method_options\":{\"card\":{\"request_three_d_secure\":\"automatic\"}},\"payment_method_types\":[\"card\"],\"payment_status\":\"paid\",\"permissions\":null,\"phone_number_collection\":{\"enabled\":false},\"recovered_from\":null,\"saved_payment_method_options\":{\"allow_redisplay_filters\":[\"always\"],\"payment_method_remove\":\"disabled\",\"payment_method_save\":null},\"setup_intent\":null,\"shipping_address_collection\":null,\"shipping_cost\":null,\"shipping_options\":[],\"status\":\"complete\",\"submit_type\":null,\"subscription\":\"sub_1SsUkVDtVSgFr1B0FQhFMVaM\",\"success_url\":\"https:\\/\\/jacqueb.me\\/liturgia\\/?success=1\",\"total_details\":{\"amount_discount\":0,\"amount_shipping\":0,\"amount_tax\":0},\"ui_mode\":\"hosted\",\"url\":null,\"wallet_options\":null}},\"livemode\":true,\"pending_webhooks\":1,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"checkout.session.completed\"}',1769118910),
('evt_1SsWT3DtVSgFr1B0QPoLzNwV','{\"id\":\"evt_1SsWT3DtVSgFr1B0QPoLzNwV\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1769121308,\"data\":{\"object\":{\"id\":\"sub_1SsUkVDtVSgFr1B0FQhFMVaM\",\"object\":\"subscription\",\"application\":null,\"application_fee_percent\":null,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null},\"billing_cycle_anchor\":1769114700,\"billing_cycle_anchor_config\":null,\"billing_mode\":{\"flexible\":{\"proration_discounts\":\"included\"},\"type\":\"flexible\",\"updated_at\":1769114693},\"billing_thresholds\":null,\"cancel_at\":1771793100,\"cancel_at_period_end\":false,\"canceled_at\":null,\"cancellation_details\":{\"comment\":null,\"feedback\":null,\"reason\":\"cancellation_requested\"},\"collection_method\":\"charge_automatically\",\"created\":1769114700,\"currency\":\"usd\",\"customer\":\"cus_TqB6PvqiU5hjoU\",\"customer_account\":null,\"days_until_due\":null,\"default_payment_method\":\"pm_1SsUkSDtVSgFr1B0anCti9Ln\",\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"ended_at\":null,\"invoice_settings\":{\"account_tax_ids\":null,\"issuer\":{\"type\":\"self\"}},\"items\":{\"object\":\"list\",\"data\":[{\"id\":\"si_TqB6oRgURgsdKr\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1769114701,\"current_period_end\":1771793100,\"current_period_start\":1769114700,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1SsUkVDtVSgFr1B0FQhFMVaM\",\"tax_rates\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/subscription_items?subscription=sub_1SsUkVDtVSgFr1B0FQhFMVaM\"},\"latest_invoice\":\"in_1SsUkSDtVSgFr1B0Ts9tCe5K\",\"livemode\":true,\"metadata\":[],\"next_pending_invoice_item_invoice\":null,\"on_behalf_of\":null,\"pause_collection\":null,\"payment_settings\":{\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"network\":null,\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"sepa_debit\":null,\"us_bank_account\":null},\"payment_method_types\":[\"card\"],\"save_default_payment_method\":\"off\"},\"pending_invoice_item_interval\":null,\"pending_setup_intent\":null,\"pending_update\":null,\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"quantity\":1,\"schedule\":null,\"start_date\":1769114700,\"status\":\"active\",\"test_clock\":null,\"transfer_data\":null,\"trial_end\":null,\"trial_settings\":{\"end_behavior\":{\"missing_payment_method\":\"create_invoice\"}},\"trial_start\":null},\"previous_attributes\":{\"cancel_at\":null,\"cancellation_details\":{\"reason\":null}}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":\"3e6bcc55-6480-4ab7-a7d3-1cc7e0f4b0b7\"},\"type\":\"customer.subscription.updated\"}',1769121309),
('evt_1SsWTIDtVSgFr1B0n8BK1OYP','{\"id\":\"evt_1SsWTIDtVSgFr1B0n8BK1OYP\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1769121323,\"data\":{\"object\":{\"id\":\"sub_1SsUkVDtVSgFr1B0FQhFMVaM\",\"object\":\"subscription\",\"application\":null,\"application_fee_percent\":null,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null},\"billing_cycle_anchor\":1769114700,\"billing_cycle_anchor_config\":null,\"billing_mode\":{\"flexible\":{\"proration_discounts\":\"included\"},\"type\":\"flexible\",\"updated_at\":1769114693},\"billing_thresholds\":null,\"cancel_at\":1771793100,\"cancel_at_period_end\":false,\"canceled_at\":null,\"cancellation_details\":{\"comment\":\"its my service lol im just testing\",\"feedback\":\"other\",\"reason\":\"cancellation_requested\"},\"collection_method\":\"charge_automatically\",\"created\":1769114700,\"currency\":\"usd\",\"customer\":\"cus_TqB6PvqiU5hjoU\",\"customer_account\":null,\"days_until_due\":null,\"default_payment_method\":\"pm_1SsUkSDtVSgFr1B0anCti9Ln\",\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"ended_at\":null,\"invoice_settings\":{\"account_tax_ids\":null,\"issuer\":{\"type\":\"self\"}},\"items\":{\"object\":\"list\",\"data\":[{\"id\":\"si_TqB6oRgURgsdKr\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1769114701,\"current_period_end\":1771793100,\"current_period_start\":1769114700,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1SsUkVDtVSgFr1B0FQhFMVaM\",\"tax_rates\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/subscription_items?subscription=sub_1SsUkVDtVSgFr1B0FQhFMVaM\"},\"latest_invoice\":\"in_1SsUkSDtVSgFr1B0Ts9tCe5K\",\"livemode\":true,\"metadata\":[],\"next_pending_invoice_item_invoice\":null,\"on_behalf_of\":null,\"pause_collection\":null,\"payment_settings\":{\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"network\":null,\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"sepa_debit\":null,\"us_bank_account\":null},\"payment_method_types\":[\"card\"],\"save_default_payment_method\":\"off\"},\"pending_invoice_item_interval\":null,\"pending_setup_intent\":null,\"pending_update\":null,\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"quantity\":1,\"schedule\":null,\"start_date\":1769114700,\"status\":\"active\",\"test_clock\":null,\"transfer_data\":null,\"trial_end\":null,\"trial_settings\":{\"end_behavior\":{\"missing_payment_method\":\"create_invoice\"}},\"trial_start\":null},\"previous_attributes\":{\"cancellation_details\":{\"comment\":null,\"feedback\":null}}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":\"41118686-c5ab-4801-9e16-3ee87719b93c\"},\"type\":\"customer.subscription.updated\"}',1769121325),
('evt_1TegecDtVSgFr1B0yswvfyiB','{\"id\":\"evt_1TegecDtVSgFr1B0yswvfyiB\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1780600209,\"data\":{\"object\":{\"id\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"object\":\"subscription\",\"application\":null,\"application_fee_percent\":null,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null},\"billing_cycle_anchor\":1775329718,\"billing_cycle_anchor_config\":null,\"billing_mode\":{\"flexible\":{\"proration_discounts\":\"included\"},\"type\":\"flexible\",\"updated_at\":1775327823},\"billing_thresholds\":null,\"cancel_at\":null,\"cancel_at_period_end\":false,\"canceled_at\":null,\"cancellation_details\":{\"comment\":null,\"feedback\":null,\"reason\":null},\"collection_method\":\"charge_automatically\",\"created\":1775329718,\"currency\":\"usd\",\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"days_until_due\":null,\"default_payment_method\":\"pm_1TIZYfDtVSgFr1B0oO4uB6Rt\",\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"ended_at\":null,\"invoice_settings\":{\"account_tax_ids\":null,\"issuer\":{\"type\":\"self\"}},\"items\":{\"object\":\"list\",\"data\":[{\"id\":\"si_UH7oHLGxSye0gf\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1775329719,\"current_period_end\":1783192118,\"current_period_start\":1780600118,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"tax_rates\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/subscription_items?subscription=sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"latest_invoice\":\"in_1TegebDtVSgFr1B0RWTFQLjh\",\"livemode\":true,\"managed_payments\":{\"enabled\":false},\"metadata\":[],\"next_pending_invoice_item_invoice\":null,\"on_behalf_of\":null,\"pause_collection\":null,\"payment_settings\":{\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"network\":null,\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null,\"save_default_payment_method\":\"off\"},\"pending_invoice_item_interval\":null,\"pending_setup_intent\":null,\"pending_update\":null,\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"quantity\":1,\"schedule\":null,\"start_date\":1775329718,\"status\":\"active\",\"test_clock\":null,\"transfer_data\":null,\"trial_end\":null,\"trial_settings\":{\"end_behavior\":{\"missing_payment_method\":\"create_invoice\"}},\"trial_start\":null},\"previous_attributes\":{\"items\":{\"data\":[{\"id\":\"si_UH7oHLGxSye0gf\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1775329719,\"current_period_end\":1780600118,\"current_period_start\":1777921718,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"tax_rates\":[]}]},\"latest_invoice\":\"in_1TTRreDtVSgFr1B0Eyzmb4Cf\"}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"customer.subscription.updated\"}',1780600210),
('evt_1TehbHDtVSgFr1B0GRNmpFaM','{\"id\":\"evt_1TehbHDtVSgFr1B0GRNmpFaM\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1780603847,\"data\":{\"object\":{\"id\":\"cus_UH7oaNjitT2rrv\",\"object\":\"customer\",\"address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"balance\":0,\"created\":1775329718,\"currency\":\"usd\",\"customer_account\":null,\"default_source\":null,\"delinquent\":false,\"description\":null,\"discount\":null,\"email\":\"revivedchurchofgod@outlook.com\",\"invoice_prefix\":\"SALV53MV\",\"invoice_settings\":{\"custom_fields\":null,\"default_payment_method\":null,\"footer\":null,\"rendering_options\":null},\"livemode\":true,\"metadata\":[],\"name\":\"Revived Church of God\",\"next_invoice_sequence\":4,\"phone\":null,\"preferred_locales\":[\"en-US\"],\"shipping\":null,\"tax_exempt\":\"none\",\"test_clock\":null},\"previous_attributes\":{\"next_invoice_sequence\":3}},\"livemode\":true,\"pending_webhooks\":1,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"customer.updated\"}',1780603848),
('evt_1TehbIDtVSgFr1B0SB054Ufe','{\"id\":\"evt_1TehbIDtVSgFr1B0SB054Ufe\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1780603847,\"data\":{\"object\":{\"id\":\"in_1TegebDtVSgFr1B0RWTFQLjh\",\"object\":\"invoice\",\"account_country\":\"US\",\"account_name\":\"Liturgia\",\"account_tax_ids\":null,\"amount_due\":1200,\"amount_overpaid\":0,\"amount_paid\":1200,\"amount_remaining\":0,\"amount_shipping\":0,\"application\":null,\"attempt_count\":1,\"attempted\":true,\"auto_advance\":false,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null,\"provider\":null,\"status\":null},\"automatically_finalizes_at\":null,\"billing_reason\":\"subscription_cycle\",\"collection_method\":\"charge_automatically\",\"created\":1780600209,\"currency\":\"usd\",\"custom_fields\":null,\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"customer_address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"customer_email\":\"revivedchurchofgod@outlook.com\",\"customer_name\":\"Revived Church of God\",\"customer_phone\":null,\"customer_shipping\":null,\"customer_tax_exempt\":\"none\",\"customer_tax_ids\":[],\"default_payment_method\":null,\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"due_date\":null,\"effective_at\":1780603840,\"ending_balance\":0,\"footer\":null,\"from_invoice\":null,\"hosted_invoice_url\":\"https:\\/\\/invoice.stripe.com\\/i\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VZHlicDJFQkxSQk5taUZVdEJPNUFtcDZXQXNtb0xHLDE3MTE0NDY0OA0200boc3bQaz?s=ap\",\"invoice_pdf\":\"https:\\/\\/pay.stripe.com\\/invoice\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VZHlicDJFQkxSQk5taUZVdEJPNUFtcDZXQXNtb0xHLDE3MTE0NDY0OA0200boc3bQaz\\/pdf?s=ap\",\"issuer\":{\"type\":\"self\"},\"last_finalization_error\":null,\"latest_revision\":null,\"lines\":{\"object\":\"list\",\"data\":[{\"id\":\"il_1Tegd8DtVSgFr1B0eWl1IjiT\",\"object\":\"line_item\",\"amount\":1200,\"currency\":\"usd\",\"description\":\"1 \\u00d7 Monthly Subscription (at $12.00 \\/ month)\",\"discount_amounts\":[],\"discountable\":true,\"discounts\":[],\"invoice\":\"in_1TegebDtVSgFr1B0RWTFQLjh\",\"livemode\":true,\"metadata\":[],\"parent\":{\"invoice_item_details\":null,\"license_fee_subscription_details\":null,\"subscription_item_details\":{\"invoice_item\":null,\"proration\":false,\"proration_details\":{\"credited_items\":null},\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"subscription_item\":\"si_UH7oHLGxSye0gf\"},\"type\":\"subscription_item_details\"},\"period\":{\"end\":1783192118,\"start\":1780600118},\"pretax_credit_amounts\":[],\"pricing\":{\"price_details\":{\"price\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"product\":\"prod_ToiEyjVhflCXX1\"},\"type\":\"price_details\",\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"quantity_decimal\":\"1\",\"subtotal\":1200,\"taxes\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/invoices\\/in_1TegebDtVSgFr1B0RWTFQLjh\\/lines\"},\"livemode\":true,\"metadata\":[],\"next_payment_attempt\":null,\"number\":\"SALV53MV-0003\",\"on_behalf_of\":null,\"parent\":{\"quote_details\":null,\"subscription_details\":{\"metadata\":[],\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"type\":\"subscription_details\"},\"payment_settings\":{\"default_mandate\":null,\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null},\"period_end\":1780600118,\"period_start\":1777921718,\"post_payment_credit_notes_amount\":0,\"pre_payment_credit_notes_amount\":0,\"receipt_number\":null,\"rendering\":null,\"shipping_cost\":null,\"shipping_details\":null,\"starting_balance\":0,\"statement_descriptor\":null,\"status\":\"paid\",\"status_transitions\":{\"finalized_at\":1780603840,\"marked_uncollectible_at\":null,\"paid_at\":1780603840,\"voided_at\":null},\"subtotal\":1200,\"subtotal_excluding_tax\":1200,\"test_clock\":null,\"total\":1200,\"total_discount_amounts\":[],\"total_excluding_tax\":1200,\"total_pretax_credit_amounts\":[],\"total_taxes\":[],\"webhooks_delivered_at\":1780600209}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"invoice.payment_succeeded\"}',1780603849),
('evt_1TIZYiDtVSgFr1B0kaC58ysa','{\"id\":\"evt_1TIZYiDtVSgFr1B0kaC58ysa\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1775329718,\"data\":{\"object\":{\"id\":\"cus_UH7oaNjitT2rrv\",\"object\":\"customer\",\"address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"balance\":0,\"created\":1775329718,\"currency\":\"usd\",\"customer_account\":null,\"default_source\":null,\"delinquent\":false,\"description\":null,\"discount\":null,\"email\":\"revivedchurchofgod@outlook.com\",\"invoice_prefix\":\"SALV53MV\",\"invoice_settings\":{\"custom_fields\":null,\"default_payment_method\":null,\"footer\":null,\"rendering_options\":null},\"livemode\":true,\"metadata\":[],\"name\":\"Revived Church of God\",\"next_invoice_sequence\":1,\"phone\":null,\"preferred_locales\":[\"en-US\"],\"shipping\":null,\"tax_exempt\":\"none\",\"test_clock\":null},\"previous_attributes\":{\"currency\":null}},\"livemode\":true,\"pending_webhooks\":1,\"request\":{\"id\":null,\"idempotency_key\":\"1fed3cf5-da78-4526-a186-353d66c32497\"},\"type\":\"customer.updated\"}',1775329720),
('evt_1TIZYuDtVSgFr1B0j9yuLjyo','{\"id\":\"evt_1TIZYuDtVSgFr1B0j9yuLjyo\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1775329732,\"data\":{\"object\":{\"id\":\"cs_live_b1eZIt6uYZer4nTQSV20SnUfftJEXZpndBBt828WFClGCswzS1hlYCub5W\",\"object\":\"checkout.session\",\"adaptive_pricing\":{\"enabled\":true},\"after_expiration\":null,\"allow_promotion_codes\":true,\"amount_subtotal\":1200,\"amount_total\":1200,\"automatic_tax\":{\"enabled\":false,\"liability\":null,\"provider\":null,\"status\":null},\"billing_address_collection\":null,\"branding_settings\":{\"background_color\":\"#ffffff\",\"border_style\":\"rounded\",\"button_color\":\"#0074d4\",\"display_name\":\"Liturgia\",\"font_family\":\"default\",\"icon\":null,\"logo\":null},\"cancel_url\":\"https:\\/\\/jacqueb.me\\/liturgia\\/?canceled=1\",\"client_reference_id\":null,\"client_secret\":null,\"collected_information\":{\"business_name\":null,\"individual_name\":null,\"shipping_details\":null},\"consent\":null,\"consent_collection\":null,\"created\":1775327823,\"currency\":\"usd\",\"currency_conversion\":null,\"custom_fields\":[],\"custom_text\":{\"after_submit\":null,\"shipping_address\":null,\"submit\":null,\"terms_of_service_acceptance\":null},\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"customer_creation\":\"always\",\"customer_details\":{\"address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"business_name\":null,\"email\":\"revivedchurchofgod@outlook.com\",\"individual_name\":null,\"name\":\"Revived Church of God\",\"phone\":null,\"tax_exempt\":\"none\",\"tax_ids\":[]},\"customer_email\":\"revivedchurchofgod@outlook.com\",\"discounts\":[],\"expires_at\":1775414223,\"integration_identifier\":null,\"invoice\":\"in_1TIZYgDtVSgFr1B0ivCRjUdz\",\"invoice_creation\":null,\"livemode\":true,\"locale\":null,\"metadata\":{\"plan\":\"monthly\",\"email\":\"revivedchurchofgod@outlook.com\"},\"mode\":\"subscription\",\"origin_context\":null,\"payment_intent\":null,\"payment_link\":null,\"payment_method_collection\":\"always\",\"payment_method_configuration_details\":{\"id\":\"pmc_1Sr4UXDtVSgFr1B02WKcga2D\",\"parent\":null},\"payment_method_options\":{\"card\":{\"request_three_d_secure\":\"automatic\"}},\"payment_method_types\":[\"card\",\"klarna\",\"link\",\"cashapp\",\"amazon_pay\"],\"payment_status\":\"paid\",\"permissions\":null,\"phone_number_collection\":{\"enabled\":false},\"recovered_from\":null,\"saved_payment_method_options\":{\"allow_redisplay_filters\":[\"always\"],\"payment_method_remove\":\"disabled\",\"payment_method_save\":null},\"setup_intent\":null,\"shipping_address_collection\":null,\"shipping_cost\":null,\"shipping_options\":[],\"status\":\"complete\",\"submit_type\":null,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"success_url\":\"https:\\/\\/jacqueb.me\\/liturgia\\/?success=1&plan=monthly\",\"total_details\":{\"amount_discount\":0,\"amount_shipping\":0,\"amount_tax\":0},\"ui_mode\":\"hosted\",\"url\":null,\"wallet_options\":null}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"checkout.session.completed\"}',1775329733),
('evt_1TIZYvDtVSgFr1B0hO4xNlgr','{\"id\":\"evt_1TIZYvDtVSgFr1B0hO4xNlgr\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1775329732,\"data\":{\"object\":{\"id\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"object\":\"subscription\",\"application\":null,\"application_fee_percent\":null,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null},\"billing_cycle_anchor\":1775329718,\"billing_cycle_anchor_config\":null,\"billing_mode\":{\"flexible\":{\"proration_discounts\":\"included\"},\"type\":\"flexible\",\"updated_at\":1775327823},\"billing_thresholds\":null,\"cancel_at\":null,\"cancel_at_period_end\":false,\"canceled_at\":null,\"cancellation_details\":{\"comment\":null,\"feedback\":null,\"reason\":null},\"collection_method\":\"charge_automatically\",\"created\":1775329718,\"currency\":\"usd\",\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"days_until_due\":null,\"default_payment_method\":\"pm_1TIZYfDtVSgFr1B0oO4uB6Rt\",\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"ended_at\":null,\"invoice_settings\":{\"account_tax_ids\":null,\"issuer\":{\"type\":\"self\"}},\"items\":{\"object\":\"list\",\"data\":[{\"id\":\"si_UH7oHLGxSye0gf\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1775329719,\"current_period_end\":1777921718,\"current_period_start\":1775329718,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"tax_rates\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/subscription_items?subscription=sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"latest_invoice\":\"in_1TIZYgDtVSgFr1B0ivCRjUdz\",\"livemode\":true,\"metadata\":[],\"next_pending_invoice_item_invoice\":null,\"on_behalf_of\":null,\"pause_collection\":null,\"payment_settings\":{\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"network\":null,\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null,\"save_default_payment_method\":\"off\"},\"pending_invoice_item_interval\":null,\"pending_setup_intent\":null,\"pending_update\":null,\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"quantity\":1,\"schedule\":null,\"start_date\":1775329718,\"status\":\"active\",\"test_clock\":null,\"transfer_data\":null,\"trial_end\":null,\"trial_settings\":{\"end_behavior\":{\"missing_payment_method\":\"create_invoice\"}},\"trial_start\":null}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"customer.subscription.created\"}',1775329734),
('evt_1TIZYvDtVSgFr1B0WqTKa0R9','{\"id\":\"evt_1TIZYvDtVSgFr1B0WqTKa0R9\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1775329731,\"data\":{\"object\":{\"id\":\"in_1TIZYgDtVSgFr1B0ivCRjUdz\",\"object\":\"invoice\",\"account_country\":\"US\",\"account_name\":\"Liturgia\",\"account_tax_ids\":null,\"amount_due\":1200,\"amount_overpaid\":0,\"amount_paid\":1200,\"amount_remaining\":0,\"amount_shipping\":0,\"application\":null,\"attempt_count\":0,\"attempted\":true,\"auto_advance\":false,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null,\"provider\":null,\"status\":null},\"automatically_finalizes_at\":null,\"billing_reason\":\"subscription_create\",\"collection_method\":\"charge_automatically\",\"created\":1775329718,\"currency\":\"usd\",\"custom_fields\":null,\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"customer_address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"customer_email\":\"revivedchurchofgod@outlook.com\",\"customer_name\":\"Revived Church of God\",\"customer_phone\":null,\"customer_shipping\":null,\"customer_tax_exempt\":\"none\",\"customer_tax_ids\":[],\"default_payment_method\":null,\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"due_date\":null,\"effective_at\":1775329718,\"ending_balance\":0,\"footer\":null,\"from_invoice\":null,\"hosted_invoice_url\":\"https:\\/\\/invoice.stripe.com\\/i\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VSDdvbnFJYnc4bks3M1BLc3BtQUVUV0JCbmplcVlTLDE2NTg3MDUzMw0200GzOOIQwt?s=ap\",\"invoice_pdf\":\"https:\\/\\/pay.stripe.com\\/invoice\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VSDdvbnFJYnc4bks3M1BLc3BtQUVUV0JCbmplcVlTLDE2NTg3MDUzMw0200GzOOIQwt\\/pdf?s=ap\",\"issuer\":{\"type\":\"self\"},\"last_finalization_error\":null,\"latest_revision\":null,\"lines\":{\"object\":\"list\",\"data\":[{\"id\":\"il_1TIZYgDtVSgFr1B07BTH6OEl\",\"object\":\"line_item\",\"amount\":1200,\"currency\":\"usd\",\"description\":\"1 \\u00d7 Monthly Subscription (at $12.00 \\/ month)\",\"discount_amounts\":[],\"discountable\":true,\"discounts\":[],\"invoice\":\"in_1TIZYgDtVSgFr1B0ivCRjUdz\",\"livemode\":true,\"metadata\":[],\"parent\":{\"invoice_item_details\":null,\"license_fee_subscription_details\":null,\"subscription_item_details\":{\"invoice_item\":null,\"proration\":false,\"proration_details\":{\"credited_items\":null},\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"subscription_item\":\"si_UH7oHLGxSye0gf\"},\"type\":\"subscription_item_details\"},\"period\":{\"end\":1777921718,\"start\":1775329718},\"pretax_credit_amounts\":[],\"pricing\":{\"price_details\":{\"price\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"product\":\"prod_ToiEyjVhflCXX1\"},\"type\":\"price_details\",\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"quantity_decimal\":\"1\",\"subtotal\":1200,\"taxes\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/invoices\\/in_1TIZYgDtVSgFr1B0ivCRjUdz\\/lines\"},\"livemode\":true,\"metadata\":[],\"next_payment_attempt\":null,\"number\":\"SALV53MV-0001\",\"on_behalf_of\":null,\"parent\":{\"quote_details\":null,\"subscription_details\":{\"metadata\":[],\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"type\":\"subscription_details\"},\"payment_settings\":{\"default_mandate\":null,\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null},\"period_end\":1775329718,\"period_start\":1775329718,\"post_payment_credit_notes_amount\":0,\"pre_payment_credit_notes_amount\":0,\"receipt_number\":null,\"rendering\":null,\"shipping_cost\":null,\"shipping_details\":null,\"starting_balance\":0,\"statement_descriptor\":null,\"status\":\"paid\",\"status_transitions\":{\"finalized_at\":1775329718,\"marked_uncollectible_at\":null,\"paid_at\":1775329728,\"voided_at\":null},\"subtotal\":1200,\"subtotal_excluding_tax\":1200,\"test_clock\":null,\"total\":1200,\"total_discount_amounts\":[],\"total_excluding_tax\":1200,\"total_pretax_credit_amounts\":[],\"total_taxes\":[],\"webhooks_delivered_at\":1775329718}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"invoice.payment_succeeded\"}',1775329734),
('evt_1TTRrfDtVSgFr1B0elVoBOTz','{\"id\":\"evt_1TTRrfDtVSgFr1B0elVoBOTz\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1777921751,\"data\":{\"object\":{\"id\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"object\":\"subscription\",\"application\":null,\"application_fee_percent\":null,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null},\"billing_cycle_anchor\":1775329718,\"billing_cycle_anchor_config\":null,\"billing_mode\":{\"flexible\":{\"proration_discounts\":\"included\"},\"type\":\"flexible\",\"updated_at\":1775327823},\"billing_thresholds\":null,\"cancel_at\":null,\"cancel_at_period_end\":false,\"canceled_at\":null,\"cancellation_details\":{\"comment\":null,\"feedback\":null,\"reason\":null},\"collection_method\":\"charge_automatically\",\"created\":1775329718,\"currency\":\"usd\",\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"days_until_due\":null,\"default_payment_method\":\"pm_1TIZYfDtVSgFr1B0oO4uB6Rt\",\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"ended_at\":null,\"invoice_settings\":{\"account_tax_ids\":null,\"issuer\":{\"type\":\"self\"}},\"items\":{\"object\":\"list\",\"data\":[{\"id\":\"si_UH7oHLGxSye0gf\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1775329719,\"current_period_end\":1780600118,\"current_period_start\":1777921718,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"tax_rates\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/subscription_items?subscription=sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"latest_invoice\":\"in_1TTRreDtVSgFr1B0Eyzmb4Cf\",\"livemode\":true,\"managed_payments\":{\"enabled\":false},\"metadata\":[],\"next_pending_invoice_item_invoice\":null,\"on_behalf_of\":null,\"pause_collection\":null,\"payment_settings\":{\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"network\":null,\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null,\"save_default_payment_method\":\"off\"},\"pending_invoice_item_interval\":null,\"pending_setup_intent\":null,\"pending_update\":null,\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"quantity\":1,\"schedule\":null,\"start_date\":1775329718,\"status\":\"active\",\"test_clock\":null,\"transfer_data\":null,\"trial_end\":null,\"trial_settings\":{\"end_behavior\":{\"missing_payment_method\":\"create_invoice\"}},\"trial_start\":null},\"previous_attributes\":{\"items\":{\"data\":[{\"id\":\"si_UH7oHLGxSye0gf\",\"object\":\"subscription_item\",\"billing_thresholds\":null,\"created\":1775329719,\"current_period_end\":1777921718,\"current_period_start\":1775329718,\"discounts\":[],\"metadata\":[],\"plan\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"plan\",\"active\":true,\"amount\":1200,\"amount_decimal\":\"1200\",\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"interval\":\"month\",\"interval_count\":1,\"livemode\":true,\"metadata\":[],\"meter\":null,\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"tiers_mode\":null,\"transform_usage\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"price\":{\"id\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"object\":\"price\",\"active\":true,\"billing_scheme\":\"per_unit\",\"created\":1768776671,\"currency\":\"usd\",\"custom_unit_amount\":null,\"livemode\":true,\"lookup_key\":null,\"metadata\":[],\"nickname\":null,\"product\":\"prod_ToiEyjVhflCXX1\",\"recurring\":{\"interval\":\"month\",\"interval_count\":1,\"meter\":null,\"trial_period_days\":null,\"usage_type\":\"licensed\"},\"tax_behavior\":\"unspecified\",\"tiers_mode\":null,\"transform_quantity\":null,\"type\":\"recurring\",\"unit_amount\":1200,\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"tax_rates\":[]}]},\"latest_invoice\":\"in_1TIZYgDtVSgFr1B0ivCRjUdz\"}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"customer.subscription.updated\"}',1777921752),
('evt_1TTSoCDtVSgFr1B0q08KRGy6','{\"id\":\"evt_1TTSoCDtVSgFr1B0q08KRGy6\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1777925380,\"data\":{\"object\":{\"id\":\"cus_UH7oaNjitT2rrv\",\"object\":\"customer\",\"address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"balance\":0,\"created\":1775329718,\"currency\":\"usd\",\"customer_account\":null,\"default_source\":null,\"delinquent\":false,\"description\":null,\"discount\":null,\"email\":\"revivedchurchofgod@outlook.com\",\"invoice_prefix\":\"SALV53MV\",\"invoice_settings\":{\"custom_fields\":null,\"default_payment_method\":null,\"footer\":null,\"rendering_options\":null},\"livemode\":true,\"metadata\":[],\"name\":\"Revived Church of God\",\"next_invoice_sequence\":3,\"phone\":null,\"preferred_locales\":[\"en-US\"],\"shipping\":null,\"tax_exempt\":\"none\",\"test_clock\":null},\"previous_attributes\":{\"next_invoice_sequence\":2}},\"livemode\":true,\"pending_webhooks\":1,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"customer.updated\"}',1777925381),
('evt_1TTSoDDtVSgFr1B0enRJ7wEZ','{\"id\":\"evt_1TTSoDDtVSgFr1B0enRJ7wEZ\",\"object\":\"event\",\"api_version\":\"2025-12-15.clover\",\"created\":1777925380,\"data\":{\"object\":{\"id\":\"in_1TTRreDtVSgFr1B0Eyzmb4Cf\",\"object\":\"invoice\",\"account_country\":\"US\",\"account_name\":\"Liturgia\",\"account_tax_ids\":null,\"amount_due\":1200,\"amount_overpaid\":0,\"amount_paid\":1200,\"amount_remaining\":0,\"amount_shipping\":0,\"application\":null,\"attempt_count\":1,\"attempted\":true,\"auto_advance\":false,\"automatic_tax\":{\"disabled_reason\":null,\"enabled\":false,\"liability\":null,\"provider\":null,\"status\":null},\"automatically_finalizes_at\":null,\"billing_reason\":\"subscription_cycle\",\"collection_method\":\"charge_automatically\",\"created\":1777921750,\"currency\":\"usd\",\"custom_fields\":null,\"customer\":\"cus_UH7oaNjitT2rrv\",\"customer_account\":null,\"customer_address\":{\"city\":null,\"country\":\"US\",\"line1\":null,\"line2\":null,\"postal_code\":\"72437\",\"state\":null},\"customer_email\":\"revivedchurchofgod@outlook.com\",\"customer_name\":\"Revived Church of God\",\"customer_phone\":null,\"customer_shipping\":null,\"customer_tax_exempt\":\"none\",\"customer_tax_ids\":[],\"default_payment_method\":null,\"default_source\":null,\"default_tax_rates\":[],\"description\":null,\"discounts\":[],\"due_date\":null,\"effective_at\":1777925373,\"ending_balance\":0,\"footer\":null,\"from_invoice\":null,\"hosted_invoice_url\":\"https:\\/\\/invoice.stripe.com\\/i\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VU01hcHJ6STRFWXB0UzluYkg2VG1hT29UVVdnQ1duLDE2ODQ2NjE4MQ02002FvQFDSd?s=ap\",\"invoice_pdf\":\"https:\\/\\/pay.stripe.com\\/invoice\\/acct_1Sr4U0DtVSgFr1B0\\/live_YWNjdF8xU3I0VTBEdFZTZ0ZyMUIwLF9VU01hcHJ6STRFWXB0UzluYkg2VG1hT29UVVdnQ1duLDE2ODQ2NjE4MQ02002FvQFDSd\\/pdf?s=ap\",\"issuer\":{\"type\":\"self\"},\"last_finalization_error\":null,\"latest_revision\":null,\"lines\":{\"object\":\"list\",\"data\":[{\"id\":\"il_1TTRr8DtVSgFr1B0zJgsEbXC\",\"object\":\"line_item\",\"amount\":1200,\"currency\":\"usd\",\"description\":\"1 \\u00d7 Monthly Subscription (at $12.00 \\/ month)\",\"discount_amounts\":[],\"discountable\":true,\"discounts\":[],\"invoice\":\"in_1TTRreDtVSgFr1B0Eyzmb4Cf\",\"livemode\":true,\"metadata\":[],\"parent\":{\"invoice_item_details\":null,\"license_fee_subscription_details\":null,\"subscription_item_details\":{\"invoice_item\":null,\"proration\":false,\"proration_details\":{\"credited_items\":null},\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\",\"subscription_item\":\"si_UH7oHLGxSye0gf\"},\"type\":\"subscription_item_details\"},\"period\":{\"end\":1780600118,\"start\":1777921718},\"pretax_credit_amounts\":[],\"pricing\":{\"price_details\":{\"price\":\"price_1Sr4oNDtVSgFr1B0pojNxZoA\",\"product\":\"prod_ToiEyjVhflCXX1\"},\"type\":\"price_details\",\"unit_amount_decimal\":\"1200\"},\"quantity\":1,\"quantity_decimal\":\"1\",\"subtotal\":1200,\"taxes\":[]}],\"has_more\":false,\"total_count\":1,\"url\":\"\\/v1\\/invoices\\/in_1TTRreDtVSgFr1B0Eyzmb4Cf\\/lines\"},\"livemode\":true,\"metadata\":[],\"next_payment_attempt\":null,\"number\":\"SALV53MV-0002\",\"on_behalf_of\":null,\"parent\":{\"quote_details\":null,\"subscription_details\":{\"metadata\":[],\"subscription\":\"sub_1TIZYrDtVSgFr1B0w99zNB53\"},\"type\":\"subscription_details\"},\"payment_settings\":{\"default_mandate\":null,\"payment_method_options\":{\"acss_debit\":null,\"bancontact\":null,\"card\":{\"request_three_d_secure\":\"automatic\"},\"customer_balance\":null,\"konbini\":null,\"payto\":null,\"pix\":null,\"sepa_debit\":null,\"upi\":null,\"us_bank_account\":null},\"payment_method_types\":null},\"period_end\":1777921718,\"period_start\":1775329718,\"post_payment_credit_notes_amount\":0,\"pre_payment_credit_notes_amount\":0,\"receipt_number\":null,\"rendering\":null,\"shipping_cost\":null,\"shipping_details\":null,\"starting_balance\":0,\"statement_descriptor\":null,\"status\":\"paid\",\"status_transitions\":{\"finalized_at\":1777925373,\"marked_uncollectible_at\":null,\"paid_at\":1777925373,\"voided_at\":null},\"subtotal\":1200,\"subtotal_excluding_tax\":1200,\"test_clock\":null,\"total\":1200,\"total_discount_amounts\":[],\"total_excluding_tax\":1200,\"total_pretax_credit_amounts\":[],\"total_taxes\":[],\"webhooks_delivered_at\":1777921750}},\"livemode\":true,\"pending_webhooks\":2,\"request\":{\"id\":null,\"idempotency_key\":null},\"type\":\"invoice.payment_succeeded\"}',1777925381);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magic_links`
--

DROP TABLE IF EXISTS `magic_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `magic_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `used` tinyint(4) DEFAULT 0,
  `created_at` int(11) DEFAULT NULL,
  `expires_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magic_links`
--

LOCK TABLES `magic_links` WRITE;
/*!40000 ALTER TABLE `magic_links` DISABLE KEYS */;
INSERT INTO `magic_links` VALUES
(7,'647d728baa78284ff6272b08b555c433','jacqueb1337@gmail.com',1,NULL,1768870160),
(8,'bfdae1ad639c2d6922ba3aeef48ab5a1','jacqueb1337@gmail.com',1,NULL,1768977215),
(9,'1f7700a31854566592b62a2135564068','jacqueb1337@gmail.com',1,NULL,1768977666),
(10,'e396b321da8dbef80e632e8db64c4fbe','jacqueb1337@gmail.com',1,NULL,1769116406),
(11,'e2c245c989abd946db6a259246746f84','jacqueb1337@gmail.com',1,NULL,1769116724),
(12,'b0f7f483327aa0e6a10aae43c50e791f','jacqueb1337@gmail.com',1,NULL,1769121209),
(13,'fe0a3bfe779b18386638f30b52aa2f24','jacqueb1337@gmail.com',1,NULL,1769124859);
/*!40000 ALTER TABLE `magic_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relay_magic_links`
--

DROP TABLE IF EXISTS `relay_magic_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relay_magic_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_email` (`email`),
  KEY `idx_token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relay_magic_links`
--

LOCK TABLES `relay_magic_links` WRITE;
/*!40000 ALTER TABLE `relay_magic_links` DISABLE KEYS */;
INSERT INTO `relay_magic_links` VALUES
(9,'jacqueb1337@gmail.com','c2269672980764becab4b73e68e28129c093e0dedfc853e3db8033510bf6da26','2026-02-16 04:26:21','2026-02-16 04:36:21',NULL),
(10,'jacqueb1337@gmail.com','8c95f88493eb9a27ff338c17af6a80d90d43dfccdd2d8c1dea73ed91013ed1ee','2026-02-16 04:32:09','2026-02-16 04:42:09',NULL);
/*!40000 ALTER TABLE `relay_magic_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relay_messages`
--

DROP TABLE IF EXISTS `relay_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relay_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `direction` varchar(10) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relay_messages`
--

LOCK TABLES `relay_messages` WRITE;
/*!40000 ALTER TABLE `relay_messages` DISABLE KEYS */;
INSERT INTO `relay_messages` VALUES
(1,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"GO_LIVE\",\"data\":[]}','2026-02-16 05:22:56','2026-02-16 05:22:56'),
(2,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 05:23:04','2026-02-16 05:23:04'),
(3,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-02-16 05:23:05','2026-02-16 05:23:06'),
(4,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 05:23:07','2026-02-16 05:23:07'),
(5,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 05:23:07','2026-02-16 05:23:08'),
(6,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"PREV_VERSE\",\"data\":[]}','2026-02-16 05:23:10','2026-02-16 05:23:10'),
(7,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"GO_LIVE\",\"data\":[]}','2026-02-16 05:23:12','2026-02-16 05:23:12'),
(8,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":3,\"goLive\":true}}','2026-02-16 05:56:39','2026-02-16 05:56:40'),
(9,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":3,\"goLive\":true}}','2026-02-16 05:56:47','2026-02-16 05:56:48'),
(10,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-16 05:56:54','2026-02-16 05:56:54'),
(11,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":3,\"goLive\":true}}','2026-02-16 05:59:20','2026-02-16 05:59:20'),
(12,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":14,\"verse\":3}}','2026-02-16 06:06:04','2026-02-16 06:06:05'),
(13,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":14,\"verse\":3,\"goLive\":true}}','2026-02-16 06:06:05','2026-02-16 06:06:05'),
(14,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 06:06:11','2026-02-16 06:06:11'),
(15,'1d3740b0b33fcd3c7ba9f247e9bb9eaf','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 06:06:11','2026-02-16 06:06:12'),
(16,'5815b9924058a748bb068f37d124ded1','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:12:04','2026-02-16 06:12:04'),
(17,'5815b9924058a748bb068f37d124ded1','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:12:09','2026-02-16 06:12:09'),
(18,'c818293c9b2f97074c730b793f1caa71','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:14:59','2026-02-16 06:15:00'),
(19,'c818293c9b2f97074c730b793f1caa71','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:16:33',NULL),
(20,'c818293c9b2f97074c730b793f1caa71','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:16:37',NULL),
(21,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:19:49','2026-02-16 06:19:49'),
(22,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-16 06:19:54','2026-02-16 06:19:55'),
(23,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:20:04','2026-02-16 06:20:04'),
(24,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-16 06:20:07','2026-02-16 06:20:08'),
(25,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1}}','2026-02-16 06:20:09','2026-02-16 06:20:09'),
(26,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-16 06:20:11','2026-02-16 06:20:11'),
(27,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 06:20:12','2026-02-16 06:20:12'),
(28,'ee862f448a9c52447a468fcb20f34f31','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":1,\"goLive\":true}}','2026-02-16 06:20:32','2026-02-16 06:20:32'),
(29,'824ada8a39ad1e456110c6a2d4451622','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":1,\"goLive\":true}}','2026-02-16 06:24:47','2026-02-16 06:24:47'),
(30,'da18d41d832c45343dfb229296003323','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 16:13:00','2026-02-16 16:13:00'),
(31,'da18d41d832c45343dfb229296003323','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 16:13:05','2026-02-16 16:13:05'),
(32,'da18d41d832c45343dfb229296003323','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-02-16 16:13:06','2026-02-16 16:13:07'),
(33,'da18d41d832c45343dfb229296003323','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-02-16 16:13:08','2026-02-16 16:13:08'),
(34,'da18d41d832c45343dfb229296003323','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-02-16 16:13:09','2026-02-16 16:13:09'),
(35,'b97f338282117aa78a42d75e43c5d467','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-16 16:14:50','2026-02-16 16:14:51'),
(36,'b97f338282117aa78a42d75e43c5d467','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-16 16:14:55','2026-02-16 16:14:55'),
(37,'b97f338282117aa78a42d75e43c5d467','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1}}','2026-02-16 16:14:58','2026-02-16 16:14:58'),
(38,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_SCHEDULE_ITEM\",\"data\":[]}','2026-02-17 01:58:57','2026-02-17 01:58:57'),
(39,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_SCHEDULE_ITEM\",\"data\":[]}','2026-02-17 01:58:58','2026-02-17 01:58:58'),
(40,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Exodus\",\"chapter\":12,\"verse\":2,\"goLive\":true}}','2026-02-17 01:59:07','2026-02-17 01:59:08'),
(41,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-17 01:59:44','2026-02-17 01:59:44'),
(42,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-02-17 01:59:46','2026-02-17 01:59:46'),
(43,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Exodus\",\"chapter\":12,\"verse\":2,\"goLive\":true}}','2026-02-17 01:59:47','2026-02-17 01:59:48'),
(44,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_SCHEDULE_ITEM\",\"data\":[]}','2026-02-17 02:00:01','2026-02-17 02:00:01'),
(45,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"NEXT_SCHEDULE_ITEM\",\"data\":[]}','2026-02-17 02:00:05','2026-02-17 02:00:06'),
(46,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Exodus\",\"chapter\":12,\"verse\":5}}','2026-02-17 02:02:08','2026-02-17 02:02:08'),
(47,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"PREV_VERSE\",\"data\":[]}','2026-02-17 02:02:38','2026-02-17 02:02:38'),
(48,'18f33cd3f1ae671cbe41b8c0c26d64b7','to_desktop','{\"command\":\"PREV_SCHEDULE_ITEM\",\"data\":[]}','2026-02-17 02:07:53','2026-02-17 02:07:53'),
(49,'caf5d7634c616253e1d0f495e568a155','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-02-17 02:19:42','2026-02-17 02:19:42'),
(50,'caf5d7634c616253e1d0f495e568a155','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-02-17 02:21:04','2026-02-17 02:21:04'),
(51,'caf5d7634c616253e1d0f495e568a155','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":2}}','2026-02-17 02:25:37','2026-02-17 02:25:37'),
(52,'caf5d7634c616253e1d0f495e568a155','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":23}}','2026-02-17 02:25:42','2026-02-17 02:25:42'),
(53,'caf5d7634c616253e1d0f495e568a155','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":23,\"goLive\":true}}','2026-02-17 02:25:43','2026-02-17 02:25:44'),
(54,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":6}}','2026-03-20 05:59:05','2026-03-20 05:59:06'),
(55,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 05:59:11','2026-03-20 05:59:14'),
(56,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 05:59:12','2026-03-20 05:59:14'),
(57,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 05:59:13','2026-03-20 05:59:14'),
(58,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 05:59:19','2026-03-20 05:59:22'),
(59,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 05:59:22','2026-03-20 05:59:25'),
(60,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":6}}','2026-03-20 05:59:27','2026-03-20 05:59:28'),
(61,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8}}','2026-03-20 05:59:36','2026-03-20 05:59:36'),
(62,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8,\"goLive\":true}}','2026-03-20 05:59:37','2026-03-20 05:59:39'),
(63,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"ADD_TO_SCHEDULE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8}}','2026-03-20 05:59:45','2026-03-20 05:59:47'),
(64,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"ADD_TO_SCHEDULE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8}}','2026-03-20 05:59:49',NULL),
(65,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:37',NULL),
(66,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:38',NULL),
(67,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:42',NULL),
(68,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:43',NULL),
(69,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:44',NULL),
(70,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 06:04:44',NULL),
(71,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 06:05:10',NULL),
(72,'1ec302b13307a526ba57eef707b8ab6d','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 06:05:16',NULL),
(73,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8}}','2026-03-20 06:06:01',NULL),
(74,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8,\"goLive\":true}}','2026-03-20 06:06:09',NULL),
(75,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8,\"goLive\":true}}','2026-03-20 06:06:14',NULL),
(76,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":8}}','2026-03-20 06:06:27',NULL),
(77,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"PREV_VERSE\",\"data\":[]}','2026-03-20 06:06:34',NULL),
(78,'944149c050befbfc7ef51e4b84447ce5','to_desktop','{\"command\":\"PREV_VERSE\",\"data\":[]}','2026-03-20 06:06:35',NULL),
(79,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":5}}','2026-03-20 06:08:29',NULL),
(80,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":5}}','2026-03-20 06:08:30',NULL),
(81,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":5}}','2026-03-20 06:08:30',NULL),
(82,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":5}}','2026-03-20 06:08:40',NULL),
(83,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":6}}','2026-03-20 06:08:40',NULL),
(84,'dfea77f9de41b5b7fca66d49b6e8f126','to_desktop','{\"command\":\"ADD_TO_SCHEDULE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":1}}','2026-03-20 06:08:46',NULL),
(85,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":0}}','2026-03-20 06:22:13',NULL),
(86,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":0}}','2026-03-20 06:22:16',NULL),
(87,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":0}}','2026-03-20 06:22:22',NULL),
(88,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":0}}','2026-03-20 06:22:28',NULL),
(89,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":0}}','2026-03-20 06:22:31',NULL),
(90,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":2}}','2026-03-20 06:22:34',NULL),
(91,'f2183e32f5b519639798f15d01caadda','to_desktop','{\"command\":\"ADD_TO_SCHEDULE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":1}}','2026-03-20 06:23:55',NULL),
(92,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":1}}','2026-03-20 16:57:52','2026-03-20 16:57:55'),
(93,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":1}}','2026-03-20 16:57:53','2026-03-20 16:57:55'),
(94,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":2}}','2026-03-20 16:57:59','2026-03-20 16:57:59'),
(95,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":19}}','2026-03-20 17:01:59','2026-03-20 17:02:02'),
(96,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":19}}','2026-03-20 17:02:02','2026-03-20 17:02:05'),
(97,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":19}}','2026-03-20 17:02:02','2026-03-20 17:02:05'),
(98,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":19}}','2026-03-20 17:02:03','2026-03-20 17:02:05'),
(99,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":21}}','2026-03-20 17:02:08','2026-03-20 17:02:08'),
(100,'6b40326af8ea34a5819f37f78cf03acc','to_desktop','{\"command\":\"SELECT_SONG\",\"data\":{\"songIndex\":20}}','2026-03-20 17:02:10','2026-03-20 17:02:12'),
(101,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 18:35:44','2026-03-20 18:35:44'),
(102,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"NEXT_VERSE\",\"data\":[]}','2026-03-20 18:35:45','2026-03-20 18:35:47'),
(103,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:05:55','2026-03-20 19:05:55'),
(104,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:05:56','2026-03-20 19:05:58'),
(105,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-03-20 19:06:02','2026-03-20 19:06:02'),
(106,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"BLACK_SCREEN\",\"data\":[]}','2026-03-20 19:06:04','2026-03-20 19:06:06'),
(107,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":1,\"verseIndex\":0}}','2026-03-20 19:06:18','2026-03-20 19:06:19'),
(108,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":1,\"verseIndex\":0}}','2026-03-20 19:06:35','2026-03-20 19:06:37'),
(109,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":4}}','2026-03-20 19:11:40','2026-03-20 19:11:41'),
(110,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":5}}','2026-03-20 19:11:42','2026-03-20 19:11:46'),
(111,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":5}}','2026-03-20 19:11:45','2026-03-20 19:11:46'),
(112,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":5}}','2026-03-20 19:11:48','2026-03-20 19:12:02'),
(113,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":6}}','2026-03-20 19:12:24','2026-03-20 19:12:30'),
(114,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":6}}','2026-03-20 19:12:25','2026-03-20 19:12:30'),
(115,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":7}}','2026-03-20 19:14:29','2026-03-20 19:25:15'),
(116,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":7}}','2026-03-20 19:14:29','2026-03-20 19:25:15'),
(117,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":6,\"verseIndex\":10}}','2026-03-20 19:14:36','2026-03-20 19:25:15'),
(118,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":3}}','2026-03-20 19:14:37','2026-03-20 19:25:15'),
(119,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":2}}','2026-03-20 19:14:38','2026-03-20 19:25:15'),
(120,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":2}}','2026-03-20 19:14:38','2026-03-20 19:25:15'),
(121,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":3}}','2026-03-20 19:14:39','2026-03-20 19:25:15'),
(122,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":0}}','2026-03-20 19:14:39','2026-03-20 19:25:15'),
(123,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":1}}','2026-03-20 19:14:40','2026-03-20 19:25:15'),
(124,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":3}}','2026-03-20 19:14:40','2026-03-20 19:25:15'),
(125,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":4}}','2026-03-20 19:14:41','2026-03-20 19:25:22'),
(126,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":0}}','2026-03-20 19:14:42','2026-03-20 19:25:22'),
(127,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":1}}','2026-03-20 19:14:43','2026-03-20 19:25:22'),
(128,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":3}}','2026-03-20 19:14:44','2026-03-20 19:25:22'),
(129,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":12,\"verseIndex\":4}}','2026-03-20 19:24:54','2026-03-20 19:25:22'),
(130,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":2,\"goLive\":true}}','2026-03-20 19:25:07','2026-03-20 19:25:22'),
(131,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":2,\"goLive\":true}}','2026-03-20 19:25:27','2026-03-20 19:25:28'),
(132,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":4,\"goLive\":true}}','2026-03-20 19:25:34','2026-03-20 19:25:35'),
(133,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:25:50','2026-03-20 19:25:54'),
(134,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:25:59','2026-03-20 19:25:59'),
(135,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:26:14','2026-03-20 19:27:20'),
(136,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:26:26','2026-03-20 19:27:20'),
(137,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:26:34','2026-03-20 19:27:20'),
(138,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:26:48','2026-03-20 19:27:20'),
(139,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:26:48','2026-03-20 19:27:20'),
(140,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:26:49','2026-03-20 19:27:20'),
(141,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:27:03','2026-03-20 19:27:20'),
(142,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":6,\"goLive\":true}}','2026-03-20 19:27:34','2026-03-20 19:27:34'),
(143,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"CLEAR_LIVE\",\"data\":[]}','2026-03-20 19:27:39','2026-03-20 19:27:40'),
(144,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":7,\"goLive\":true}}','2026-03-20 19:27:47','2026-03-20 19:27:52'),
(145,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":7,\"goLive\":true}}','2026-03-20 19:27:55','2026-03-20 19:27:57'),
(146,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":8,\"goLive\":true}}','2026-03-20 19:28:01','2026-03-20 19:28:01'),
(147,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":8,\"goLive\":true}}','2026-03-20 19:28:12','2026-03-20 19:28:14'),
(148,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":8,\"goLive\":true}}','2026-03-20 19:28:46','2026-03-20 19:28:49'),
(149,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":12,\"verse\":5,\"goLive\":true}}','2026-03-20 19:32:08','2026-03-20 19:32:08'),
(150,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Exodus\",\"chapter\":12,\"verse\":5,\"verseEnd\":null,\"goLive\":true}}','2026-03-20 19:39:36','2026-03-20 19:39:38'),
(151,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":0,\"verseIndex\":1}}','2026-03-20 19:39:53','2026-03-20 19:39:55'),
(152,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":0,\"verseIndex\":1}}','2026-03-20 19:39:55','2026-03-20 19:39:55'),
(153,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":2}}','2026-03-20 19:42:53','2026-03-20 19:42:56'),
(154,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":2}}','2026-03-20 19:42:53','2026-03-20 19:42:56'),
(155,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":3}}','2026-03-20 19:43:01','2026-03-20 19:43:01'),
(156,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":3}}','2026-03-20 19:43:02','2026-03-20 19:43:06'),
(157,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":2}}','2026-03-20 19:43:05','2026-03-20 19:43:06'),
(158,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":1}}','2026-03-20 19:43:05','2026-03-20 19:43:06'),
(159,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":1}}','2026-03-20 19:43:06','2026-03-20 19:43:06'),
(160,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":2}}','2026-03-20 19:43:10','2026-03-20 19:43:12'),
(161,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":2}}','2026-03-20 19:43:10','2026-03-20 19:43:12'),
(162,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":3}}','2026-03-20 19:43:17','2026-03-20 19:43:18'),
(163,'6a0393819dd561d6cbf4123429150091','to_desktop','{\"command\":\"DISPLAY_SONG_VERSE\",\"data\":{\"songIndex\":10,\"verseIndex\":3}}','2026-03-20 19:43:18','2026-03-20 19:43:24'),
(164,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-03-21 00:18:48','2026-03-21 00:30:00'),
(165,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-03-21 00:24:44','2026-03-21 00:30:00'),
(166,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-03-21 00:24:44','2026-03-21 00:30:00'),
(167,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-03-21 00:24:45','2026-03-21 00:30:00'),
(168,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Leviticus\",\"chapter\":4,\"verse\":7,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:24:54','2026-03-21 00:30:00'),
(169,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":3,\"verse\":2,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:30:20','2026-03-21 00:30:21'),
(170,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:34:08','2026-03-22 17:19:27'),
(171,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:35:47','2026-03-22 17:19:27'),
(172,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:37:18','2026-03-22 17:19:27'),
(173,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"verseEnd\":null,\"goLive\":true}}','2026-03-21 00:38:17','2026-03-22 17:19:27'),
(174,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"command\":\"SELECT_VERSE\",\"data\":{\"book\":\"Genesis\",\"chapter\":1,\"verse\":1,\"goLive\":true}}','2026-03-21 00:45:17','2026-03-22 17:19:27'),
(175,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"type\":\"command\",\"data\":{\"command\":\"REQUEST_STATE\",\"data\":{}}}','2026-03-22 23:23:22','2026-03-22 23:29:04'),
(176,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"type\":\"command\",\"data\":{\"command\":\"REQUEST_STATE\",\"data\":{}}}','2026-03-22 23:23:28','2026-03-22 23:29:04'),
(177,'9641847d02e044547ae10d653e0d1083','to_desktop','{\"type\":\"command\",\"data\":{\"command\":\"REQUEST_STATE\",\"data\":{}}}','2026-03-22 23:29:13','2026-03-22 23:29:14');
/*!40000 ALTER TABLE `relay_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relay_sessions`
--

DROP TABLE IF EXISTS `relay_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relay_sessions` (
  `session_id` varchar(64) NOT NULL,
  `email` varchar(255) NOT NULL,
  `device_name` varchar(255) DEFAULT NULL,
  `last_seen` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`session_id`),
  KEY `idx_email` (`email`),
  KEY `idx_last_seen` (`last_seen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relay_sessions`
--

LOCK TABLES `relay_sessions` WRITE;
/*!40000 ALTER TABLE `relay_sessions` DISABLE KEYS */;
INSERT INTO `relay_sessions` VALUES
('4e8a2699490fa1cad9f93f49d20f3866','contact@alcparagould.church','Liturgia Desktop','2026-06-12 18:15:15','2026-04-25 00:56:14');
/*!40000 ALTER TABLE `relay_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relay_state`
--

DROP TABLE IF EXISTS `relay_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relay_state` (
  `session_id` varchar(64) NOT NULL,
  `state` longtext NOT NULL,
  `last_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`session_id`),
  CONSTRAINT `relay_state_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `relay_sessions` (`session_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relay_state`
--

LOCK TABLES `relay_state` WRITE;
/*!40000 ALTER TABLE `relay_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `relay_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_events`
--

DROP TABLE IF EXISTS `stripe_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stripe_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` varchar(255) DEFAULT NULL,
  `processed_at` int(11) DEFAULT NULL,
  `payload` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_events`
--

LOCK TABLES `stripe_events` WRITE;
/*!40000 ALTER TABLE `stripe_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `stripe_customer_id` varchar(255) DEFAULT NULL,
  `active` tinyint(4) DEFAULT 0,
  `plan` varchar(50) DEFAULT NULL,
  `expires_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `founder` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(3,'jacqueb1337@gmail.com','cus_TqB6PvqiU5hjoU',1,'monthly',1803329100,1768866568,1),
(4,'mcglothlinboys123@gmail.com',NULL,1,'yearly',1800764212,1769228212,1),
(5,'leeschapelsandtown@gmail.com',NULL,1,'yearly',1803316370,1771780370,1),
(6,'alcparagould@gmail.com',NULL,1,'yearly',1803410539,1771874539,1),
(7,'stlackey@gmail.com',NULL,1,NULL,1803916328,1772380328,1),
(8,'contact@alcparagould.church',NULL,1,NULL,1804632685,1773096685,1),
(9,'revivedchurchofgod@outlook.com','cus_UH7oaNjitT2rrv',1,'monthly',1809457718,1775329733,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'jacquebm_liturgia'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-06-14 18:43:09
